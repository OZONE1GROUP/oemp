# OMAN's Enterprise Metadata Platform (OEMP)

A modular, metadata-driven enterprise suite built on **Laravel 12**. One multi-tenant
core (auth, tenancy, metadata engine, licensing/entitlements, event bus) hosts **25
business modules** from ERP and CRM through to Smart City and ESG.

> This repository is a **runnable scaffold**: the platform core and module architecture
> are real and consistent; ERP and CRM ship as reference implementations with full CRUD,
> and every other module is generated as a working package (model, migration, controller,
> routes, view) ready to extend.

## Tech stack

- **Backend:** Laravel 12 (PHP 8.2+)
- **Frontend:** Bootstrap 5 + Vue 3 (Vite)
- **Database:** MySQL 8 / PostgreSQL
- **Cache & Queues:** Redis
- **Realtime:** Laravel Reverb (WebSockets)
- **IoT messaging:** MQTT (Mosquitto)
- **Search:** Elasticsearch / OpenSearch
- **Storage:** S3-compatible (MinIO in dev)
- **Auth:** Sanctum + OAuth 2.0 / OIDC, MFA
- **Containers & CI:** Docker Compose, GitHub Actions

## Quick start (Docker)

```bash
cp .env.example .env
docker compose up -d --build
docker compose exec app composer install
docker compose exec app php artisan key:generate
docker compose exec app php artisan migrate --seed
npm install && npm run build      # or: npm run dev
```

App: http://localhost:8000  ·  Demo login: `admin@acme.test` / `password`

## Architecture

```
Presentation (Bootstrap 5 + Vue)
        |
   API Gateway (auth + tenant + entitlement middleware)
        |
Application Modules  (app/Modules/*)   <-- 25 modules, auto-discovered
        |
Core Services (app/Core/*)
  Metadata · Tenancy · Licensing · Events · Support
        |
Data: MySQL/Postgres · Redis · Elastic/OpenSearch · S3 · MQTT
```

### How modules work
Every module is a self-contained package under `app/Modules/<Name>/` extending
`App\Core\Support\ModuleServiceProvider`. It is registered once in
`config/emp.php` and auto-discovered at boot. Routes are guarded by
`auth:sanctum`, the `tenant` middleware, and a per-module `entitled:module.<key>`
check so access maps directly to the customer's subscription.

### Adding a module
1. Create `app/Modules/<Name>/` with a `<Name>ServiceProvider` (see any module).
2. Add its entry to `config/emp.php` under `modules`.
3. Add the module key to a tenant's `entitlements.modules` to unlock it.

## Modules

| # | Module | Key | Primary entity | Band |
|---|--------|-----|----------------|------|
| 1 | ERP | `erp` | SalesOrder | A |
| 2 | CRM | `crm` | Lead | A |
| 3 | HRMS | `hrms` | Employee | A |
| 4 | Payroll | `payroll` | PayrollRun | B |
| 5 | Accounting | `accounting` | JournalEntry | A |
| 6 | Procurement | `procurement` | PurchaseOrder | A |
| 7 | RfidWarehouse | `rfid_warehouse` | RfidTag | B |
| 8 | Inventory | `inventory` | Item | A |
| 9 | Manufacturing | `manufacturing` | WorkOrder | B |
| 10 | AssetManagement | `asset_management` | Asset | A |
| 11 | RealEstate | `real_estate` | Property | B |
| 12 | PropertyManagement | `property_management` | Lease | B |
| 13 | FacilityManagement | `facility_management` | ServiceRequest | B |
| 14 | HelpDesk | `help_desk` | Ticket | A |
| 15 | FleetManagement | `fleet_management` | Vehicle | B |
| 16 | SchoolErp | `school_erp` | Student | C |
| 17 | HospitalManagement | `hospital_management` | Patient | C |
| 18 | HotelManagement | `hotel_management` | Reservation | C |
| 19 | RetailPos | `retail_pos` | Sale | B |
| 20 | VisitorManagement | `visitor_management` | Visitor | B |
| 21 | VideoAnalytics | `video_analytics` | Camera | C |
| 22 | IotPlatform | `iot_platform` | Device | C |
| 23 | Dcim | `dcim` | Rack | C |
| 24 | SmartCity | `smart_city` | Incident | C |
| 25 | Esg | `esg` | EmissionSource | C |

*Bands: A = foundational, B = specialized, C = vertical/platform (see pricing model).*

## Repository layout

```
app/
  Core/            Platform core (Metadata, Tenancy, Licensing, Events, Support)
  Modules/         The 25 business modules (each a package)
  Providers/       AppServiceProvider, ModuleRegistryServiceProvider
config/emp.php     Module registry & platform settings
database/migrations  Core tables (tenants, users, entitlements, metadata, usage, audit)
resources/js       Vue 3 SPA shell (Bootstrap 5)
docker/            PHP, Nginx, MQTT images
docs/              Architecture & Hostinger deployment guides
.github/workflows  CI pipeline
```

## Deployment
See **docs/DEPLOYMENT-HOSTINGER.md** for hosting on Hostinger (VPS recommended).

## License
Proprietary. Commercial packaging is described in the EMP License & Subscription Model.
