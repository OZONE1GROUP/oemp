<?php

namespace App\Modules\HotelManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class HotelAnalyticsController extends Controller
{
    /** Occupancy: occupied rooms / total rooms. */
    public function occupancy()
    {
        $total = DB::table('hotel_rooms')->count();
        $occupied = DB::table('hotel_rooms')->where('status', 'occupied')->count();

        return ['total_rooms' => $total, 'occupied' => $occupied, 'occupancy_pct' => $total ? round($occupied / $total * 100, 1) : 0];
    }

    /** ADR (average daily rate) and RevPAR from checked-in/out reservations. */
    public function adrRevpar()
    {
        $roomsSold = DB::table('hotel_reservations')->whereIn('status', ['checked_in', 'checked_out'])->count();
        $roomRevenue = DB::table('hotel_folio_charges')->where('type', 'room')->sum('amount');
        $totalRooms = max(1, DB::table('hotel_rooms')->count());
        $adr = $roomsSold ? round((float) $roomRevenue / $roomsSold, 2) : 0;
        $revpar = round((float) $roomRevenue / $totalRooms, 2);

        return ['rooms_sold' => $roomsSold, 'room_revenue' => round((float) $roomRevenue, 2), 'adr' => $adr, 'revpar' => $revpar];
    }
}
