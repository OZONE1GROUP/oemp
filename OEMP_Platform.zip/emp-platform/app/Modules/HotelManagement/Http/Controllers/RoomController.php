<?php

namespace App\Modules\HotelManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HotelManagement\Models\RoomType;
use App\Modules\HotelManagement\Models\Room;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function roomTypes()
    {
        return RoomType::withCount('rooms')->get();
    }

    public function storeRoomType(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:20'],
            'name' => ['required', 'string', 'max:80'],
            'base_rate' => ['required', 'numeric', 'min:0'],
            'capacity' => ['nullable', 'integer', 'min:1'],
        ]);

        return response()->json(RoomType::create($data), 201);
    }

    public function rooms(Request $request)
    {
        return Room::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->orderBy('number')->paginate(100);
    }

    public function storeRoom(Request $request)
    {
        $data = $request->validate([
            'room_type_id' => ['required', 'integer', 'exists:hotel_room_types,id'],
            'number' => ['required', 'string', 'max:20'],
            'floor' => ['nullable', 'string', 'max:20'],
        ]);

        return response()->json(Room::create(array_merge($data, ['status' => 'available'])), 201);
    }
}
