<?php

namespace App\Modules\HotelManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HotelManagement\Models\Reservation;
use App\Modules\HotelManagement\Models\Room;
use App\Modules\HotelManagement\Models\RoomType;
use App\Modules\HotelManagement\Models\Folio;
use App\Core\Events\EventBus;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    public function index(Request $request)
    {
        return Reservation::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    /** Availability: rooms of a type not reserved over the date range. */
    public function availability(Request $request)
    {
        $data = $request->validate([
            'room_type_id' => ['required', 'integer', 'exists:hotel_room_types,id'],
            'check_in' => ['required', 'date'],
            'check_out' => ['required', 'date', 'after:check_in'],
        ]);

        $totalRooms = Room::where('room_type_id', $data['room_type_id'])->count();
        $booked = Reservation::where('room_type_id', $data['room_type_id'])
            ->whereIn('status', ['booked', 'checked_in'])
            ->where('check_in', '<', $data['check_out'])
            ->where('check_out', '>', $data['check_in'])
            ->count();

        return ['room_type_id' => $data['room_type_id'], 'total' => $totalRooms, 'booked' => $booked, 'available' => max(0, $totalRooms - $booked)];
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'guest_name' => ['required', 'string', 'max:150'],
            'guest_contact' => ['nullable', 'string', 'max:120'],
            'room_type_id' => ['required', 'integer', 'exists:hotel_room_types,id'],
            'check_in' => ['required', 'date'],
            'check_out' => ['required', 'date', 'after:check_in'],
            'adults' => ['nullable', 'integer', 'min:1'],
            'channel' => ['nullable', 'in:direct,web,ota,phone,walk_in'],
        ]);
        $rate = RoomType::find($data['room_type_id'])->base_rate;

        return response()->json(Reservation::create(array_merge($data, [
            'booking_no' => 'BKG-' . now()->format('YmdHis'),
            'rate' => $rate,
            'status' => 'booked',
            'channel' => $data['channel'] ?? 'direct',
        ])), 201);
    }

    /** Check-in: assign an available room, open a folio with room charge. */
    public function checkIn(Reservation $reservation, EventBus $bus)
    {
        abort_unless($reservation->status === 'booked', 422, 'Reservation not in booked state.');

        return DB::transaction(function () use ($reservation, $bus) {
            $room = Room::where('room_type_id', $reservation->room_type_id)->where('status', 'available')->lockForUpdate()->first();
            abort_unless($room, 422, 'No available room of this type.');
            $room->update(['status' => 'occupied']);

            $folio = Folio::create(['reservation_id' => $reservation->id, 'status' => 'open', 'balance' => 0]);
            $roomCharge = round((float) $reservation->rate * $reservation->nights(), 2);
            $folio->charges()->create(['description' => 'Room charge', 'amount' => $roomCharge, 'type' => 'room']);
            $folio->update(['balance' => $roomCharge]);

            $reservation->update(['room_id' => $room->id, 'status' => 'checked_in']);
            $bus->publish('hotel.guest.checked_in', ['reservation_id' => $reservation->id, 'room_id' => $room->id]);

            return response()->json($reservation->fresh(), 200);
        });
    }

    /** Check-out: settle folio, release room to housekeeping. */
    public function checkOut(Reservation $reservation)
    {
        abort_unless($reservation->status === 'checked_in', 422, 'Guest is not checked in.');

        return DB::transaction(function () use ($reservation) {
            Folio::where('reservation_id', $reservation->id)->update(['status' => 'closed']);
            if ($reservation->room_id) {
                Room::where('id', $reservation->room_id)->update(['status' => 'dirty']);
            }
            $reservation->update(['status' => 'checked_out']);

            return $reservation;
        });
    }
}
