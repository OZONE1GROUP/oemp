<?php

namespace App\Modules\HotelManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HotelManagement\Models\Folio;
use Illuminate\Http\Request;

class FolioController extends Controller
{
    public function show(Folio $folio)
    {
        return $folio->load('charges');
    }

    /** Post a charge (F&B, minibar, POS, etc.) to a folio. */
    public function charge(Request $request, Folio $folio)
    {
        $data = $request->validate([
            'description' => ['required', 'string', 'max:150'],
            'amount' => ['required', 'numeric'],
            'type' => ['required', 'in:room,fnb,minibar,pos,tax,service,payment'],
        ]);
        $folio->charges()->create($data);
        $delta = $data['type'] === 'payment' ? -abs($data['amount']) : $data['amount'];
        $folio->increment('balance', $delta);

        return $folio->fresh()->load('charges');
    }
}
