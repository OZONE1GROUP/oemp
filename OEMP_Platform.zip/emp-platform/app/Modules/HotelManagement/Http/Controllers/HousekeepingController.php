<?php

namespace App\Modules\HotelManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HotelManagement\Models\Housekeeping;
use App\Modules\HotelManagement\Models\Room;
use Illuminate\Http\Request;

class HousekeepingController extends Controller
{
    public function board()
    {
        return Room::orderBy('number')->get(['id', 'number', 'floor', 'status']);
    }

    /** Update room housekeeping status; 'clean' returns the room to available. */
    public function update(Request $request, Room $room)
    {
        $status = $request->validate(['status' => ['required', 'in:clean,dirty,inspected,out_of_order']])['status'];
        Housekeeping::create(['room_id' => $room->id, 'status' => $status, 'date' => now()->toDateString()]);
        $room->update(['status' => $status === 'clean' || $status === 'inspected' ? 'available' : ($status === 'out_of_order' ? 'ooo' : 'dirty')]);

        return $room;
    }
}
