<?php

namespace App\Modules\HotelManagement\Models;

use App\Core\Support\BaseModel;

class RatePlan extends BaseModel
{
    protected $table = 'hotel_rate_plans';
    protected $fillable = ['tenant_id', 'room_type_id', 'name', 'rate', 'start_date', 'end_date'];
    protected $casts = ['rate' => 'decimal:2', 'start_date' => 'date', 'end_date' => 'date'];

}
