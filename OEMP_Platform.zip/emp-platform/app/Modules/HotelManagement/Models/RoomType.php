<?php

namespace App\Modules\HotelManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class RoomType extends BaseModel
{
    protected $table = 'hotel_room_types';
    protected $fillable = ['tenant_id', 'code', 'name', 'base_rate', 'capacity'];
    protected $casts = ['base_rate' => 'decimal:2', 'capacity' => 'integer'];

    public function rooms(): HasMany
    {
        return $this->hasMany(Room::class);
    }
}
