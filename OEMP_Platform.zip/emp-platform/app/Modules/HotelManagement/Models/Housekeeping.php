<?php

namespace App\Modules\HotelManagement\Models;

use App\Core\Support\BaseModel;

class Housekeeping extends BaseModel
{
    protected $table = 'hotel_housekeeping';
    protected $fillable = ['tenant_id', 'room_id', 'status', 'assigned_to', 'date'];
    protected $casts = ['date' => 'date'];

}
