<?php

namespace App\Modules\HotelManagement\Models;

use App\Core\Support\BaseModel;

class FolioCharge extends BaseModel
{
    protected $table = 'hotel_folio_charges';
    protected $fillable = ['tenant_id', 'folio_id', 'description', 'amount', 'type'];
    protected $casts = ['amount' => 'decimal:2'];

}
