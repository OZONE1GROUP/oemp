<?php

namespace App\Modules\HotelManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Folio extends BaseModel
{
    protected $table = 'hotel_folios';
    protected $fillable = ['tenant_id', 'reservation_id', 'status', 'balance'];
    protected $casts = ['balance' => 'decimal:2'];

    public function charges(): HasMany
    {
        return $this->hasMany(FolioCharge::class);
    }
}
