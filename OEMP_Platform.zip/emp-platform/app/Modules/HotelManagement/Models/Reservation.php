<?php

namespace App\Modules\HotelManagement\Models;

use App\Core\Support\BaseModel;

class Reservation extends BaseModel
{
    protected $table = 'hotel_reservations';
    protected $fillable = ['tenant_id','booking_no','guest_name','guest_contact','room_type_id','room_id',
        'check_in','check_out','adults','rate','status','channel'];
    protected $casts = ['check_in' => 'date', 'check_out' => 'date', 'adults' => 'integer', 'rate' => 'decimal:2'];

    public function nights(): int
    {
        return max(1, \Illuminate\Support\Carbon::parse($this->check_in)->diffInDays($this->check_out));
    }
}
