<?php

namespace App\Modules\HotelManagement\Models;

use App\Core\Support\BaseModel;

class Room extends BaseModel
{
    protected $table = 'hotel_rooms';
    protected $fillable = ['tenant_id', 'room_type_id', 'number', 'floor', 'status'];

}
