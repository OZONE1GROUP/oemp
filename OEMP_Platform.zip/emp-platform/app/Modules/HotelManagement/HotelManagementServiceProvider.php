<?php

namespace App\Modules\HotelManagement;

use App\Core\Support\ModuleServiceProvider;

class HotelManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'hotel_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
