<div class="emp-module" data-module="hotel_management">
    <h3>Reservations</h3>
    <p class="text-muted">HotelManagement module &mdash; managed by the EMP platform core.</p>
</div>
