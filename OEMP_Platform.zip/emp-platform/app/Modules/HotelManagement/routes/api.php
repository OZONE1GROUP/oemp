<?php

use Illuminate\Support\Facades\Route;
use App\Modules\HotelManagement\Http\Controllers\RoomController;
use App\Modules\HotelManagement\Http\Controllers\ReservationController;
use App\Modules\HotelManagement\Http\Controllers\FolioController;
use App\Modules\HotelManagement\Http\Controllers\HousekeepingController;
use App\Modules\HotelManagement\Http\Controllers\HotelAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.hotel_management'])
    ->prefix('api/hotel')
    ->group(function () {
        Route::get('room-types', [RoomController::class, 'roomTypes']);
        Route::post('room-types', [RoomController::class, 'storeRoomType']);
        Route::get('rooms', [RoomController::class, 'rooms']);
        Route::post('rooms', [RoomController::class, 'storeRoom']);

        Route::get('reservations', [ReservationController::class, 'index']);
        Route::get('reservations/availability', [ReservationController::class, 'availability']);
        Route::post('reservations', [ReservationController::class, 'store']);
        Route::post('reservations/{reservation}/check-in', [ReservationController::class, 'checkIn']);
        Route::post('reservations/{reservation}/check-out', [ReservationController::class, 'checkOut']);

        Route::get('folios/{folio}', [FolioController::class, 'show']);
        Route::post('folios/{folio}/charge', [FolioController::class, 'charge']);

        Route::get('housekeeping/board', [HousekeepingController::class, 'board']);
        Route::post('housekeeping/{room}', [HousekeepingController::class, 'update']);

        Route::get('analytics/occupancy', [HotelAnalyticsController::class, 'occupancy']);
        Route::get('analytics/adr-revpar', [HotelAnalyticsController::class, 'adrRevpar']);
    });
