<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('hotel_reservations', function (Blueprint $table) {
            foreach ([['guest_contact','str'],['room_type_id','bigint'],['adults','int'],['rate','dec'],['channel','str']] as [$c,$t]) {
                if (! Schema::hasColumn('hotel_reservations', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'int' => $table->integer($c)->default(1),
                        'dec' => $table->decimal($c, 12, 2)->default(0),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('hotel_reservations', function (Blueprint $table) {
            $table->dropColumn(['guest_contact','room_type_id','adults','rate','channel']);
        });
    }
};
