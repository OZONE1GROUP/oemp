<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hotel_room_types', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->decimal('base_rate', 12, 2)->default(0);
            $table->integer('capacity')->default(2);
            $table->timestamps();
        });

        Schema::create('hotel_rooms', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('room_type_id')->constrained('hotel_room_types')->cascadeOnDelete();
            $table->string('number');
            $table->string('floor')->nullable();
            $table->string('status')->default('available');
            $table->timestamps();
        });

        Schema::create('hotel_rate_plans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('room_type_id')->constrained('hotel_room_types')->cascadeOnDelete();
            $table->string('name');
            $table->decimal('rate', 12, 2)->default(0);
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->timestamps();
        });

        Schema::create('hotel_folios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('reservation_id')->constrained('hotel_reservations')->cascadeOnDelete();
            $table->string('status')->default('open');
            $table->decimal('balance', 12, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('hotel_folio_charges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('folio_id')->constrained('hotel_folios')->cascadeOnDelete();
            $table->string('description');
            $table->decimal('amount', 12, 2)->default(0);
            $table->string('type')->default('room');
            $table->timestamps();
        });

        Schema::create('hotel_housekeeping', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('room_id')->constrained('hotel_rooms')->cascadeOnDelete();
            $table->string('status')->default('dirty');
            $table->unsignedBigInteger('assigned_to')->nullable();
            $table->date('date');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hotel_housekeeping');
        Schema::dropIfExists('hotel_folio_charges');
        Schema::dropIfExists('hotel_folios');
        Schema::dropIfExists('hotel_rate_plans');
        Schema::dropIfExists('hotel_rooms');
        Schema::dropIfExists('hotel_room_types');
    }
};
