<div class="emp-module" data-module="hospital_management">
    <h3>Patients</h3>
    <p class="text-muted">HospitalManagement module &mdash; managed by the EMP platform core.</p>
</div>
