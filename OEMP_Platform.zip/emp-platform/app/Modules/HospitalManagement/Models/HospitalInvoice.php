<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class HospitalInvoice extends BaseModel
{
    protected $table = 'hms_invoices';
    protected $fillable = ['tenant_id', 'patient_id', 'encounter_id', 'total', 'amount_paid', 'status'];
    protected $casts = ['total' => 'decimal:2', 'amount_paid' => 'decimal:2'];

}
