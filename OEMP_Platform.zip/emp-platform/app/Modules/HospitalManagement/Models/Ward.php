<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Ward extends BaseModel
{
    protected $table = 'hms_wards';
    protected $fillable = ['tenant_id', 'name', 'type'];

    public function beds(): HasMany
    {
        return $this->hasMany(Bed::class);
    }
}
