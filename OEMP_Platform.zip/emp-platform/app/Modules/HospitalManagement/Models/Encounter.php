<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class Encounter extends BaseModel
{
    protected $table = 'hms_encounters';
    protected $fillable = ['tenant_id', 'patient_id', 'doctor_id', 'type', 'diagnosis', 'notes', 'encounter_at'];
    protected $casts = ['encounter_at' => 'datetime'];

}
