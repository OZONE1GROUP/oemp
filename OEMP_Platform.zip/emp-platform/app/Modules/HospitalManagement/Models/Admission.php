<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class Admission extends BaseModel
{
    protected $table = 'hms_admissions';
    protected $fillable = ['tenant_id', 'patient_id', 'bed_id', 'admitted_at', 'discharged_at', 'status'];
    protected $casts = ['admitted_at' => 'datetime', 'discharged_at' => 'datetime'];

}
