<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class Appointment extends BaseModel
{
    protected $table = 'hms_appointments';
    protected $fillable = ['tenant_id', 'patient_id', 'doctor_id', 'scheduled_at', 'type', 'status'];
    protected $casts = ['scheduled_at' => 'datetime'];

}
