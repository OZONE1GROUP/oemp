<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class Bed extends BaseModel
{
    protected $table = 'hms_beds';
    protected $fillable = ['tenant_id', 'ward_id', 'bed_no', 'status'];

}
