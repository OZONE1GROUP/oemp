<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class ClinicalOrder extends BaseModel
{
    protected $table = 'hms_orders';
    protected $fillable = ['tenant_id', 'encounter_id', 'type', 'item', 'status', 'result', 'ordered_at'];
    protected $casts = ['ordered_at' => 'datetime'];

}
