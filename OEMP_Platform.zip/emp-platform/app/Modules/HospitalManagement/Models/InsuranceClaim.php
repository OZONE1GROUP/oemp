<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class InsuranceClaim extends BaseModel
{
    protected $table = 'hms_claims';
    protected $fillable = ['tenant_id', 'invoice_id', 'payer', 'amount', 'status'];
    protected $casts = ['amount' => 'decimal:2'];

}
