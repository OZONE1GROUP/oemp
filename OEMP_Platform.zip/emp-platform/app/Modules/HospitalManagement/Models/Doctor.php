<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class Doctor extends BaseModel
{
    protected $table = 'hms_doctors';
    protected $fillable = ['tenant_id', 'name', 'specialty', 'department', 'status'];

}
