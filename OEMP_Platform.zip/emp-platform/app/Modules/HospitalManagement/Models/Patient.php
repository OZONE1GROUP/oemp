<?php

namespace App\Modules\HospitalManagement\Models;

use App\Core\Support\BaseModel;

class Patient extends BaseModel
{
    protected $table = 'hospital_patients';
    protected $fillable = ['tenant_id','mrn','first_name','last_name','dob','gender','phone','blood_group','status'];
    protected $casts = ['dob' => 'date'];

    // PHI note: in production, contact fields are encrypted casts and access is audited.
}
