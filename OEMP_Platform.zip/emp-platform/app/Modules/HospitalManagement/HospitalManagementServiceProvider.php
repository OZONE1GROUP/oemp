<?php

namespace App\Modules\HospitalManagement;

use App\Core\Support\ModuleServiceProvider;

class HospitalManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'hospital_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
