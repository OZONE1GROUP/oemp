<?php

use Illuminate\Support\Facades\Route;
use App\Modules\HospitalManagement\Http\Controllers\PatientController;
use App\Modules\HospitalManagement\Http\Controllers\AppointmentController;
use App\Modules\HospitalManagement\Http\Controllers\EncounterController;
use App\Modules\HospitalManagement\Http\Controllers\WardController;
use App\Modules\HospitalManagement\Http\Controllers\BillingController;
use App\Modules\HospitalManagement\Http\Controllers\HospitalAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.hospital_management'])
    ->prefix('api/hospital')
    ->group(function () {
        Route::get('patients', [PatientController::class, 'index']);
        Route::post('patients', [PatientController::class, 'store']);

        Route::get('doctors', [AppointmentController::class, 'doctors']);
        Route::post('doctors', [AppointmentController::class, 'storeDoctor']);
        Route::get('appointments', [AppointmentController::class, 'index']);
        Route::post('appointments', [AppointmentController::class, 'store']);
        Route::post('appointments/{appointment}/status', [AppointmentController::class, 'updateStatus']);

        Route::get('encounters', [EncounterController::class, 'index']);
        Route::post('encounters', [EncounterController::class, 'store']);
        Route::post('encounters/{encounter}/orders', [EncounterController::class, 'order']);
        Route::post('orders/{order}/result', [EncounterController::class, 'resultOrder']);

        Route::get('wards', [WardController::class, 'index']);
        Route::post('wards', [WardController::class, 'storeWard']);
        Route::post('beds', [WardController::class, 'storeBed']);
        Route::post('admissions', [WardController::class, 'admit']);
        Route::post('admissions/{admission}/discharge', [WardController::class, 'discharge']);

        Route::get('invoices', [BillingController::class, 'invoices']);
        Route::post('invoices', [BillingController::class, 'store']);
        Route::post('invoices/{invoice}/pay', [BillingController::class, 'pay']);
        Route::post('invoices/{invoice}/claim', [BillingController::class, 'claim']);

        Route::get('analytics/bed-occupancy', [HospitalAnalyticsController::class, 'bedOccupancy']);
        Route::get('analytics/appointments', [HospitalAnalyticsController::class, 'appointments']);
        Route::get('analytics/revenue', [HospitalAnalyticsController::class, 'revenue']);
    });
