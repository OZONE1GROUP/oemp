<?php

namespace App\Modules\HospitalManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HospitalManagement\Models\Appointment;
use App\Modules\HospitalManagement\Models\Doctor;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    public function index(Request $request)
    {
        return Appointment::when($request->doctor_id, fn ($q) => $q->where('doctor_id', $request->doctor_id))
            ->when($request->date, fn ($q) => $q->whereDate('scheduled_at', $request->date))
            ->latest('scheduled_at')->paginate(50);
    }

    public function doctors()
    {
        return Doctor::orderBy('name')->get();
    }

    public function storeDoctor(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'specialty' => ['nullable', 'string', 'max:80'],
            'department' => ['nullable', 'string', 'max:80'],
        ]);

        return response()->json(Doctor::create(array_merge($data, ['status' => 'active'])), 201);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'patient_id' => ['required', 'integer', 'exists:hospital_patients,id'],
            'doctor_id' => ['required', 'integer', 'exists:hms_doctors,id'],
            'scheduled_at' => ['required', 'date'],
            'type' => ['required', 'in:opd,follow_up,teleconsult'],
        ]);

        return response()->json(Appointment::create(array_merge($data, ['status' => 'scheduled'])), 201);
    }

    public function updateStatus(Request $request, Appointment $appointment)
    {
        $status = $request->validate(['status' => ['required', 'in:scheduled,checked_in,completed,cancelled,no_show']])['status'];
        $appointment->update(['status' => $status]);

        return $appointment;
    }
}
