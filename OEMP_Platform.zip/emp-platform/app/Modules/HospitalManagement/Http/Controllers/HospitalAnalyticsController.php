<?php

namespace App\Modules\HospitalManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class HospitalAnalyticsController extends Controller
{
    /** Bed occupancy. */
    public function bedOccupancy()
    {
        $total = DB::table('hms_beds')->count();
        $occupied = DB::table('hms_beds')->where('status', 'occupied')->count();

        return ['total_beds' => $total, 'occupied' => $occupied, 'occupancy_pct' => $total ? round($occupied / $total * 100, 1) : 0];
    }

    /** Appointments by status (last 30 days). */
    public function appointments()
    {
        return DB::table('hms_appointments')
            ->where('scheduled_at', '>=', now()->subDays(30))
            ->groupBy('status')
            ->select('status', DB::raw('COUNT(*) as count'))
            ->get();
    }

    /** Revenue: billed vs collected. */
    public function revenue()
    {
        return DB::table('hms_invoices')
            ->select(DB::raw('SUM(total) as billed'), DB::raw('SUM(amount_paid) as collected'))
            ->first();
    }
}
