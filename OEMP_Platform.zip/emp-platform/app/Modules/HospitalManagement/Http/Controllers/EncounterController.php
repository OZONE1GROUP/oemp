<?php

namespace App\Modules\HospitalManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HospitalManagement\Models\Encounter;
use App\Modules\HospitalManagement\Models\ClinicalOrder;
use Illuminate\Http\Request;

class EncounterController extends Controller
{
    public function index(Request $request)
    {
        return Encounter::when($request->patient_id, fn ($q) => $q->where('patient_id', $request->patient_id))
            ->latest('encounter_at')->paginate(50);
    }

    /** Create an EMR encounter record. */
    public function store(Request $request)
    {
        $data = $request->validate([
            'patient_id' => ['required', 'integer', 'exists:hospital_patients,id'],
            'doctor_id' => ['nullable', 'integer', 'exists:hms_doctors,id'],
            'type' => ['required', 'in:opd,ipd,emergency'],
            'diagnosis' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
        ]);

        return response()->json(Encounter::create(array_merge($data, ['encounter_at' => now()])), 201);
    }

    /** Place a lab/pharmacy/radiology order under an encounter. */
    public function order(Request $request, Encounter $encounter)
    {
        $data = $request->validate([
            'type' => ['required', 'in:lab,pharmacy,radiology'],
            'item' => ['required', 'string', 'max:150'],
        ]);

        return response()->json(ClinicalOrder::create(array_merge($data, [
            'encounter_id' => $encounter->id, 'status' => 'ordered', 'ordered_at' => now(),
        ])), 201);
    }

    public function resultOrder(Request $request, ClinicalOrder $order)
    {
        $data = $request->validate(['result' => ['required', 'string']]);
        $order->update(['result' => $data['result'], 'status' => 'completed']);

        return $order;
    }
}
