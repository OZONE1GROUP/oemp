<?php

namespace App\Modules\HospitalManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HospitalManagement\Models\Patient;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    public function index(Request $request)
    {
        return Patient::when($request->q, fn ($q) => $q->where('first_name', 'like', "%{$request->q}%")->orWhere('mrn', 'like', "%{$request->q}%"))
            ->orderByDesc('id')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'mrn' => ['required', 'string', 'max:30'],
            'first_name' => ['required', 'string', 'max:80'],
            'last_name' => ['nullable', 'string', 'max:80'],
            'dob' => ['nullable', 'date'],
            'gender' => ['nullable', 'in:male,female,other'],
            'phone' => ['nullable', 'string', 'max:40'],
            'blood_group' => ['nullable', 'string', 'max:5'],
        ]);

        return response()->json(Patient::create(array_merge($data, ['status' => 'active'])), 201);
    }
}
