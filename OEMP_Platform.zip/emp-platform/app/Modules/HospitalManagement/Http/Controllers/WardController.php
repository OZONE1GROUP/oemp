<?php

namespace App\Modules\HospitalManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HospitalManagement\Models\Ward;
use App\Modules\HospitalManagement\Models\Bed;
use App\Modules\HospitalManagement\Models\Admission;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class WardController extends Controller
{
    public function index()
    {
        return Ward::with('beds')->get();
    }

    public function storeWard(Request $request)
    {
        $data = $request->validate(['name' => ['required', 'string', 'max:80'], 'type' => ['nullable', 'in:general,private,icu,maternity']]);

        return response()->json(Ward::create($data), 201);
    }

    public function storeBed(Request $request)
    {
        $data = $request->validate([
            'ward_id' => ['required', 'integer', 'exists:hms_wards,id'],
            'bed_no' => ['required', 'string', 'max:20'],
        ]);

        return response()->json(Bed::create(array_merge($data, ['status' => 'available'])), 201);
    }

    /** Admit a patient to an available bed (IPD). */
    public function admit(Request $request)
    {
        $data = $request->validate([
            'patient_id' => ['required', 'integer', 'exists:hospital_patients,id'],
            'bed_id' => ['required', 'integer', 'exists:hms_beds,id'],
        ]);

        return DB::transaction(function () use ($data) {
            $bed = Bed::lockForUpdate()->findOrFail($data['bed_id']);
            abort_unless($bed->status === 'available', 422, 'Bed is not available.');
            $bed->update(['status' => 'occupied']);

            return response()->json(Admission::create([
                'patient_id' => $data['patient_id'], 'bed_id' => $bed->id,
                'admitted_at' => now(), 'status' => 'admitted',
            ]), 201);
        });
    }

    public function discharge(Admission $admission)
    {
        abort_unless($admission->status === 'admitted', 422, 'Not an active admission.');
        $admission->update(['discharged_at' => now(), 'status' => 'discharged']);
        Bed::where('id', $admission->bed_id)->update(['status' => 'available']);

        return $admission;
    }
}
