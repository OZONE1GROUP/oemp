<?php

namespace App\Modules\HospitalManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HospitalManagement\Models\HospitalInvoice;
use App\Modules\HospitalManagement\Models\InsuranceClaim;
use Illuminate\Http\Request;

class BillingController extends Controller
{
    public function invoices(Request $request)
    {
        return HospitalInvoice::when($request->patient_id, fn ($q) => $q->where('patient_id', $request->patient_id))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'patient_id' => ['required', 'integer', 'exists:hospital_patients,id'],
            'encounter_id' => ['nullable', 'integer', 'exists:hms_encounters,id'],
            'total' => ['required', 'numeric', 'min:0'],
        ]);

        return response()->json(HospitalInvoice::create(array_merge($data, ['amount_paid' => 0, 'status' => 'open'])), 201);
    }

    public function pay(Request $request, HospitalInvoice $invoice)
    {
        $amount = $request->validate(['amount' => ['required', 'numeric', 'min:0.01']])['amount'];
        abort_if($amount > ($invoice->total - $invoice->amount_paid), 422, 'Payment exceeds balance.');
        $paid = $invoice->amount_paid + $amount;
        $invoice->update(['amount_paid' => $paid, 'status' => $paid >= $invoice->total ? 'paid' : 'partial']);

        return $invoice;
    }

    /** File an insurance claim against an invoice. */
    public function claim(Request $request, HospitalInvoice $invoice)
    {
        $data = $request->validate([
            'payer' => ['required', 'string', 'max:120'],
            'amount' => ['required', 'numeric', 'min:0'],
        ]);

        return response()->json(InsuranceClaim::create(array_merge($data, [
            'invoice_id' => $invoice->id, 'status' => 'submitted',
        ])), 201);
    }
}
