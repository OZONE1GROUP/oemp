<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hms_doctors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('specialty')->nullable();
            $table->string('department')->nullable();
            $table->string('status')->default('active');
            $table->timestamps();
        });

        Schema::create('hms_appointments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('patient_id')->constrained('hospital_patients')->cascadeOnDelete();
            $table->foreignId('doctor_id')->constrained('hms_doctors');
            $table->dateTime('scheduled_at');
            $table->string('type')->default('opd');
            $table->string('status')->default('scheduled');
            $table->timestamps();
        });

        Schema::create('hms_encounters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('patient_id')->constrained('hospital_patients')->cascadeOnDelete();
            $table->unsignedBigInteger('doctor_id')->nullable();
            $table->string('type')->default('opd');
            $table->text('diagnosis')->nullable();
            $table->text('notes')->nullable();
            $table->dateTime('encounter_at');
            $table->timestamps();
        });

        Schema::create('hms_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('encounter_id')->constrained('hms_encounters')->cascadeOnDelete();
            $table->string('type');
            $table->string('item');
            $table->string('status')->default('ordered');
            $table->text('result')->nullable();
            $table->dateTime('ordered_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hms_orders');
        Schema::dropIfExists('hms_encounters');
        Schema::dropIfExists('hms_appointments');
        Schema::dropIfExists('hms_doctors');
    }
};
