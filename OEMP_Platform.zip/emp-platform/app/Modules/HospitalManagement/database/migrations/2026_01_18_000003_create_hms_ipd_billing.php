<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hms_wards', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('type')->default('general');
            $table->timestamps();
        });

        Schema::create('hms_beds', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('ward_id')->constrained('hms_wards')->cascadeOnDelete();
            $table->string('bed_no');
            $table->string('status')->default('available');
            $table->timestamps();
        });

        Schema::create('hms_admissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('patient_id')->constrained('hospital_patients')->cascadeOnDelete();
            $table->foreignId('bed_id')->constrained('hms_beds');
            $table->dateTime('admitted_at');
            $table->dateTime('discharged_at')->nullable();
            $table->string('status')->default('admitted');
            $table->timestamps();
        });

        Schema::create('hms_invoices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('patient_id')->constrained('hospital_patients')->cascadeOnDelete();
            $table->unsignedBigInteger('encounter_id')->nullable();
            $table->decimal('total', 15, 2)->default(0);
            $table->decimal('amount_paid', 15, 2)->default(0);
            $table->string('status')->default('open');
            $table->timestamps();
        });

        Schema::create('hms_claims', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('invoice_id')->constrained('hms_invoices')->cascadeOnDelete();
            $table->string('payer');
            $table->decimal('amount', 15, 2)->default(0);
            $table->string('status')->default('submitted');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hms_claims');
        Schema::dropIfExists('hms_invoices');
        Schema::dropIfExists('hms_admissions');
        Schema::dropIfExists('hms_beds');
        Schema::dropIfExists('hms_wards');
    }
};
