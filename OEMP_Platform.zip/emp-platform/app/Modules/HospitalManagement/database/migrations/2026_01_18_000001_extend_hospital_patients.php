<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('hospital_patients', function (Blueprint $table) {
            foreach ([['gender','str'],['phone','str'],['blood_group','str']] as [$c,$t]) {
                if (! Schema::hasColumn('hospital_patients', $c)) {
                    $table->string($c)->nullable();
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('hospital_patients', function (Blueprint $table) {
            $table->dropColumn(['gender', 'phone', 'blood_group']);
        });
    }
};
