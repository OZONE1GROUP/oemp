<?php

namespace App\Modules\Inventory;

use App\Core\Support\ModuleServiceProvider;

class InventoryServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'inventory';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
