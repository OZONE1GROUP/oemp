<div class="emp-module" data-module="inventory">
    <h3>Items</h3>
    <p class="text-muted">Inventory module &mdash; managed by the EMP platform core.</p>
</div>
