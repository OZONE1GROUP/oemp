<?php

namespace App\Modules\Inventory\Models;

use App\Core\Support\BaseModel;

class Location extends BaseModel
{
    protected $table = 'inventory_locations';
    protected $fillable = ['tenant_id', 'code', 'name', 'type'];

}
