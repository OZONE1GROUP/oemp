<?php

namespace App\Modules\Inventory\Models;

use App\Core\Support\BaseModel;

class ItemCategory extends BaseModel
{
    protected $table = 'inventory_categories';
    protected $fillable = ['tenant_id', 'code', 'name', 'parent_id'];

}
