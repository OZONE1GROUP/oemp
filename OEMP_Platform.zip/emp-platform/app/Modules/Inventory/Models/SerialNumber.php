<?php

namespace App\Modules\Inventory\Models;

use App\Core\Support\BaseModel;

class SerialNumber extends BaseModel
{
    protected $table = 'inventory_serials';
    protected $fillable = ['tenant_id', 'item_id', 'serial', 'location_id', 'status'];

}
