<?php

namespace App\Modules\Inventory\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Item extends BaseModel
{
    protected $table = 'inventory_items';
    protected $fillable = ['tenant_id','sku','name','category_id','uom','cost','price',
        'track_batch','track_serial','reorder_point','reorder_qty','on_hand','status'];
    protected $casts = ['cost' => 'decimal:4', 'price' => 'decimal:2',
        'track_batch' => 'boolean', 'track_serial' => 'boolean',
        'reorder_point' => 'integer', 'reorder_qty' => 'integer', 'on_hand' => 'integer'];

    public function stockLevels(): HasMany
    {
        return $this->hasMany(StockLevel::class);
    }
}
