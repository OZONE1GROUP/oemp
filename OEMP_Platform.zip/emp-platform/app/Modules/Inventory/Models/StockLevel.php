<?php

namespace App\Modules\Inventory\Models;

use App\Core\Support\BaseModel;

class StockLevel extends BaseModel
{
    protected $table = 'inventory_stock_levels';
    protected $fillable = ['tenant_id', 'item_id', 'location_id', 'on_hand', 'allocated'];
    protected $casts = ['on_hand' => 'decimal:2', 'allocated' => 'decimal:2'];

    public function getAvailableAttribute(): float
    {
        return (float) $this->on_hand - (float) $this->allocated;
    }
}
