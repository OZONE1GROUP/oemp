<?php

namespace App\Modules\Inventory\Models;

use App\Core\Support\BaseModel;

class StockMovement extends BaseModel
{
    protected $table = 'inventory_movements';
    protected $fillable = ['tenant_id', 'item_id', 'location_id', 'to_location_id', 'type', 'qty', 'unit_cost', 'reference', 'moved_at'];
    protected $casts = ['qty' => 'decimal:2', 'unit_cost' => 'decimal:4', 'moved_at' => 'datetime'];

}
