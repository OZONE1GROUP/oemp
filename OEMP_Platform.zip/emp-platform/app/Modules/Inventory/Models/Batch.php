<?php

namespace App\Modules\Inventory\Models;

use App\Core\Support\BaseModel;

class Batch extends BaseModel
{
    protected $table = 'inventory_batches';
    protected $fillable = ['tenant_id', 'item_id', 'batch_no', 'expiry', 'qty'];
    protected $casts = ['expiry' => 'date', 'qty' => 'decimal:2'];

}
