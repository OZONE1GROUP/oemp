<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('inventory_items', function (Blueprint $table) {
            foreach ([['category_id','bigint'],['cost','cost'],['price','dec'],['track_batch','bool'],['track_serial','bool'],['reorder_qty','int'],['status','str']] as [$c,$t]) {
                if (! Schema::hasColumn('inventory_items', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'cost' => $table->decimal($c, 15, 4)->default(0),
                        'dec' => $table->decimal($c, 15, 2)->default(0),
                        'bool' => $table->boolean($c)->default(false),
                        'int' => $table->integer($c)->default(0),
                        default => $table->string($c)->default('active'),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('inventory_items', function (Blueprint $table) {
            $table->dropColumn(['category_id','cost','price','track_batch','track_serial','reorder_qty','status']);
        });
    }
};
