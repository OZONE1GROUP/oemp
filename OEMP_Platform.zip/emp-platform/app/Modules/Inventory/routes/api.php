<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Inventory\Http\Controllers\ItemController;
use App\Modules\Inventory\Http\Controllers\CategoryController;
use App\Modules\Inventory\Http\Controllers\LocationController;
use App\Modules\Inventory\Http\Controllers\StockController;
use App\Modules\Inventory\Http\Controllers\InventoryAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.inventory'])
    ->prefix('api/inventory')
    ->group(function () {
        // Items & catalogue
        Route::get('items', [ItemController::class, 'index']);
        Route::post('items', [ItemController::class, 'store']);
        Route::get('items/{item}', [ItemController::class, 'show']);
        Route::get('categories', [CategoryController::class, 'index']);
        Route::post('categories', [CategoryController::class, 'store']);
        Route::get('locations', [LocationController::class, 'index']);
        Route::post('locations', [LocationController::class, 'store']);

        // Stock operations
        Route::get('stock', [StockController::class, 'levels']);
        Route::post('stock/receive', [StockController::class, 'receive']);
        Route::post('stock/issue', [StockController::class, 'issue']);
        Route::post('stock/adjust', [StockController::class, 'adjust']);
        Route::post('stock/transfer', [StockController::class, 'transfer']);

        // Analytics
        Route::get('analytics/valuation', [InventoryAnalyticsController::class, 'valuation']);
        Route::get('analytics/low-stock', [InventoryAnalyticsController::class, 'lowStock']);
        Route::get('analytics/movement-volume', [InventoryAnalyticsController::class, 'movementVolume']);
    });
