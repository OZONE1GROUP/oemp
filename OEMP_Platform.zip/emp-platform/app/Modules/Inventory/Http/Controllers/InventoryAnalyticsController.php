<?php

namespace App\Modules\Inventory\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Inventory\Models\Item;
use Illuminate\Support\Facades\DB;

class InventoryAnalyticsController extends Controller
{
    /** Total inventory valuation (on_hand x moving-average cost). */
    public function valuation()
    {
        $value = Item::sum(DB::raw('on_hand * cost'));

        return ['total_value' => round((float) $value, 2), 'sku_count' => Item::count()];
    }

    /** Items at or below their reorder point. */
    public function lowStock()
    {
        return Item::whereColumn('on_hand', '<=', 'reorder_point')
            ->where('reorder_point', '>', 0)
            ->get(['id', 'sku', 'name', 'on_hand', 'reorder_point', 'reorder_qty']);
    }

    /** Movement volume by type over the last 30 days. */
    public function movementVolume()
    {
        return DB::table('inventory_movements')
            ->where('moved_at', '>=', now()->subDays(30))
            ->groupBy('type')
            ->select('type', DB::raw('COUNT(*) as movements'), DB::raw('SUM(qty) as qty'))
            ->get();
    }
}
