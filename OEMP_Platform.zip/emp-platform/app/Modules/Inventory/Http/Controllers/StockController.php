<?php

namespace App\Modules\Inventory\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Inventory\Models\StockLevel;
use App\Modules\Inventory\Services\StockService;
use Illuminate\Http\Request;

class StockController extends Controller
{
    public function __construct(private StockService $stock) {}

    public function levels(Request $request)
    {
        return StockLevel::with('item:id,sku,name')
            ->when($request->item_id, fn ($q) => $q->where('item_id', $request->item_id))
            ->when($request->location_id, fn ($q) => $q->where('location_id', $request->location_id))
            ->paginate(100);
    }

    public function receive(Request $request)
    {
        $d = $request->validate([
            'item_id' => ['required', 'integer', 'exists:inventory_items,id'],
            'location_id' => ['required', 'integer', 'exists:inventory_locations,id'],
            'qty' => ['required', 'numeric', 'gt:0'],
            'unit_cost' => ['required', 'numeric', 'min:0'],
            'reference' => ['nullable', 'string'],
        ]);

        return response()->json($this->stock->applyMovement($d['item_id'], $d['location_id'], 'receipt', $d['qty'], $d['unit_cost'], $d['reference'] ?? null), 201);
    }

    public function issue(Request $request)
    {
        $d = $request->validate([
            'item_id' => ['required', 'integer', 'exists:inventory_items,id'],
            'location_id' => ['required', 'integer', 'exists:inventory_locations,id'],
            'qty' => ['required', 'numeric', 'gt:0'],
            'reference' => ['nullable', 'string'],
        ]);

        return response()->json($this->stock->applyMovement($d['item_id'], $d['location_id'], 'issue', $d['qty'], 0, $d['reference'] ?? null), 201);
    }

    public function adjust(Request $request)
    {
        $d = $request->validate([
            'item_id' => ['required', 'integer', 'exists:inventory_items,id'],
            'location_id' => ['required', 'integer', 'exists:inventory_locations,id'],
            'qty' => ['required', 'numeric'],
            'reference' => ['nullable', 'string'],
        ]);

        return response()->json($this->stock->applyMovement($d['item_id'], $d['location_id'], 'adjust', $d['qty'], 0, $d['reference'] ?? 'manual adjustment'), 201);
    }

    public function transfer(Request $request)
    {
        $d = $request->validate([
            'item_id' => ['required', 'integer', 'exists:inventory_items,id'],
            'from_location_id' => ['required', 'integer', 'exists:inventory_locations,id'],
            'to_location_id' => ['required', 'integer', 'different:from_location_id', 'exists:inventory_locations,id'],
            'qty' => ['required', 'numeric', 'gt:0'],
        ]);
        $this->stock->transfer($d['item_id'], $d['from_location_id'], $d['to_location_id'], $d['qty'], 'transfer');

        return response()->json(['status' => 'transferred'], 201);
    }
}
