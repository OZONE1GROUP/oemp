<?php

namespace App\Modules\Inventory\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Inventory\Models\Item;
use Illuminate\Http\Request;

class ItemController extends Controller
{
    public function index(Request $request)
    {
        return Item::when($request->q, fn ($q) => $q->where('name', 'like', "%{$request->q}%")->orWhere('sku', 'like', "%{$request->q}%"))
            ->orderBy('name')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'sku' => ['required', 'string', 'max:40'],
            'name' => ['required', 'string', 'max:150'],
            'category_id' => ['nullable', 'integer', 'exists:inventory_categories,id'],
            'uom' => ['required', 'string', 'max:10'],
            'cost' => ['nullable', 'numeric', 'min:0'],
            'price' => ['nullable', 'numeric', 'min:0'],
            'track_batch' => ['boolean'],
            'track_serial' => ['boolean'],
            'reorder_point' => ['nullable', 'integer', 'min:0'],
            'reorder_qty' => ['nullable', 'integer', 'min:0'],
        ]);

        return response()->json(Item::create(array_merge($data, ['on_hand' => 0, 'status' => 'active'])), 201);
    }

    public function show(Item $item)
    {
        return $item->load('stockLevels');
    }
}
