<?php

namespace App\Modules\Inventory\Services;

use App\Modules\Inventory\Models\Item;
use App\Modules\Inventory\Models\StockLevel;
use App\Modules\Inventory\Models\StockMovement;
use App\Core\Events\EventBus;
use Illuminate\Support\Facades\DB;

/**
 * Central stock engine. All quantity changes go through applyMovement so stock
 * levels, item moving-average cost and the movement ledger stay consistent.
 */
class StockService
{
    public function __construct(private EventBus $bus) {}

    private function level(int $itemId, int $locationId): StockLevel
    {
        return StockLevel::firstOrCreate(
            ['item_id' => $itemId, 'location_id' => $locationId],
            ['on_hand' => 0, 'allocated' => 0]
        );
    }

    /** type: receipt | issue | adjust. Returns the movement. */
    public function applyMovement(int $itemId, int $locationId, string $type, float $qty, float $unitCost = 0, ?string $ref = null): StockMovement
    {
        return DB::transaction(function () use ($itemId, $locationId, $type, $qty, $unitCost, $ref) {
            $level = $this->level($itemId, $locationId);
            $item = Item::findOrFail($itemId);

            if ($type === 'receipt') {
                // moving-average cost
                $oldQty = (float) $item->on_hand;
                $oldVal = $oldQty * (float) $item->cost;
                $newQty = $oldQty + $qty;
                $item->cost = $newQty > 0 ? round(($oldVal + $qty * $unitCost) / $newQty, 4) : $unitCost;
                $item->on_hand = $newQty;
                $item->save();
                $level->increment('on_hand', $qty);
            } elseif ($type === 'issue') {
                abort_if($qty > (float) $level->on_hand, 422, 'Insufficient stock at location.');
                $item->decrement('on_hand', $qty);
                $level->decrement('on_hand', $qty);
                $unitCost = (float) $item->cost;
            } else { // adjust (signed qty)
                $item->increment('on_hand', $qty);
                $level->increment('on_hand', $qty);
            }

            $movement = StockMovement::create([
                'item_id' => $itemId, 'location_id' => $locationId, 'type' => $type,
                'qty' => $qty, 'unit_cost' => $unitCost, 'reference' => $ref, 'moved_at' => now(),
            ]);

            $this->bus->publish('inventory.stock.moved', ['item_id' => $itemId, 'type' => $type, 'qty' => $qty]);
            $this->checkReorder($item->fresh());

            return $movement;
        });
    }

    public function transfer(int $itemId, int $fromLoc, int $toLoc, float $qty, ?string $ref = null): void
    {
        $this->applyMovement($itemId, $fromLoc, 'issue', $qty, 0, $ref);
        $item = Item::find($itemId);
        $this->applyMovement($itemId, $toLoc, 'receipt', $qty, (float) $item->cost, $ref);
    }

    private function checkReorder(Item $item): void
    {
        if ($item->reorder_point > 0 && $item->on_hand <= $item->reorder_point) {
            $this->bus->publish('inventory.reorder.triggered', ['item_id' => $item->id, 'sku' => $item->sku, 'on_hand' => $item->on_hand]);
        }
    }
}
