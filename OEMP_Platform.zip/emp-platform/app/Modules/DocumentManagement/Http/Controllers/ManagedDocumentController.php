<?php

namespace App\Modules\DocumentManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\DocumentManagement\Models\ManagedDocument;
use Illuminate\Http\Request;

class ManagedDocumentController extends Controller
{
    public function index(Request $request)
    {
        return ManagedDocument::query()
            ->when($request->q, fn ($qq) => $qq->where('title', 'like', "%{$request->q}%"))
            ->latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'nullable|string|max:255',
            'version' => 'nullable|string|max:255',
            'owner' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
        ]);

        return response()->json(ManagedDocument::create($data), 201);
    }

    public function show(ManagedDocument $document_managementItem)
    {
        return $document_managementItem;
    }

    public function update(Request $request, ManagedDocument $document_managementItem)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'nullable|string|max:255',
            'version' => 'nullable|string|max:255',
            'owner' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
        ]);
        $document_managementItem->update($data);

        return $document_managementItem;
    }

    public function destroy(ManagedDocument $document_managementItem)
    {
        $document_managementItem->delete();

        return response()->noContent();
    }
}
