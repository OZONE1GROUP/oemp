<?php

namespace App\Modules\DocumentManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\DocumentManagement\Models\ManagedDocument;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class DocumentController extends Controller
{
    public function index(Request $request)
    {
        return ManagedDocument::with('versions')
            ->when($request->folder_id, fn ($q) => $q->where('folder_id', $request->folder_id))
            ->when($request->q, fn ($q) => $q->where('title', 'like', "%{$request->q}%"))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:200'],
            'folder_id' => ['nullable', 'integer', 'exists:dms_folders,id'],
            'category' => ['nullable', 'string', 'max:80'],
            'file_ref' => ['nullable', 'string', 'max:255'],
        ]);
        $doc = ManagedDocument::create([
            'title' => $data['title'], 'folder_id' => $data['folder_id'] ?? null,
            'category' => $data['category'] ?? null, 'current_version' => 1,
            'owner' => $request->user()?->name, 'status' => 'active',
        ]);
        $doc->versions()->create([
            'version' => 1, 'file_ref' => $data['file_ref'] ?? null,
            'uploaded_by' => $request->user()?->name, 'uploaded_at' => now(),
        ]);

        return response()->json($doc->load('versions'), 201);
    }

    /** Check out a document (exclusive lock). */
    public function checkout(Request $request, ManagedDocument $document)
    {
        abort_if($document->locked_by, 423, "Locked by {$document->locked_by}.");
        $document->update(['locked_by' => $request->user()?->name ?? 'user']);

        return $document;
    }

    /** Check in a new version and release the lock. */
    public function checkin(Request $request, ManagedDocument $document, EventBus $bus)
    {
        $data = $request->validate(['file_ref' => ['nullable', 'string'], 'notes' => ['nullable', 'string']]);
        $next = $document->current_version + 1;
        $document->versions()->create([
            'version' => $next, 'file_ref' => $data['file_ref'] ?? null,
            'uploaded_by' => $request->user()?->name, 'uploaded_at' => now(), 'notes' => $data['notes'] ?? null,
        ]);
        $document->update(['current_version' => $next, 'locked_by' => null]);
        $bus->publish('dms.document.versioned', ['id' => $document->id, 'version' => $next]);

        return $document->load('versions');
    }
}
