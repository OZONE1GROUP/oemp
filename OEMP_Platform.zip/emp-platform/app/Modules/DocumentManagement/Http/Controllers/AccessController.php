<?php

namespace App\Modules\DocumentManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\DocumentManagement\Models\ManagedDocument;
use Illuminate\Http\Request;

class AccessController extends Controller
{
    public function grant(Request $request, ManagedDocument $document)
    {
        $data = $request->validate([
            'principal' => ['required', 'string', 'max:120'],
            'permission' => ['required', 'in:view,edit,manage'],
        ]);

        return response()->json($document->accesses()->create($data), 201);
    }

    public function list(ManagedDocument $document)
    {
        return $document->accesses;
    }
}
