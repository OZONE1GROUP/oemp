<?php

namespace App\Modules\DocumentManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class DmsAnalyticsController extends Controller
{
    public function byCategory()
    {
        return DB::table('dms_documents')->groupBy('category')->select('category', DB::raw('COUNT(*) as count'))->get();
    }

    public function storage()
    {
        $kb = DB::table('dms_versions')->sum('size_kb');

        return ['documents' => DB::table('dms_documents')->count(), 'versions' => DB::table('dms_versions')->count(), 'storage_mb' => round((float) $kb / 1024, 2)];
    }
}
