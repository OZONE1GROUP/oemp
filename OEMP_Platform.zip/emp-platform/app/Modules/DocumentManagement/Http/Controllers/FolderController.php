<?php

namespace App\Modules\DocumentManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\DocumentManagement\Models\Folder;
use Illuminate\Http\Request;

class FolderController extends Controller
{
    public function index()
    {
        return Folder::orderBy('path')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'parent_id' => ['nullable', 'integer', 'exists:dms_folders,id'],
        ]);
        $parentPath = $data['parent_id'] ? optional(Folder::find($data['parent_id']))->path : '';
        $data['path'] = trim($parentPath . '/' . $data['name'], '/');

        return response()->json(Folder::create($data), 201);
    }
}
