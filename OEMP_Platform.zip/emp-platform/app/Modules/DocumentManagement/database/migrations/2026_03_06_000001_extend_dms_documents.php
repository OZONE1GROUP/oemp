<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('dms_documents', function (Blueprint $table) {
            foreach ([['folder_id','bigint'],['current_version','int'],['locked_by','str']] as [$c,$t]) {
                if (! Schema::hasColumn('dms_documents', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'int' => $table->integer($c)->default(1),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('dms_documents', function (Blueprint $table) {
            $table->dropColumn(['folder_id', 'current_version', 'locked_by']);
        });
    }
};
