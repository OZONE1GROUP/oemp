<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('dms_folders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->string('path')->nullable();
            $table->timestamps();
        });

        Schema::create('dms_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('document_id')->constrained('dms_documents')->cascadeOnDelete();
            $table->integer('version')->default(1);
            $table->string('file_ref')->nullable();
            $table->integer('size_kb')->default(0);
            $table->string('uploaded_by')->nullable();
            $table->timestamp('uploaded_at')->nullable();
            $table->string('notes')->nullable();
        });

        Schema::create('dms_access', function (Blueprint $table) {
            $table->id();
            $table->foreignId('document_id')->constrained('dms_documents')->cascadeOnDelete();
            $table->string('principal');
            $table->string('permission')->default('view');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dms_access');
        Schema::dropIfExists('dms_versions');
        Schema::dropIfExists('dms_folders');
    }
};
