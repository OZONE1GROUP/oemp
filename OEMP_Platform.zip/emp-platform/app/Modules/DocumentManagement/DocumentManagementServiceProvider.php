<?php

namespace App\Modules\DocumentManagement;

use App\Core\Support\ModuleServiceProvider;

class DocumentManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'document_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
