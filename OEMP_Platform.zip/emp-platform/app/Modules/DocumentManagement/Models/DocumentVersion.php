<?php

namespace App\Modules\DocumentManagement\Models;

use App\Core\Support\BaseModel;

class DocumentVersion extends BaseModel
{
    protected $table = 'dms_versions';
    protected $fillable = ['tenant_id', 'document_id', 'version', 'file_ref', 'size_kb', 'uploaded_by', 'uploaded_at', 'notes'];
    protected $casts = ['version' => 'integer', 'size_kb' => 'integer', 'uploaded_at' => 'datetime'];

}
