<?php

namespace App\Modules\DocumentManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ManagedDocument extends BaseModel
{
    protected $table = 'dms_documents';
    protected $fillable = ['tenant_id','title','folder_id','category','current_version','owner','status','locked_by'];
    protected $casts = ['current_version' => 'integer'];

    public function versions(): HasMany
    {
        return $this->hasMany(DocumentVersion::class, 'document_id');
    }

    public function accesses(): HasMany
    {
        return $this->hasMany(DocumentAccess::class, 'document_id');
    }
}
