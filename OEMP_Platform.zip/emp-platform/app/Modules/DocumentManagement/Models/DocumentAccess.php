<?php

namespace App\Modules\DocumentManagement\Models;

use App\Core\Support\BaseModel;

class DocumentAccess extends BaseModel
{
    protected $table = 'dms_access';
    protected $fillable = ['tenant_id', 'document_id', 'principal', 'permission'];

}
