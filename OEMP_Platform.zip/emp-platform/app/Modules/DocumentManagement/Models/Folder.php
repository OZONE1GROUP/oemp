<?php

namespace App\Modules\DocumentManagement\Models;

use App\Core\Support\BaseModel;

class Folder extends BaseModel
{
    protected $table = 'dms_folders';
    protected $fillable = ['tenant_id', 'name', 'parent_id', 'path'];

}
