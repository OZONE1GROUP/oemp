<?php

use Illuminate\Support\Facades\Route;
use App\Modules\DocumentManagement\Http\Controllers\FolderController;
use App\Modules\DocumentManagement\Http\Controllers\DocumentController;
use App\Modules\DocumentManagement\Http\Controllers\AccessController;
use App\Modules\DocumentManagement\Http\Controllers\DmsAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.document_management'])
    ->prefix('api/dms')
    ->group(function () {
        Route::get('folders', [FolderController::class, 'index']);
        Route::post('folders', [FolderController::class, 'store']);

        Route::get('documents', [DocumentController::class, 'index']);
        Route::post('documents', [DocumentController::class, 'store']);
        Route::post('documents/{document}/checkout', [DocumentController::class, 'checkout']);
        Route::post('documents/{document}/checkin', [DocumentController::class, 'checkin']);
        Route::post('documents/{document}/access', [AccessController::class, 'grant']);
        Route::get('documents/{document}/access', [AccessController::class, 'list']);

        Route::get('analytics/by-category', [DmsAnalyticsController::class, 'byCategory']);
        Route::get('analytics/storage', [DmsAnalyticsController::class, 'storage']);
    });
