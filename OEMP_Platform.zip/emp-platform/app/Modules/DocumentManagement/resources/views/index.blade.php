<div class="emp-module" data-module="document_management">
    <h3>ManagedDocuments</h3>
    <p class="text-muted">DocumentManagement module &mdash; managed by the EMP platform core.</p>
</div>
