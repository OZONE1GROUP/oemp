<?php

namespace App\Modules\BusinessIntelligence\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Safe aggregate query runner. Validates table + column existence against the
 * live schema (guarding against injection / unknown objects) before executing.
 * Aggregates limited to a whitelist.
 */
class QueryRunner
{
    private array $aggregates = ['count', 'sum', 'avg', 'min', 'max'];

    public function aggregate(string $table, string $aggregate, ?string $measure = null, ?string $groupBy = null, array $filter = []): mixed
    {
        abort_unless(Schema::hasTable($table), 422, 'Unknown source table.');
        $aggregate = strtolower($aggregate);
        abort_unless(in_array($aggregate, $this->aggregates, true), 422, 'Unsupported aggregate.');

        $query = DB::table($table);
        if (! empty($filter['column']) && Schema::hasColumn($table, $filter['column'])) {
            $query->where($filter['column'], $filter['op'] ?? '=', $filter['value'] ?? null);
        }

        if ($aggregate !== 'count') {
            abort_unless($measure && Schema::hasColumn($table, $measure), 422, 'Unknown measure column.');
        }
        $expr = $aggregate === 'count' ? 'COUNT(*)' : strtoupper($aggregate) . "(`$measure`)";

        if ($groupBy && Schema::hasColumn($table, $groupBy)) {
            return $query->select($groupBy)->selectRaw("$expr as value")->groupBy($groupBy)->limit(500)->get();
        }

        return ['value' => (float) $query->selectRaw("$expr as value")->value('value')];
    }
}
