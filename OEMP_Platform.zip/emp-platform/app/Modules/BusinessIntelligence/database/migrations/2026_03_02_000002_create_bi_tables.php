<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bi_data_sources', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('type')->default('table');
            $table->string('source_table');
            $table->json('config')->nullable();
            $table->timestamps();
        });

        Schema::create('bi_kpis', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('source_table');
            $table->string('measure')->nullable();
            $table->string('aggregate')->default('count');
            $table->string('filter_column')->nullable();
            $table->string('filter_value')->nullable();
            $table->decimal('target', 18, 2)->nullable();
            $table->timestamps();
        });

        Schema::create('bi_widgets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dashboard_id')->constrained('bi_dashboards')->cascadeOnDelete();
            $table->unsignedBigInteger('kpi_id')->nullable();
            $table->string('title');
            $table->string('type')->default('metric');
            $table->json('config')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bi_widgets');
        Schema::dropIfExists('bi_kpis');
        Schema::dropIfExists('bi_data_sources');
    }
};
