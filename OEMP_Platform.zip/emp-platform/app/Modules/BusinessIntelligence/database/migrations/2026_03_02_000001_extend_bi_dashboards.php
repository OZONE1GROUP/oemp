<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bi_dashboards', function (Blueprint $table) {
            if (! Schema::hasColumn('bi_dashboards', 'layout')) {
                $table->json('layout')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('bi_dashboards', function (Blueprint $table) {
            $table->dropColumn('layout');
        });
    }
};
