<?php

namespace App\Modules\BusinessIntelligence;

use App\Core\Support\ModuleServiceProvider;

class BusinessIntelligenceServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'business_intelligence';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
