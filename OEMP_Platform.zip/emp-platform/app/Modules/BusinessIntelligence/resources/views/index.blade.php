<div class="emp-module" data-module="business_intelligence">
    <h3>Dashboards</h3>
    <p class="text-muted">BusinessIntelligence module &mdash; managed by the EMP platform core.</p>
</div>
