<?php

namespace App\Modules\BusinessIntelligence\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\BusinessIntelligence\Models\Kpi;
use App\Modules\BusinessIntelligence\Services\QueryRunner;
use Illuminate\Http\Request;

class KpiController extends Controller
{
    public function index()
    {
        return Kpi::get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'source_table' => ['required', 'string', 'max:80'],
            'measure' => ['nullable', 'string', 'max:60'],
            'aggregate' => ['required', 'in:count,sum,avg,min,max'],
            'filter_column' => ['nullable', 'string', 'max:60'],
            'filter_value' => ['nullable', 'string'],
            'target' => ['nullable', 'numeric'],
        ]);

        return response()->json(Kpi::create($data), 201);
    }

    /** Compute the current KPI value vs target. */
    public function value(Kpi $kpi, QueryRunner $runner)
    {
        $filter = $kpi->filter_column ? ['column' => $kpi->filter_column, 'value' => $kpi->filter_value] : [];
        $result = $runner->aggregate($kpi->source_table, $kpi->aggregate, $kpi->measure, null, $filter);
        $value = is_array($result) ? ($result['value'] ?? 0) : 0;

        return [
            'kpi' => $kpi->name,
            'value' => round((float) $value, 2),
            'target' => $kpi->target,
            'attainment_pct' => $kpi->target ? round((float) $value / (float) $kpi->target * 100, 1) : null,
        ];
    }
}
