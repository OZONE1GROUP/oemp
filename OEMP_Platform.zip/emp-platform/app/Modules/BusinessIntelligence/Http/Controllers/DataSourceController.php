<?php

namespace App\Modules\BusinessIntelligence\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\BusinessIntelligence\Models\DataSource;
use Illuminate\Support\Facades\Schema;
use Illuminate\Http\Request;

class DataSourceController extends Controller
{
    public function index()
    {
        return DataSource::get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'type' => ['required', 'in:table,view,connection'],
            'source_table' => ['required', 'string', 'max:80'],
        ]);
        abort_unless(Schema::hasTable($data['source_table']), 422, 'Source table does not exist.');

        return response()->json(DataSource::create($data), 201);
    }

    /** Introspect a source table's columns for the report/KPI builder. */
    public function columns(Request $request)
    {
        $table = $request->validate(['table' => ['required', 'string']])['table'];
        abort_unless(Schema::hasTable($table), 422, 'Unknown table.');

        return ['table' => $table, 'columns' => Schema::getColumnListing($table)];
    }
}
