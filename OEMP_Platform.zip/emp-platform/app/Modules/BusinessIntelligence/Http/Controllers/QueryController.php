<?php

namespace App\Modules\BusinessIntelligence\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\BusinessIntelligence\Services\QueryRunner;
use Illuminate\Http\Request;

class QueryController extends Controller
{
    /** Ad-hoc safe aggregate query for the explorer. */
    public function run(Request $request, QueryRunner $runner)
    {
        $data = $request->validate([
            'table' => ['required', 'string'],
            'aggregate' => ['required', 'in:count,sum,avg,min,max'],
            'measure' => ['nullable', 'string'],
            'group_by' => ['nullable', 'string'],
            'filter_column' => ['nullable', 'string'],
            'filter_value' => ['nullable', 'string'],
        ]);
        $filter = $data['filter_column'] ? ['column' => $data['filter_column'], 'value' => $data['filter_value'] ?? null] : [];

        return $runner->aggregate($data['table'], $data['aggregate'], $data['measure'] ?? null, $data['group_by'] ?? null, $filter);
    }
}
