<?php

namespace App\Modules\BusinessIntelligence\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\BusinessIntelligence\Models\Dashboard;
use App\Modules\BusinessIntelligence\Models\Widget;
use App\Modules\BusinessIntelligence\Models\Kpi;
use App\Modules\BusinessIntelligence\Services\QueryRunner;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        return Dashboard::withCount('widgets')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'description' => ['nullable', 'string'],
        ]);

        return response()->json(Dashboard::create(array_merge($data, ['owner' => $request->user()?->name])), 201);
    }

    public function addWidget(Request $request, Dashboard $dashboard)
    {
        $data = $request->validate([
            'kpi_id' => ['nullable', 'integer', 'exists:bi_kpis,id'],
            'title' => ['required', 'string', 'max:120'],
            'type' => ['required', 'in:metric,chart,table'],
            'config' => ['nullable', 'array'],
        ]);

        return response()->json($dashboard->widgets()->create($data), 201);
    }

    /** Render a dashboard: compute every widget's KPI value. */
    public function render(Dashboard $dashboard, QueryRunner $runner)
    {
        $widgets = $dashboard->widgets()->get()->map(function ($widget) use ($runner) {
            $out = ['id' => $widget->id, 'title' => $widget->title, 'type' => $widget->type];
            if ($widget->kpi_id && ($kpi = Kpi::find($widget->kpi_id))) {
                $filter = $kpi->filter_column ? ['column' => $kpi->filter_column, 'value' => $kpi->filter_value] : [];
                $res = $runner->aggregate($kpi->source_table, $kpi->aggregate, $kpi->measure, null, $filter);
                $out['value'] = is_array($res) ? ($res['value'] ?? 0) : 0;
                $out['target'] = $kpi->target;
            }

            return $out;
        });

        return ['dashboard' => $dashboard->name, 'widgets' => $widgets];
    }
}
