<?php

use Illuminate\Support\Facades\Route;
use App\Modules\BusinessIntelligence\Http\Controllers\DataSourceController;
use App\Modules\BusinessIntelligence\Http\Controllers\KpiController;
use App\Modules\BusinessIntelligence\Http\Controllers\QueryController;
use App\Modules\BusinessIntelligence\Http\Controllers\DashboardController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.business_intelligence'])
    ->prefix('api/bi')
    ->group(function () {
        Route::get('data-sources', [DataSourceController::class, 'index']);
        Route::post('data-sources', [DataSourceController::class, 'store']);
        Route::get('columns', [DataSourceController::class, 'columns']);

        Route::get('kpis', [KpiController::class, 'index']);
        Route::post('kpis', [KpiController::class, 'store']);
        Route::get('kpis/{kpi}/value', [KpiController::class, 'value']);

        Route::post('query', [QueryController::class, 'run']);

        Route::get('dashboards', [DashboardController::class, 'index']);
        Route::post('dashboards', [DashboardController::class, 'store']);
        Route::post('dashboards/{dashboard}/widgets', [DashboardController::class, 'addWidget']);
        Route::get('dashboards/{dashboard}/render', [DashboardController::class, 'render']);
    });
