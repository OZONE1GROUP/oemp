<?php

namespace App\Modules\BusinessIntelligence\Models;

use App\Core\Support\BaseModel;

class Kpi extends BaseModel
{
    protected $table = 'bi_kpis';
    protected $fillable = ['tenant_id', 'name', 'source_table', 'measure', 'aggregate', 'filter_column', 'filter_value', 'target'];
    protected $casts = ['target' => 'decimal:2'];

}
