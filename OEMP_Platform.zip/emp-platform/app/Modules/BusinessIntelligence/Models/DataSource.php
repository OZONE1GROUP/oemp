<?php

namespace App\Modules\BusinessIntelligence\Models;

use App\Core\Support\BaseModel;

class DataSource extends BaseModel
{
    protected $table = 'bi_data_sources';
    protected $fillable = ['tenant_id', 'name', 'type', 'source_table', 'config'];
    protected $casts = ['config' => 'array'];

}
