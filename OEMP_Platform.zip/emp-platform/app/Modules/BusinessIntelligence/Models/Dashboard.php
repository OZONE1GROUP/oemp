<?php

namespace App\Modules\BusinessIntelligence\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Dashboard extends BaseModel
{
    protected $table = 'bi_dashboards';
    protected $fillable = ['tenant_id','name','description','data_source','owner','layout'];
    protected $casts = ['layout' => 'array'];

    public function widgets(): HasMany
    {
        return $this->hasMany(Widget::class);
    }
}
