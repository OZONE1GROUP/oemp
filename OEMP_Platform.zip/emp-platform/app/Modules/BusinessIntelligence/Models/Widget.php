<?php

namespace App\Modules\BusinessIntelligence\Models;

use App\Core\Support\BaseModel;

class Widget extends BaseModel
{
    protected $table = 'bi_widgets';
    protected $fillable = ['tenant_id', 'dashboard_id', 'kpi_id', 'title', 'type', 'config'];
    protected $casts = ['config' => 'array'];

}
