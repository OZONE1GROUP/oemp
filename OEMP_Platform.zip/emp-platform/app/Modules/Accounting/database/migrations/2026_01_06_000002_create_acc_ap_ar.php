<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('acc_bills', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('bill_no');
            $table->string('vendor_ref');
            $table->date('date');
            $table->date('due_date');
            $table->decimal('total', 15, 2)->default(0);
            $table->decimal('amount_paid', 15, 2)->default(0);
            $table->string('status')->default('open');
            $table->timestamps();
        });

        Schema::create('acc_bill_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('bill_id')->constrained('acc_bills')->cascadeOnDelete();
            $table->date('date');
            $table->decimal('amount', 15, 2)->default(0);
            $table->string('method')->nullable();
            $table->string('reference')->nullable();
        });

        Schema::create('acc_receipts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('receipt_no');
            $table->string('customer_ref');
            $table->string('invoice_ref')->nullable();
            $table->date('date');
            $table->decimal('amount', 15, 2)->default(0);
            $table->string('method')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('acc_receipts');
        Schema::dropIfExists('acc_bill_payments');
        Schema::dropIfExists('acc_bills');
    }
};
