<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('acc_bank_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('number');
            $table->string('gl_account_code')->nullable();
            $table->string('currency', 3)->default('USD');
            $table->decimal('balance', 15, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('acc_bank_statements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('bank_account_id')->constrained('acc_bank_accounts')->cascadeOnDelete();
            $table->date('statement_date');
            $table->decimal('opening_balance', 15, 2)->default(0);
            $table->decimal('closing_balance', 15, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('acc_bank_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('statement_id')->constrained('acc_bank_statements')->cascadeOnDelete();
            $table->date('date');
            $table->string('description');
            $table->decimal('amount', 15, 2)->default(0);
            $table->string('direction')->default('debit');
            $table->boolean('reconciled')->default(false);
            $table->string('matched_ref')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('acc_bank_transactions');
        Schema::dropIfExists('acc_bank_statements');
        Schema::dropIfExists('acc_bank_accounts');
    }
};
