<?php

namespace App\Modules\Accounting;

use App\Core\Support\ModuleServiceProvider;
use App\Core\Events\EventBus;
use App\Modules\Accounting\Services\PostingService;

class AccountingServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'accounting';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }

    public function boot(): void
    {
        parent::boot();

        /** @var EventBus $bus */
        $bus = $this->app->make(EventBus::class);
        $posting = $this->app->make(PostingService::class);

        // Auto-post approved payroll runs to the GL.
        $bus->subscribe('payroll.run.approved', function ($payload) use ($posting) {
            $posting->postPayrollRun((float) ($payload['net'] ?? 0), 'run#' . ($payload['id'] ?? '?'));
        });

        // Auto-post sales invoices raised by ERP.
        $bus->subscribe('erp.invoice.created', function ($payload) use ($posting) {
            $amount = (float) ($payload['total'] ?? 0);
            $posting->postSalesInvoice($amount, 'inv#' . ($payload['id'] ?? '?'));
        });

        // Auto-post asset depreciation runs.
        $bus->subscribe('asset.depreciation.posted', function ($payload) use ($posting) {
            $posting->postDepreciation((float) ($payload['amount'] ?? 0), $payload['period'] ?? '?');
        });
    }
}
