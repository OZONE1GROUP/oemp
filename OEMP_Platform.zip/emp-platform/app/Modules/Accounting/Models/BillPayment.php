<?php

namespace App\Modules\Accounting\Models;

use App\Core\Support\BaseModel;

class BillPayment extends BaseModel
{
    protected $table = 'acc_bill_payments';
    protected $fillable = ['tenant_id', 'bill_id', 'date', 'amount', 'method', 'reference'];
    protected $casts = ['date' => 'date', 'amount' => 'decimal:2'];

}
