<?php

namespace App\Modules\Accounting\Models;

use App\Core\Support\BaseModel;

class Receipt extends BaseModel
{
    protected $table = 'acc_receipts';
    protected $fillable = ['tenant_id', 'receipt_no', 'customer_ref', 'invoice_ref', 'date', 'amount', 'method'];
    protected $casts = ['date' => 'date', 'amount' => 'decimal:2'];

}
