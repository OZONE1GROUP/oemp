<?php

namespace App\Modules\Accounting\Models;

use App\Core\Support\BaseModel;

class JournalEntry extends BaseModel
{
    protected $table = 'accounting_journal_entries';

    protected $fillable = ['tenant_id', 'reference', 'memo', 'debit', 'credit', 'posted'];

    protected $casts = [
        'debit' => 'decimal:2',
        'credit' => 'decimal:2',
        'posted' => 'boolean'
    ];
}
