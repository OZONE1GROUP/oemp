<?php

namespace App\Modules\Accounting\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Bill extends BaseModel
{
    protected $table = 'acc_bills';
    protected $fillable = ['tenant_id', 'bill_no', 'vendor_ref', 'date', 'due_date', 'total', 'amount_paid', 'status'];
    protected $casts = ['date' => 'date', 'due_date' => 'date', 'total' => 'decimal:2', 'amount_paid' => 'decimal:2'];

    public function payments(): HasMany
    {
        return $this->hasMany(BillPayment::class);
    }
}
