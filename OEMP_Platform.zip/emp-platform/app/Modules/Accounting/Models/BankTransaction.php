<?php

namespace App\Modules\Accounting\Models;

use App\Core\Support\BaseModel;

class BankTransaction extends BaseModel
{
    protected $table = 'acc_bank_transactions';
    protected $fillable = ['tenant_id', 'statement_id', 'date', 'description', 'amount', 'direction', 'reconciled', 'matched_ref'];
    protected $casts = ['date' => 'date', 'amount' => 'decimal:2', 'reconciled' => 'boolean'];

}
