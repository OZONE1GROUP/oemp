<?php

namespace App\Modules\Accounting\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BankStatement extends BaseModel
{
    protected $table = 'acc_bank_statements';
    protected $fillable = ['tenant_id', 'bank_account_id', 'statement_date', 'opening_balance', 'closing_balance'];
    protected $casts = ['statement_date' => 'date', 'opening_balance' => 'decimal:2', 'closing_balance' => 'decimal:2'];

    public function transactions(): HasMany
    {
        return $this->hasMany(BankTransaction::class, 'statement_id');
    }
}
