<?php

namespace App\Modules\Accounting\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BankAccount extends BaseModel
{
    protected $table = 'acc_bank_accounts';
    protected $fillable = ['tenant_id', 'name', 'number', 'gl_account_code', 'currency', 'balance'];
    protected $casts = ['balance' => 'decimal:2'];

    public function statements(): HasMany
    {
        return $this->hasMany(BankStatement::class);
    }
}
