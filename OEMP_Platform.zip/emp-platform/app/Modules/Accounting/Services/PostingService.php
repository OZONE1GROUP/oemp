<?php

namespace App\Modules\Accounting\Services;

use App\Modules\ERP\Models\GlAccount;
use App\Modules\ERP\Models\GlJournal;
use App\Modules\ERP\Models\FiscalPeriod;

/**
 * Turns business events into balanced GL journals in the shared ERP ledger.
 * Account resolution is by code; if mapping accounts are absent the posting is
 * skipped gracefully (returns null) so event handling never breaks the app.
 */
class PostingService
{
    private function account(string $code): ?int
    {
        return optional(GlAccount::where('code', $code)->first())->id;
    }

    private function openPeriodId(): ?int
    {
        return optional(FiscalPeriod::where('status', 'open')->latest('id')->first())->id;
    }

    /** Dr Salary Expense / Cr Wages Payable for an approved payroll run. */
    public function postPayrollRun(float $net, string $ref): ?GlJournal
    {
        $expense = $this->account('6000');
        $payable = $this->account('2100');
        $period = $this->openPeriodId();
        if (! $expense || ! $payable || ! $period || $net <= 0) {
            return null;
        }

        $journal = GlJournal::create([
            'journal_no' => 'PR-' . now()->format('YmdHis'),
            'date' => now()->toDateString(),
            'period_id' => $period,
            'memo' => "Payroll $ref",
            'source' => 'payroll',
            'posted' => true,
        ]);
        $journal->lines()->createMany([
            ['account_id' => $expense, 'debit' => $net, 'credit' => 0, 'memo' => 'Payroll expense'],
            ['account_id' => $payable, 'debit' => 0, 'credit' => $net, 'memo' => 'Wages payable'],
        ]);

        return $journal;
    }

    /** Dr Accounts Receivable / Cr Sales Revenue for a sales invoice. */
    public function postSalesInvoice(float $amount, string $ref): ?GlJournal
    {
        $ar = $this->account('1100');
        $revenue = $this->account('4000');
        $period = $this->openPeriodId();
        if (! $ar || ! $revenue || ! $period || $amount <= 0) {
            return null;
        }

        $journal = GlJournal::create([
            'journal_no' => 'AR-' . now()->format('YmdHis'),
            'date' => now()->toDateString(),
            'period_id' => $period,
            'memo' => "Invoice $ref",
            'source' => 'sales',
            'posted' => true,
        ]);
        $journal->lines()->createMany([
            ['account_id' => $ar, 'debit' => $amount, 'credit' => 0, 'memo' => 'AR'],
            ['account_id' => $revenue, 'debit' => 0, 'credit' => $amount, 'memo' => 'Revenue'],
        ]);

        return $journal;
    }

    /** Dr Depreciation Expense / Cr Accumulated Depreciation for a period run. */
    public function postDepreciation(float $amount, string $ref): ?GlJournal
    {
        $expense = $this->account('6100');
        $accum = $this->account('1500');
        $period = $this->openPeriodId();
        if (! $expense || ! $accum || ! $period || $amount <= 0) {
            return null;
        }

        $journal = GlJournal::create([
            'journal_no' => 'DEP-' . now()->format('YmdHis'),
            'date' => now()->toDateString(),
            'period_id' => $period,
            'memo' => "Depreciation $ref",
            'source' => 'assets',
            'posted' => true,
        ]);
        $journal->lines()->createMany([
            ['account_id' => $expense, 'debit' => $amount, 'credit' => 0, 'memo' => 'Depreciation expense'],
            ['account_id' => $accum, 'debit' => 0, 'credit' => $amount, 'memo' => 'Accumulated depreciation'],
        ]);

        return $journal;
    }
}
