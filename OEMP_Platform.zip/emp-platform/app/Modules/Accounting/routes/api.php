<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Accounting\Http\Controllers\BankAccountController;
use App\Modules\Accounting\Http\Controllers\BankReconciliationController;
use App\Modules\Accounting\Http\Controllers\BillController;
use App\Modules\Accounting\Http\Controllers\ReceiptController;
use App\Modules\Accounting\Http\Controllers\FinancialStatementController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.accounting'])
    ->prefix('api/accounting')
    ->group(function () {
        // Bank & reconciliation
        Route::get('bank-accounts', [BankAccountController::class, 'index']);
        Route::post('bank-accounts', [BankAccountController::class, 'store']);
        Route::post('bank-statements', [BankReconciliationController::class, 'importStatement']);
        Route::post('bank-transactions/{bankTransaction}/match', [BankReconciliationController::class, 'match']);
        Route::get('bank-statements/{bankStatement}/status', [BankReconciliationController::class, 'status']);

        // AP (bills) & AR (receipts)
        Route::get('bills', [BillController::class, 'index']);
        Route::post('bills', [BillController::class, 'store']);
        Route::post('bills/{bill}/pay', [BillController::class, 'pay']);
        Route::get('receipts', [ReceiptController::class, 'index']);
        Route::post('receipts', [ReceiptController::class, 'store']);

        // Financial statements
        Route::get('statements/profit-and-loss', [FinancialStatementController::class, 'profitAndLoss']);
        Route::get('statements/balance-sheet', [FinancialStatementController::class, 'balanceSheet']);
        Route::get('statements/cash-flow', [FinancialStatementController::class, 'cashFlow']);
    });
