<div class="emp-module" data-module="accounting">
    <h3>JournalEntrys</h3>
    <p class="text-muted">Accounting module &mdash; managed by the EMP platform core.</p>
</div>
