<?php

namespace App\Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Accounting\Models\Bill;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class BillController extends Controller
{
    public function index(Request $request)
    {
        return Bill::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'vendor_ref' => ['required', 'string', 'max:120'],
            'date' => ['required', 'date'],
            'due_date' => ['required', 'date', 'after_or_equal:date'],
            'total' => ['required', 'numeric', 'min:0'],
        ]);

        return response()->json(Bill::create(array_merge($data, [
            'bill_no' => 'BILL-' . now()->format('YmdHis'),
            'amount_paid' => 0,
            'status' => 'open',
        ])), 201);
    }

    public function pay(Request $request, Bill $bill, EventBus $bus)
    {
        $data = $request->validate([
            'amount' => ['required', 'numeric', 'min:0.01'],
            'method' => ['required', 'string', 'max:40'],
        ]);
        abort_if($data['amount'] > ($bill->total - $bill->amount_paid), 422, 'Payment exceeds balance due.');

        $bill->payments()->create(['date' => now()->toDateString(), 'amount' => $data['amount'], 'method' => $data['method']]);
        $paid = $bill->amount_paid + $data['amount'];
        $bill->update(['amount_paid' => $paid, 'status' => $paid >= $bill->total ? 'paid' : 'partial']);
        $bus->publish('accounting.bill.paid', ['id' => $bill->id, 'amount' => $data['amount']]);

        return $bill->load('payments');
    }
}
