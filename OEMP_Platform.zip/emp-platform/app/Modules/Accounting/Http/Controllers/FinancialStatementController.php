<?php

namespace App\Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

/**
 * Financial statements computed from posted GL journals in the shared ERP ledger.
 */
class FinancialStatementController extends Controller
{
    private function balancesByType(): \Illuminate\Support\Collection
    {
        return DB::table('erp_gl_journal_lines as l')
            ->join('erp_gl_journals as j', 'j.id', '=', 'l.journal_id')
            ->join('erp_gl_accounts as a', 'a.id', '=', 'l.account_id')
            ->where('j.posted', true)
            ->groupBy('a.type')
            ->select('a.type', DB::raw('SUM(l.debit - l.credit) as balance'))
            ->pluck('balance', 'type');
    }

    /** P&L: revenue (credit-normal) less expenses (debit-normal). */
    public function profitAndLoss()
    {
        $b = $this->balancesByType();
        $income = -(float) ($b['income'] ?? 0);   // credit balance shown positive
        $expense = (float) ($b['expense'] ?? 0);

        return [
            'income' => round($income, 2),
            'expense' => round($expense, 2),
            'net_profit' => round($income - $expense, 2),
        ];
    }

    /** Balance sheet: assets = liabilities + equity (+ retained earnings). */
    public function balanceSheet()
    {
        $b = $this->balancesByType();
        $assets = (float) ($b['asset'] ?? 0);
        $liabilities = -(float) ($b['liability'] ?? 0);
        $equity = -(float) ($b['equity'] ?? 0);
        $retained = -(float) ($b['income'] ?? 0) - (float) ($b['expense'] ?? 0);

        return [
            'assets' => round($assets, 2),
            'liabilities' => round($liabilities, 2),
            'equity' => round($equity, 2),
            'retained_earnings' => round($retained, 2),
            'balances' => round($assets - ($liabilities + $equity + $retained), 2),
        ];
    }

    /** Simplified cash flow proxy from bank movements. */
    public function cashFlow()
    {
        $in = DB::table('acc_bank_transactions')->where('direction', 'credit')->sum('amount');
        $out = DB::table('acc_bank_transactions')->where('direction', 'debit')->sum('amount');

        return ['inflow' => round((float) $in, 2), 'outflow' => round((float) $out, 2), 'net' => round((float) $in - (float) $out, 2)];
    }
}
