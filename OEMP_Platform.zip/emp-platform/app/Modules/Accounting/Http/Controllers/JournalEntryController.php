<?php

namespace App\Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Accounting\Models\JournalEntry;
use Illuminate\Http\Request;

class JournalEntryController extends Controller
{
    public function index(Request $request)
    {
        return JournalEntry::query()
            ->when($request->q, fn ($qq) => $qq->where('reference', 'like', "%{$request->q}%"))
            ->latest()
            ->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'reference' => 'required|string|max:255',
            'memo' => 'nullable|string|max:255',
            'debit' => 'nullable|numeric',
            'credit' => 'nullable|numeric',
            'posted' => 'nullable|boolean',
        ]);

        return response()->json(JournalEntry::create($data), 201);
    }

    public function show(JournalEntry $accountingItem)
    {
        return $accountingItem;
    }

    public function update(Request $request, JournalEntry $accountingItem)
    {
        $data = $request->validate([
            'reference' => 'required|string|max:255',
            'memo' => 'nullable|string|max:255',
            'debit' => 'nullable|numeric',
            'credit' => 'nullable|numeric',
            'posted' => 'nullable|boolean',
        ]);
        $accountingItem->update($data);

        return $accountingItem;
    }

    public function destroy(JournalEntry $accountingItem)
    {
        $accountingItem->delete();

        return response()->noContent();
    }
}
