<?php

namespace App\Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Accounting\Models\BankStatement;
use App\Modules\Accounting\Models\BankTransaction;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class BankReconciliationController extends Controller
{
    /** Import a statement with its transactions. */
    public function importStatement(Request $request)
    {
        $data = $request->validate([
            'bank_account_id' => ['required', 'integer', 'exists:acc_bank_accounts,id'],
            'statement_date' => ['required', 'date'],
            'opening_balance' => ['required', 'numeric'],
            'closing_balance' => ['required', 'numeric'],
            'transactions' => ['required', 'array', 'min:1'],
            'transactions.*.date' => ['required', 'date'],
            'transactions.*.description' => ['required', 'string'],
            'transactions.*.amount' => ['required', 'numeric'],
            'transactions.*.direction' => ['required', 'in:debit,credit'],
        ]);

        return DB::transaction(function () use ($data) {
            $stmt = BankStatement::create([
                'bank_account_id' => $data['bank_account_id'],
                'statement_date' => $data['statement_date'],
                'opening_balance' => $data['opening_balance'],
                'closing_balance' => $data['closing_balance'],
            ]);
            foreach ($data['transactions'] as $t) {
                $stmt->transactions()->create(array_merge($t, ['reconciled' => false]));
            }

            return response()->json($stmt->load('transactions'), 201);
        });
    }

    /** Mark a transaction reconciled against a book reference. */
    public function match(Request $request, BankTransaction $bankTransaction)
    {
        $ref = $request->validate(['matched_ref' => ['required', 'string']])['matched_ref'];
        $bankTransaction->update(['reconciled' => true, 'matched_ref' => $ref]);

        return $bankTransaction;
    }

    /** Reconciliation status for a statement: matched vs. outstanding. */
    public function status(BankStatement $bankStatement)
    {
        $txns = $bankStatement->transactions()->get();
        $bookClosing = $bankStatement->opening_balance + $txns->sum(fn ($t) => $t->direction === 'credit' ? $t->amount : -$t->amount);

        return [
            'statement_closing' => $bankStatement->closing_balance,
            'computed_closing' => round($bookClosing, 2),
            'difference' => round($bankStatement->closing_balance - $bookClosing, 2),
            'reconciled' => $txns->where('reconciled', false)->isEmpty(),
            'outstanding' => $txns->where('reconciled', false)->values(),
        ];
    }
}
