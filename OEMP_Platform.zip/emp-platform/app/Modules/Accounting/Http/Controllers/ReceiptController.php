<?php

namespace App\Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Accounting\Models\Receipt;
use Illuminate\Http\Request;

class ReceiptController extends Controller
{
    public function index()
    {
        return Receipt::latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'customer_ref' => ['required', 'string', 'max:120'],
            'invoice_ref' => ['nullable', 'string', 'max:60'],
            'date' => ['required', 'date'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'method' => ['required', 'string', 'max:40'],
        ]);

        return response()->json(Receipt::create(array_merge($data, [
            'receipt_no' => 'RCPT-' . now()->format('YmdHis'),
        ])), 201);
    }
}
