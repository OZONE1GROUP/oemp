<?php

namespace App\Modules\Accounting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Accounting\Models\BankAccount;
use Illuminate\Http\Request;

class BankAccountController extends Controller
{
    public function index()
    {
        return BankAccount::orderBy('name')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'number' => ['required', 'string', 'max:40'],
            'gl_account_code' => ['nullable', 'string', 'max:20'],
            'currency' => ['required', 'string', 'size:3'],
        ]);

        return response()->json(BankAccount::create(array_merge($data, ['balance' => 0])), 201);
    }
}
