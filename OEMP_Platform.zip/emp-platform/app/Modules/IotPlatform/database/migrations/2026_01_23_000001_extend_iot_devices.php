<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('iot_devices', function (Blueprint $table) {
            foreach ([['device_type_id','bigint'],['firmware_version','str'],['twin_state','json']] as [$c,$t]) {
                if (! Schema::hasColumn('iot_devices', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'json' => $table->json($c)->nullable(),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('iot_devices', function (Blueprint $table) {
            $table->dropColumn(['device_type_id', 'firmware_version', 'twin_state']);
        });
    }
};
