<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('iot_device_types', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->json('metrics')->nullable();
            $table->timestamps();
        });

        Schema::create('iot_telemetry', function (Blueprint $table) {
            $table->id();
            $table->foreignId('device_id')->constrained('iot_devices')->cascadeOnDelete();
            $table->string('metric');
            $table->decimal('value', 18, 4)->default(0);
            $table->timestamp('recorded_at')->index();
        });

        Schema::create('iot_rules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->unsignedBigInteger('device_type_id')->nullable();
            $table->unsignedBigInteger('device_id')->nullable();
            $table->string('metric');
            $table->string('operator')->default('gt');
            $table->decimal('threshold', 18, 4)->default(0);
            $table->string('action')->default('alert');
            $table->string('command')->nullable();
            $table->string('severity')->default('medium');
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('iot_commands', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('device_id')->constrained('iot_devices')->cascadeOnDelete();
            $table->string('command');
            $table->json('payload')->nullable();
            $table->string('status')->default('queued');
            $table->timestamp('issued_at')->nullable();
            $table->timestamps();
        });

        Schema::create('iot_alerts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('device_id')->constrained('iot_devices')->cascadeOnDelete();
            $table->unsignedBigInteger('rule_id')->nullable();
            $table->string('message');
            $table->string('severity')->default('medium');
            $table->string('status')->default('open');
            $table->timestamps();
        });

        Schema::create('iot_firmware', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->unsignedBigInteger('device_type_id')->nullable();
            $table->string('version');
            $table->string('url')->nullable();
            $table->string('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('iot_firmware');
        Schema::dropIfExists('iot_alerts');
        Schema::dropIfExists('iot_commands');
        Schema::dropIfExists('iot_rules');
        Schema::dropIfExists('iot_telemetry');
        Schema::dropIfExists('iot_device_types');
    }
};
