<?php

namespace App\Modules\IotPlatform\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\IotPlatform\Models\IotRule;
use Illuminate\Http\Request;

class RuleController extends Controller
{
    public function index()
    {
        return IotRule::get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'device_type_id' => ['nullable', 'integer', 'exists:iot_device_types,id'],
            'device_id' => ['nullable', 'integer', 'exists:iot_devices,id'],
            'metric' => ['required', 'string', 'max:60'],
            'operator' => ['required', 'in:gt,lt,gte,lte,eq'],
            'threshold' => ['required', 'numeric'],
            'action' => ['required', 'in:alert,command'],
            'command' => ['nullable', 'string', 'max:60'],
            'severity' => ['nullable', 'in:info,low,medium,high,critical'],
        ]);

        return response()->json(IotRule::create(array_merge($data, ['active' => true])), 201);
    }
}
