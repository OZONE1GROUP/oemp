<?php

namespace App\Modules\IotPlatform\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class IotAnalyticsController extends Controller
{
    /** Device fleet status. */
    public function deviceStatus()
    {
        return DB::table('iot_devices')
            ->groupBy('status')
            ->select('status', DB::raw('COUNT(*) as count'))
            ->get();
    }

    /** Devices offline (no ping in 15 min). */
    public function offline()
    {
        return DB::table('iot_devices')
            ->where(fn ($q) => $q->whereNull('last_ping')->orWhere('last_ping', '<', now()->subMinutes(15)))
            ->get(['id', 'device_uid', 'last_ping', 'status']);
    }

    /** Open IoT alerts by severity. */
    public function alerts()
    {
        return DB::table('iot_alerts')
            ->where('status', 'open')
            ->groupBy('severity')
            ->select('severity', DB::raw('COUNT(*) as count'))
            ->get();
    }
}
