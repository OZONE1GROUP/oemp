<?php

namespace App\Modules\IotPlatform\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\IotPlatform\Models\Device;
use App\Modules\IotPlatform\Models\DeviceType;
use Illuminate\Http\Request;

class DeviceController extends Controller
{
    public function types()
    {
        return DeviceType::get();
    }

    public function storeType(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:40'],
            'name' => ['required', 'string', 'max:120'],
            'metrics' => ['nullable', 'array'],
        ]);

        return response()->json(DeviceType::create($data), 201);
    }

    public function index(Request $request)
    {
        return Device::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->orderBy('device_uid')->paginate(100);
    }

    /** Provision a device into the registry. */
    public function store(Request $request)
    {
        $data = $request->validate([
            'device_uid' => ['required', 'string', 'max:80'],
            'type' => ['nullable', 'string', 'max:60'],
            'device_type_id' => ['nullable', 'integer', 'exists:iot_device_types,id'],
            'gateway' => ['nullable', 'string', 'max:80'],
            'firmware_version' => ['nullable', 'string', 'max:40'],
        ]);

        return response()->json(Device::create(array_merge($data, ['status' => 'provisioned'])), 201);
    }

    public function show(Device $device)
    {
        return $device; // includes twin_state
    }
}
