<?php

namespace App\Modules\IotPlatform\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\IotPlatform\Models\IotCommand;
use App\Modules\IotPlatform\Models\Device;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class CommandController extends Controller
{
    public function index(Request $request)
    {
        return IotCommand::when($request->device_id, fn ($q) => $q->where('device_id', $request->device_id))
            ->latest()->paginate(50);
    }

    /** Issue a downlink command to a device (dispatched via MQTT by the gateway). */
    public function issue(Request $request, EventBus $bus)
    {
        $data = $request->validate([
            'device_id' => ['required', 'integer', 'exists:iot_devices,id'],
            'command' => ['required', 'string', 'max:60'],
            'payload' => ['nullable', 'array'],
        ]);

        $cmd = IotCommand::create(array_merge($data, ['status' => 'queued', 'issued_at' => now()]));
        $device = Device::find($data['device_id']);
        $bus->publish('iot.command.queued', ['device' => $device?->device_uid, 'command' => $data['command']]);

        return response()->json($cmd, 201);
    }
}
