<?php

namespace App\Modules\IotPlatform\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\IotPlatform\Models\Telemetry;
use App\Modules\IotPlatform\Services\TelemetryIngestor;
use Illuminate\Http\Request;

class TelemetryController extends Controller
{
    /** HTTP mirror of the MQTT telemetry pipeline. */
    public function ingest(Request $request, TelemetryIngestor $ingestor)
    {
        $data = $request->validate([
            'device_uid' => ['required', 'string'],
            'metric' => ['required', 'string'],
            'value' => ['required', 'numeric'],
        ]);
        $reading = $ingestor->ingest($data['device_uid'], $data['metric'], $data['value']);
        abort_if($reading === null, 404, 'Unknown device.');

        return response()->json($reading, 201);
    }

    public function query(Request $request)
    {
        return Telemetry::where('device_id', $request->device_id)
            ->when($request->metric, fn ($q) => $q->where('metric', $request->metric))
            ->latest('recorded_at')->limit(500)->get();
    }
}
