<?php

namespace App\Modules\IotPlatform\Models;

use App\Core\Support\BaseModel;

class Firmware extends BaseModel
{
    protected $table = 'iot_firmware';
    protected $fillable = ['tenant_id', 'device_type_id', 'version', 'url', 'notes'];

}
