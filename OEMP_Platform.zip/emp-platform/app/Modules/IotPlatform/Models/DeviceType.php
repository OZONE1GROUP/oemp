<?php

namespace App\Modules\IotPlatform\Models;

use App\Core\Support\BaseModel;

class DeviceType extends BaseModel
{
    protected $table = 'iot_device_types';
    protected $fillable = ['tenant_id', 'code', 'name', 'metrics'];
    protected $casts = ['metrics' => 'array'];

}
