<?php

namespace App\Modules\IotPlatform\Models;

use App\Core\Support\BaseModel;

class Device extends BaseModel
{
    protected $table = 'iot_devices';
    protected $fillable = ['tenant_id','device_uid','type','device_type_id','gateway','status',
        'last_ping','firmware_version','twin_state'];
    protected $casts = ['last_ping' => 'datetime', 'twin_state' => 'array'];
}
