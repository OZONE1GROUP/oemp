<?php

namespace App\Modules\IotPlatform\Models;

use App\Core\Support\BaseModel;

class Telemetry extends BaseModel
{
    protected $table = 'iot_telemetry';
    protected $fillable = ['tenant_id', 'device_id', 'metric', 'value', 'recorded_at'];
    protected $casts = ['value' => 'decimal:4', 'recorded_at' => 'datetime'];

}
