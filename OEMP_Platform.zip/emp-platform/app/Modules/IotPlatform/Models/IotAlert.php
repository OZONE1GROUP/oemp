<?php

namespace App\Modules\IotPlatform\Models;

use App\Core\Support\BaseModel;

class IotAlert extends BaseModel
{
    protected $table = 'iot_alerts';
    protected $fillable = ['tenant_id', 'device_id', 'rule_id', 'message', 'severity', 'status'];

}
