<?php

namespace App\Modules\IotPlatform\Models;

use App\Core\Support\BaseModel;

class IotCommand extends BaseModel
{
    protected $table = 'iot_commands';
    protected $fillable = ['tenant_id', 'device_id', 'command', 'payload', 'status', 'issued_at'];
    protected $casts = ['payload' => 'array', 'issued_at' => 'datetime'];

}
