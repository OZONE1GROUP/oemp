<?php

namespace App\Modules\IotPlatform\Models;

use App\Core\Support\BaseModel;

class IotRule extends BaseModel
{
    protected $table = 'iot_rules';
    protected $fillable = ['tenant_id', 'device_type_id', 'device_id', 'metric', 'operator', 'threshold', 'action', 'command', 'severity', 'active'];
    protected $casts = ['threshold' => 'decimal:4', 'active' => 'boolean'];

}
