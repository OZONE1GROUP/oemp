<?php

namespace App\Modules\IotPlatform\Services;

use App\Modules\IotPlatform\Models\Device;
use App\Modules\IotPlatform\Models\Telemetry;
use App\Modules\IotPlatform\Models\IotRule;
use App\Modules\IotPlatform\Models\IotAlert;
use App\Modules\IotPlatform\Models\IotCommand;
use App\Core\Events\EventBus;

/**
 * Ingests device telemetry, updates the digital-twin state and last-ping, then
 * runs the rules engine: threshold breaches raise alerts and/or dispatch commands.
 */
class TelemetryIngestor
{
    public function __construct(private EventBus $bus) {}

    public function ingest(string $deviceUid, string $metric, float $value): ?Telemetry
    {
        $device = Device::where('device_uid', $deviceUid)->first();
        if (! $device) {
            return null;
        }

        $reading = Telemetry::create(['device_id' => $device->id, 'metric' => $metric, 'value' => $value, 'recorded_at' => now()]);

        $twin = $device->twin_state ?? [];
        $twin[$metric] = $value;
        $device->update(['twin_state' => $twin, 'last_ping' => now(), 'status' => 'online']);

        $this->bus->publish('iot.telemetry', ['device' => $deviceUid, 'metric' => $metric, 'value' => $value]);
        $this->evaluateRules($device, $metric, $value);

        return $reading;
    }

    private function evaluateRules(Device $device, string $metric, float $value): void
    {
        $rules = IotRule::where('active', true)->where('metric', $metric)
            ->where(fn ($q) => $q->where('device_id', $device->id)->orWhere('device_type_id', $device->device_type_id))
            ->get();

        foreach ($rules as $rule) {
            $hit = match ($rule->operator) {
                'gt' => $value > $rule->threshold,
                'lt' => $value < $rule->threshold,
                'gte' => $value >= $rule->threshold,
                'lte' => $value <= $rule->threshold,
                'eq' => $value == $rule->threshold,
                default => false,
            };
            if (! $hit) {
                continue;
            }

            if ($rule->action === 'command' && $rule->command) {
                IotCommand::create(['device_id' => $device->id, 'command' => $rule->command, 'status' => 'queued', 'issued_at' => now()]);
                $this->bus->publish('iot.command.queued', ['device' => $device->device_uid, 'command' => $rule->command]);
            } else {
                IotAlert::create([
                    'device_id' => $device->id, 'rule_id' => $rule->id,
                    'message' => "{$metric} {$rule->operator} {$rule->threshold} (value {$value})",
                    'severity' => $rule->severity ?? 'medium', 'status' => 'open',
                ]);
                $this->bus->publish('iot.alert', ['device' => $device->device_uid, 'metric' => $metric, 'value' => $value]);
            }
        }
    }
}
