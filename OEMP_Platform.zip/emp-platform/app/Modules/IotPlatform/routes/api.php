<?php

use Illuminate\Support\Facades\Route;
use App\Modules\IotPlatform\Http\Controllers\DeviceController;
use App\Modules\IotPlatform\Http\Controllers\TelemetryController;
use App\Modules\IotPlatform\Http\Controllers\RuleController;
use App\Modules\IotPlatform\Http\Controllers\CommandController;
use App\Modules\IotPlatform\Http\Controllers\IotAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.iot_platform'])
    ->prefix('api/iot')
    ->group(function () {
        Route::get('device-types', [DeviceController::class, 'types']);
        Route::post('device-types', [DeviceController::class, 'storeType']);
        Route::get('devices', [DeviceController::class, 'index']);
        Route::post('devices', [DeviceController::class, 'store']);
        Route::get('devices/{device}', [DeviceController::class, 'show']);

        Route::post('telemetry', [TelemetryController::class, 'ingest']);
        Route::get('telemetry', [TelemetryController::class, 'query']);

        Route::get('rules', [RuleController::class, 'index']);
        Route::post('rules', [RuleController::class, 'store']);

        Route::get('commands', [CommandController::class, 'index']);
        Route::post('commands', [CommandController::class, 'issue']);

        Route::get('analytics/device-status', [IotAnalyticsController::class, 'deviceStatus']);
        Route::get('analytics/offline', [IotAnalyticsController::class, 'offline']);
        Route::get('analytics/alerts', [IotAnalyticsController::class, 'alerts']);
    });
