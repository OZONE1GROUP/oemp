<div class="emp-module" data-module="iot_platform">
    <h3>Devices</h3>
    <p class="text-muted">IotPlatform module &mdash; managed by the EMP platform core.</p>
</div>
