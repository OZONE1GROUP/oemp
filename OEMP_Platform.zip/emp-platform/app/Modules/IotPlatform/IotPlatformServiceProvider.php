<?php

namespace App\Modules\IotPlatform;

use App\Core\Support\ModuleServiceProvider;
use App\Modules\IotPlatform\Console\SubscribeDevices;

class IotPlatformServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'iot_platform';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }

    public function boot(): void
    {
        parent::boot();

        if ($this->app->runningInConsole()) {
            $this->commands([SubscribeDevices::class]);
        }
    }
}
