<?php

namespace App\Modules\IotPlatform\Console;

use Illuminate\Console\Command;
use App\Modules\IotPlatform\Services\TelemetryIngestor;
use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

/**
 * Subscribes to device telemetry: iot/{deviceUid}/{metric} with the numeric
 * value as payload (or JSON {"metric":..,"value":..} on iot/{deviceUid}/telemetry).
 */
class SubscribeDevices extends Command
{
    protected $signature = 'iot:subscribe';
    protected $description = 'Subscribe to IoT device telemetry over MQTT';

    public function handle(TelemetryIngestor $ingestor): int
    {
        $client = new MqttClient(env('MQTT_HOST', 'mqtt'), (int) env('MQTT_PORT', 1883), 'emp-iot-' . uniqid());
        $client->connect((new ConnectionSettings)->setKeepAliveInterval(30), true);

        $this->info('Subscribed to iot/#');
        $client->subscribe('iot/#', function (string $topic, string $payload) use ($ingestor) {
            $parts = explode('/', $topic); // iot/{uid}/{metric}
            $uid = $parts[1] ?? 'unknown';
            $metric = $parts[2] ?? 'telemetry';
            if ($metric === 'telemetry') {
                $data = json_decode($payload, true) ?: [];
                $ingestor->ingest($uid, $data['metric'] ?? 'value', (float) ($data['value'] ?? 0));
            } else {
                $ingestor->ingest($uid, $metric, (float) $payload);
            }
        }, 0);

        $client->loop(true);
        $client->disconnect();

        return self::SUCCESS;
    }
}
