<?php

namespace App\Modules\AssetManagement;

use App\Core\Support\ModuleServiceProvider;

class AssetManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'asset_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
