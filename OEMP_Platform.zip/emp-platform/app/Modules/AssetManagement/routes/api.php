<?php

use Illuminate\Support\Facades\Route;
use App\Modules\AssetManagement\Http\Controllers\AssetController;
use App\Modules\AssetManagement\Http\Controllers\MaintenanceController;
use App\Modules\AssetManagement\Http\Controllers\MeterController;
use App\Modules\AssetManagement\Http\Controllers\DepreciationController;
use App\Modules\AssetManagement\Http\Controllers\AssetAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.asset_management'])
    ->prefix('api/assets')
    ->group(function () {
        // Register
        Route::get('/', [AssetController::class, 'index']);
        Route::post('/', [AssetController::class, 'store']);
        Route::get('{asset}', [AssetController::class, 'show']);

        // Maintenance
        Route::get('maintenance/plans', [MaintenanceController::class, 'plans']);
        Route::post('maintenance/plans', [MaintenanceController::class, 'storePlan']);
        Route::post('maintenance/generate-due', [MaintenanceController::class, 'generateDue']);
        Route::get('maintenance/work-orders', [MaintenanceController::class, 'workOrders']);
        Route::post('maintenance/work-orders/{workOrder}/complete', [MaintenanceController::class, 'complete']);

        // Meters (condition-based)
        Route::post('meters', [MeterController::class, 'store']);
        Route::post('meters/{meter}/readings', [MeterController::class, 'record']);

        // Depreciation
        Route::get('depreciation/schedule', [DepreciationController::class, 'schedule']);
        Route::post('depreciation/run', [DepreciationController::class, 'run']);

        // Analytics
        Route::get('analytics/value-by-category', [AssetAnalyticsController::class, 'valueByCategory']);
        Route::get('analytics/maintenance-cost', [AssetAnalyticsController::class, 'maintenanceCost']);
    });
