<?php

namespace App\Modules\AssetManagement\Services;

use App\Modules\AssetManagement\Models\MaintenancePlan;
use App\Modules\AssetManagement\Models\MaintenanceWorkOrder;
use App\Core\Events\EventBus;

/**
 * Generates preventive-maintenance work orders from plans whose next-due date
 * has arrived, then rolls the schedule forward.
 */
class MaintenanceService
{
    public function __construct(private EventBus $bus) {}

    public function generateDue(): int
    {
        $count = 0;
        MaintenancePlan::where('active', true)->whereDate('next_due', '<=', now())->get()->each(function ($plan) use (&$count) {
            MaintenanceWorkOrder::create([
                'asset_id' => $plan->asset_id,
                'plan_id' => $plan->id,
                'type' => 'PM',
                'description' => $plan->task,
                'status' => 'open',
                'scheduled_date' => now()->toDateString(),
            ]);
            $plan->update(['next_due' => now()->addDays($plan->frequency_days)->toDateString()]);
            $this->bus->publish('asset.pm.generated', ['asset_id' => $plan->asset_id, 'plan_id' => $plan->id]);
            $count++;
        });

        return $count;
    }
}
