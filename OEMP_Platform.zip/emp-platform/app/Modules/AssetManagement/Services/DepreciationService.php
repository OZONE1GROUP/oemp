<?php

namespace App\Modules\AssetManagement\Services;

use App\Modules\AssetManagement\Models\Asset;
use App\Modules\AssetManagement\Models\DepreciationEntry;
use App\Core\Events\EventBus;

/**
 * Straight-line depreciation engine. Posts one monthly entry per active asset,
 * updates accumulated depreciation and book value, and publishes an event that
 * Accounting turns into a GL journal.
 */
class DepreciationService
{
    public function __construct(private EventBus $bus) {}

    public function runPeriod(string $period): array
    {
        $entries = [];
        $total = 0.0;

        Asset::where('status', 'active')->where('useful_life_years', '>', 0)->chunk(200, function ($assets) use (&$entries, &$total, $period) {
            foreach ($assets as $asset) {
                $monthly = round((((float) $asset->cost - (float) $asset->salvage_value)) / ($asset->useful_life_years * 12), 2);
                $remaining = (float) $asset->book_value - (float) $asset->salvage_value;
                if ($remaining <= 0) {
                    continue;
                }
                $amount = min($monthly, $remaining);

                $newAccum = (float) $asset->accumulated_depreciation + $amount;
                $newBook = (float) $asset->cost - $newAccum;
                $asset->update(['accumulated_depreciation' => $newAccum, 'book_value' => $newBook]);

                $entries[] = DepreciationEntry::create([
                    'asset_id' => $asset->id, 'period' => $period, 'amount' => $amount, 'book_value' => $newBook,
                ]);
                $total += $amount;
            }
        });

        if ($total > 0) {
            $this->bus->publish('asset.depreciation.posted', ['period' => $period, 'amount' => round($total, 2)]);
        }

        return ['period' => $period, 'entries' => count($entries), 'total' => round($total, 2)];
    }
}
