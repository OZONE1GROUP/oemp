<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('am_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->integer('useful_life_years')->default(5);
            $table->timestamps();
        });

        Schema::create('am_maintenance_plans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('asset_id')->constrained('assets')->cascadeOnDelete();
            $table->string('name');
            $table->integer('frequency_days')->default(30);
            $table->string('task');
            $table->date('next_due');
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('am_maintenance_work_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('asset_id')->constrained('assets')->cascadeOnDelete();
            $table->unsignedBigInteger('plan_id')->nullable();
            $table->string('type')->default('CM');
            $table->string('description');
            $table->string('status')->default('open');
            $table->date('scheduled_date')->nullable();
            $table->date('completed_date')->nullable();
            $table->decimal('cost', 15, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('am_meters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('asset_id')->constrained('assets')->cascadeOnDelete();
            $table->string('name');
            $table->string('unit');
            $table->decimal('current_reading', 15, 2)->default(0);
            $table->decimal('trigger_threshold', 15, 2)->nullable();
            $table->timestamps();
        });

        Schema::create('am_meter_readings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('meter_id')->constrained('am_meters')->cascadeOnDelete();
            $table->decimal('reading', 15, 2)->default(0);
            $table->timestamp('read_at')->index();
        });

        Schema::create('am_depreciation_entries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('asset_id')->constrained('assets')->cascadeOnDelete();
            $table->string('period');
            $table->decimal('amount', 15, 2)->default(0);
            $table->decimal('book_value', 15, 2)->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('am_depreciation_entries');
        Schema::dropIfExists('am_meter_readings');
        Schema::dropIfExists('am_meters');
        Schema::dropIfExists('am_maintenance_work_orders');
        Schema::dropIfExists('am_maintenance_plans');
        Schema::dropIfExists('am_categories');
    }
};
