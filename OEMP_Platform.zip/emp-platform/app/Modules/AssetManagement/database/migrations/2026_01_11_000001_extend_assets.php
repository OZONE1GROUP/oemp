<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('assets', function (Blueprint $table) {
            foreach ([['category_id','bigint'],['location','str'],['cost','dec'],['salvage_value','dec'],
                      ['useful_life_years','int'],['depreciation_method','str'],
                      ['accumulated_depreciation','dec'],['book_value','dec']] as [$c,$t]) {
                if (! Schema::hasColumn('assets', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'dec' => $table->decimal($c, 15, 2)->default(0),
                        'int' => $table->integer($c)->default(0),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('assets', function (Blueprint $table) {
            $table->dropColumn(['category_id','location','cost','salvage_value','useful_life_years','depreciation_method','accumulated_depreciation','book_value']);
        });
    }
};
