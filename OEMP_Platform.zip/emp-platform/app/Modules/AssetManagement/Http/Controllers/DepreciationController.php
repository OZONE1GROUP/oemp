<?php

namespace App\Modules\AssetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AssetManagement\Models\DepreciationEntry;
use App\Modules\AssetManagement\Services\DepreciationService;
use Illuminate\Http\Request;

class DepreciationController extends Controller
{
    public function schedule(Request $request)
    {
        return DepreciationEntry::when($request->asset_id, fn ($q) => $q->where('asset_id', $request->asset_id))
            ->latest()->paginate(100);
    }

    /** Run straight-line depreciation for a period (e.g. 2026-07). */
    public function run(Request $request, DepreciationService $svc)
    {
        $period = $request->validate(['period' => ['required', 'string', 'max:7']])['period'];

        return $svc->runPeriod($period);
    }
}
