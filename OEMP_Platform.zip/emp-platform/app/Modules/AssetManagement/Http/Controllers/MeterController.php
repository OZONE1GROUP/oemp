<?php

namespace App\Modules\AssetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AssetManagement\Models\Meter;
use App\Modules\AssetManagement\Models\MaintenanceWorkOrder;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class MeterController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'asset_id' => ['required', 'integer', 'exists:assets,id'],
            'name' => ['required', 'string', 'max:80'],
            'unit' => ['required', 'string', 'max:20'],
            'trigger_threshold' => ['nullable', 'numeric'],
        ]);

        return response()->json(Meter::create(array_merge($data, ['current_reading' => 0])), 201);
    }

    /** Record a reading; if it crosses the threshold, raise a condition-based CM order. */
    public function record(Request $request, Meter $meter, EventBus $bus)
    {
        $reading = $request->validate(['reading' => ['required', 'numeric']])['reading'];
        $meter->readings()->create(['reading' => $reading, 'read_at' => now()]);
        $meter->update(['current_reading' => $reading]);

        if ($meter->trigger_threshold !== null && $reading >= $meter->trigger_threshold) {
            MaintenanceWorkOrder::create([
                'asset_id' => $meter->asset_id,
                'type' => 'CM',
                'description' => "Condition-based: {$meter->name} reached {$reading} {$meter->unit}",
                'status' => 'open',
                'scheduled_date' => now()->toDateString(),
            ]);
            $bus->publish('asset.maintenance.triggered', ['asset_id' => $meter->asset_id, 'meter' => $meter->name]);
        }

        return $meter->fresh();
    }
}
