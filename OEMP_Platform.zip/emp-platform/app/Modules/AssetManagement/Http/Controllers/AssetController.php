<?php

namespace App\Modules\AssetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AssetManagement\Models\Asset;
use Illuminate\Http\Request;

class AssetController extends Controller
{
    public function index(Request $request)
    {
        return Asset::when($request->q, fn ($q) => $q->where('name', 'like', "%{$request->q}%")->orWhere('asset_no', 'like', "%{$request->q}%"))
            ->orderBy('asset_no')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'asset_no' => ['required', 'string', 'max:40'],
            'name' => ['required', 'string', 'max:150'],
            'category_id' => ['nullable', 'integer', 'exists:am_categories,id'],
            'location' => ['nullable', 'string', 'max:150'],
            'acquired_at' => ['required', 'date'],
            'cost' => ['required', 'numeric', 'min:0'],
            'salvage_value' => ['nullable', 'numeric', 'min:0'],
            'useful_life_years' => ['required', 'integer', 'min:1'],
            'depreciation_method' => ['nullable', 'in:straight_line,reducing_balance'],
        ]);

        return response()->json(Asset::create(array_merge($data, [
            'status' => 'active',
            'depreciation_method' => $data['depreciation_method'] ?? 'straight_line',
            'salvage_value' => $data['salvage_value'] ?? 0,
            'accumulated_depreciation' => 0,
            'book_value' => $data['cost'],
        ])), 201);
    }

    public function show(Asset $asset)
    {
        return $asset->load('meters', 'maintenanceOrders');
    }
}
