<?php

namespace App\Modules\AssetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AssetManagement\Models\MaintenancePlan;
use App\Modules\AssetManagement\Models\MaintenanceWorkOrder;
use App\Modules\AssetManagement\Services\MaintenanceService;
use Illuminate\Http\Request;

class MaintenanceController extends Controller
{
    public function plans()
    {
        return MaintenancePlan::latest()->paginate(50);
    }

    public function storePlan(Request $request)
    {
        $data = $request->validate([
            'asset_id' => ['required', 'integer', 'exists:assets,id'],
            'name' => ['required', 'string', 'max:120'],
            'frequency_days' => ['required', 'integer', 'min:1'],
            'task' => ['required', 'string', 'max:255'],
            'next_due' => ['required', 'date'],
        ]);

        return response()->json(MaintenancePlan::create(array_merge($data, ['active' => true])), 201);
    }

    public function generateDue(MaintenanceService $svc)
    {
        return ['generated' => $svc->generateDue()];
    }

    public function workOrders(Request $request)
    {
        return MaintenanceWorkOrder::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function complete(Request $request, MaintenanceWorkOrder $workOrder)
    {
        $data = $request->validate(['cost' => ['nullable', 'numeric', 'min:0']]);
        $workOrder->update(['status' => 'completed', 'completed_date' => now()->toDateString(), 'cost' => $data['cost'] ?? 0]);

        return $workOrder;
    }
}
