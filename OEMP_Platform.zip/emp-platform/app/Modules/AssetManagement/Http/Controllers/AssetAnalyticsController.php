<?php

namespace App\Modules\AssetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AssetAnalyticsController extends Controller
{
    /** Net book value by category. */
    public function valueByCategory()
    {
        return DB::table('assets as a')
            ->leftJoin('am_categories as c', 'c.id', '=', 'a.category_id')
            ->where('a.status', 'active')
            ->groupBy('c.name')
            ->select('c.name as category', DB::raw('SUM(a.cost) as cost'), DB::raw('SUM(a.book_value) as book_value'))
            ->get();
    }

    /** Maintenance cost and volume (last 12 months). */
    public function maintenanceCost()
    {
        return DB::table('am_maintenance_work_orders')
            ->where('status', 'completed')
            ->where('completed_date', '>=', now()->subYear())
            ->groupBy('type')
            ->select('type', DB::raw('COUNT(*) as orders'), DB::raw('SUM(cost) as cost'))
            ->get();
    }
}
