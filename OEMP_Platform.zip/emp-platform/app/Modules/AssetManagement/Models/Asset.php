<?php

namespace App\Modules\AssetManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Asset extends BaseModel
{
    protected $table = 'assets';
    protected $fillable = ['tenant_id','asset_no','name','category_id','category','location','status',
        'acquired_at','cost','salvage_value','useful_life_years','depreciation_method',
        'accumulated_depreciation','book_value'];
    protected $casts = ['acquired_at' => 'date', 'cost' => 'decimal:2', 'salvage_value' => 'decimal:2',
        'useful_life_years' => 'integer', 'accumulated_depreciation' => 'decimal:2', 'book_value' => 'decimal:2'];

    public function meters(): HasMany
    {
        return $this->hasMany(Meter::class);
    }

    public function maintenanceOrders(): HasMany
    {
        return $this->hasMany(MaintenanceWorkOrder::class);
    }
}
