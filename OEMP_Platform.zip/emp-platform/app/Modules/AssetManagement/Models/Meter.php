<?php

namespace App\Modules\AssetManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Meter extends BaseModel
{
    protected $table = 'am_meters';
    protected $fillable = ['tenant_id','asset_id','name','unit','current_reading','trigger_threshold'];
    protected $casts = ['current_reading' => 'decimal:2', 'trigger_threshold' => 'decimal:2'];

    public function readings(): HasMany
    {
        return $this->hasMany(MeterReading::class, 'meter_id');
    }
}
