<?php

namespace App\Modules\AssetManagement\Models;

use App\Core\Support\BaseModel;

class MaintenancePlan extends BaseModel
{
    protected $table = 'am_maintenance_plans';
    protected $fillable = ['tenant_id', 'asset_id', 'name', 'frequency_days', 'task', 'next_due', 'active'];
    protected $casts = ['next_due' => 'date', 'frequency_days' => 'integer', 'active' => 'boolean'];

}
