<?php

namespace App\Modules\AssetManagement\Models;

use App\Core\Support\BaseModel;

class MaintenanceWorkOrder extends BaseModel
{
    protected $table = 'am_maintenance_work_orders';
    protected $fillable = ['tenant_id', 'asset_id', 'plan_id', 'type', 'description', 'status', 'scheduled_date', 'completed_date', 'cost'];
    protected $casts = ['scheduled_date' => 'date', 'completed_date' => 'date', 'cost' => 'decimal:2'];

}
