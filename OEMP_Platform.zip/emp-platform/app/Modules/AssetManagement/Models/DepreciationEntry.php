<?php

namespace App\Modules\AssetManagement\Models;

use App\Core\Support\BaseModel;

class DepreciationEntry extends BaseModel
{
    protected $table = 'am_depreciation_entries';
    protected $fillable = ['tenant_id', 'asset_id', 'period', 'amount', 'book_value'];
    protected $casts = ['amount' => 'decimal:2', 'book_value' => 'decimal:2'];

}
