<?php

namespace App\Modules\AssetManagement\Models;

use App\Core\Support\BaseModel;

class MeterReading extends BaseModel
{
    protected $table = 'am_meter_readings';
    protected $fillable = ['tenant_id', 'meter_id', 'reading', 'read_at'];
    protected $casts = ['reading' => 'decimal:2', 'read_at' => 'datetime'];

}
