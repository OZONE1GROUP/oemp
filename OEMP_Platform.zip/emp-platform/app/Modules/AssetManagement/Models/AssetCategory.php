<?php

namespace App\Modules\AssetManagement\Models;

use App\Core\Support\BaseModel;

class AssetCategory extends BaseModel
{
    protected $table = 'am_categories';
    protected $fillable = ['tenant_id', 'code', 'name', 'useful_life_years'];
    protected $casts = ['useful_life_years' => 'integer'];

}
