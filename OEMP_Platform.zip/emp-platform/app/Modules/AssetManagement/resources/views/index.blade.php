<div class="emp-module" data-module="asset_management">
    <h3>Assets</h3>
    <p class="text-muted">AssetManagement module &mdash; managed by the EMP platform core.</p>
</div>
