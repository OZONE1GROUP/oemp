<?php

namespace App\Modules\LeaseManagement;

use App\Core\Support\ModuleServiceProvider;

class LeaseManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'lease_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
