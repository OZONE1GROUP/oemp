<?php

namespace App\Modules\FacilityManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FacilityManagement\Models\Contractor;
use App\Modules\FacilityManagement\Models\PermitToWork;
use Illuminate\Http\Request;

class ContractorController extends Controller
{
    public function index()
    {
        return Contractor::orderBy('name')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:20'],
            'name' => ['required', 'string', 'max:150'],
            'trade' => ['nullable', 'string', 'max:60'],
            'rating' => ['nullable', 'numeric', 'min:0', 'max:5'],
        ]);

        return response()->json(Contractor::create(array_merge($data, ['status' => 'active'])), 201);
    }

    public function issuePermit(Request $request)
    {
        $data = $request->validate([
            'service_request_id' => ['required', 'integer', 'exists:facility_service_requests,id'],
            'contractor_id' => ['required', 'integer', 'exists:fm_contractors,id'],
            'type' => ['required', 'in:hot_work,electrical,confined_space,working_at_height,general'],
            'valid_from' => ['required', 'date'],
            'valid_to' => ['required', 'date', 'after_or_equal:valid_from'],
        ]);

        return response()->json(PermitToWork::create(array_merge($data, ['status' => 'active'])), 201);
    }
}
