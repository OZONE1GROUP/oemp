<?php

namespace App\Modules\FacilityManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FacilityManagement\Models\Sla;
use Illuminate\Http\Request;

class SlaController extends Controller
{
    public function index()
    {
        return Sla::orderBy('resolution_hours')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:80'],
            'priority' => ['required', 'in:low,medium,high,urgent'],
            'response_hours' => ['required', 'integer', 'min:1'],
            'resolution_hours' => ['required', 'integer', 'min:1'],
        ]);

        return response()->json(Sla::create($data), 201);
    }
}
