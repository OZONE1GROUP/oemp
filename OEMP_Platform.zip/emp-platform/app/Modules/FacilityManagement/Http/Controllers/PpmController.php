<?php

namespace App\Modules\FacilityManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FacilityManagement\Models\PpmSchedule;
use App\Modules\FacilityManagement\Models\ServiceRequest;
use App\Modules\FacilityManagement\Services\SlaService;
use Illuminate\Http\Request;

class PpmController extends Controller
{
    public function index()
    {
        return PpmSchedule::latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'facility_id' => ['nullable', 'integer', 'exists:fm_facilities,id'],
            'equipment_id' => ['nullable', 'integer', 'exists:fm_equipment,id'],
            'task' => ['required', 'string', 'max:200'],
            'frequency_days' => ['required', 'integer', 'min:1'],
            'next_due' => ['required', 'date'],
        ]);

        return response()->json(PpmSchedule::create(array_merge($data, ['active' => true])), 201);
    }

    /** Turn due PPM schedules into service requests and roll the schedule forward. */
    public function generateDue(SlaService $sla)
    {
        $count = 0;
        PpmSchedule::where('active', true)->whereDate('next_due', '<=', now())->get()->each(function ($ppm) use (&$count, $sla) {
            $due = $sla->dueFor('medium');
            ServiceRequest::create([
                'ticket_no' => 'PPM-' . now()->format('YmdHis') . $ppm->id,
                'facility_id' => $ppm->facility_id,
                'category' => 'preventive_maintenance',
                'priority' => 'medium',
                'status' => 'open',
                'sla_id' => $due['sla_id'],
                'due_at' => $due['due_at'],
                'source' => 'ppm',
            ]);
            $ppm->update(['next_due' => now()->addDays($ppm->frequency_days)->toDateString()]);
            $count++;
        });

        return ['generated' => $count];
    }
}
