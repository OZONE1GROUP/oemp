<?php

namespace App\Modules\FacilityManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FacilityManagement\Models\ServiceRequest;
use App\Modules\FacilityManagement\Services\SlaService;
use Illuminate\Http\Request;

class ServiceRequestController extends Controller
{
    public function index(Request $request)
    {
        return ServiceRequest::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function store(Request $request, SlaService $sla)
    {
        $data = $request->validate([
            'facility_id' => ['nullable', 'integer', 'exists:fm_facilities,id'],
            'location' => ['nullable', 'string', 'max:150'],
            'category' => ['required', 'string', 'max:60'],
            'priority' => ['required', 'in:low,medium,high,urgent'],
        ]);
        $due = $sla->dueFor($data['priority']);

        return response()->json(ServiceRequest::create(array_merge($data, [
            'ticket_no' => 'FSR-' . now()->format('YmdHis'),
            'status' => 'open',
            'sla_id' => $due['sla_id'],
            'due_at' => $due['due_at'],
            'source' => 'internal',
        ])), 201);
    }

    public function assign(Request $request, ServiceRequest $serviceRequest)
    {
        $data = $request->validate(['contractor_id' => ['required', 'integer', 'exists:fm_contractors,id']]);
        $serviceRequest->update(['contractor_id' => $data['contractor_id'], 'status' => 'assigned']);

        return $serviceRequest;
    }

    public function resolve(ServiceRequest $serviceRequest)
    {
        $serviceRequest->update(['status' => 'resolved']);

        return $serviceRequest;
    }
}
