<?php

namespace App\Modules\FacilityManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FacilityManagement\Models\Facility;
use App\Modules\FacilityManagement\Models\Floor;
use App\Modules\FacilityManagement\Models\Space;
use Illuminate\Http\Request;

class FacilityController extends Controller
{
    public function index()
    {
        return Facility::with('floors.spaces')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:20'],
            'name' => ['required', 'string', 'max:120'],
            'address' => ['nullable', 'string', 'max:255'],
        ]);

        return response()->json(Facility::create($data), 201);
    }

    public function storeFloor(Request $request)
    {
        $data = $request->validate([
            'facility_id' => ['required', 'integer', 'exists:fm_facilities,id'],
            'code' => ['required', 'string', 'max:20'],
            'name' => ['required', 'string', 'max:120'],
            'area' => ['nullable', 'numeric', 'min:0'],
        ]);

        return response()->json(Floor::create($data), 201);
    }

    public function storeSpace(Request $request)
    {
        $data = $request->validate([
            'floor_id' => ['required', 'integer', 'exists:fm_floors,id'],
            'code' => ['required', 'string', 'max:20'],
            'name' => ['required', 'string', 'max:120'],
            'type' => ['nullable', 'in:office,meeting,common,plant,retail,storage'],
            'capacity' => ['nullable', 'integer', 'min:0'],
        ]);

        return response()->json(Space::create(array_merge($data, ['occupied' => 0])), 201);
    }
}
