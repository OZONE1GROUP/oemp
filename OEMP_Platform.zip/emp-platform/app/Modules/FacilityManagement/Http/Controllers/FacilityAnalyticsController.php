<?php

namespace App\Modules\FacilityManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class FacilityAnalyticsController extends Controller
{
    /** Open service requests by priority. */
    public function openRequests()
    {
        return DB::table('facility_service_requests')
            ->whereNotIn('status', ['resolved', 'closed'])
            ->groupBy('priority')
            ->select('priority', DB::raw('COUNT(*) as count'))
            ->get();
    }

    /** SLA breaches: open requests past their due time. */
    public function slaBreaches()
    {
        $breached = DB::table('facility_service_requests')
            ->whereNotIn('status', ['resolved', 'closed'])
            ->whereNotNull('due_at')
            ->where('due_at', '<', now())
            ->count();

        return ['breached' => $breached];
    }

    /** Space occupancy by facility. */
    public function occupancy()
    {
        return DB::table('fm_spaces as s')
            ->join('fm_floors as f', 'f.id', '=', 's.floor_id')
            ->groupBy('f.facility_id')
            ->select('f.facility_id', DB::raw('SUM(s.capacity) as capacity'), DB::raw('SUM(s.occupied) as occupied'))
            ->get();
    }
}
