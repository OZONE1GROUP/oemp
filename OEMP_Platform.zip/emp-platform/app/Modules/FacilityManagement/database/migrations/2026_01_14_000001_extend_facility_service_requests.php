<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('facility_service_requests', function (Blueprint $table) {
            foreach ([['facility_id','bigint'],['sla_id','bigint'],['due_at','ts'],['source','str'],['contractor_id','bigint']] as [$c,$t]) {
                if (! Schema::hasColumn('facility_service_requests', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'ts' => $table->timestamp($c)->nullable(),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('facility_service_requests', function (Blueprint $table) {
            $table->dropColumn(['facility_id','sla_id','due_at','source','contractor_id']);
        });
    }
};
