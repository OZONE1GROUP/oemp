<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('fm_facilities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->string('address')->nullable();
            $table->timestamps();
        });

        Schema::create('fm_floors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('facility_id')->constrained('fm_facilities')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->decimal('area', 15, 2)->nullable();
            $table->timestamps();
        });

        Schema::create('fm_spaces', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('floor_id')->constrained('fm_floors')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->string('type')->nullable();
            $table->integer('capacity')->default(0);
            $table->integer('occupied')->default(0);
            $table->timestamps();
        });

        Schema::create('fm_equipment', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('facility_id')->nullable()->constrained('fm_facilities')->nullOnDelete();
            $table->string('name');
            $table->string('type')->nullable();
            $table->string('status')->default('operational');
            $table->timestamps();
        });

        Schema::create('fm_slas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('priority');
            $table->integer('response_hours')->default(4);
            $table->integer('resolution_hours')->default(48);
            $table->timestamps();
        });

        Schema::create('fm_ppm_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->unsignedBigInteger('equipment_id')->nullable();
            $table->unsignedBigInteger('facility_id')->nullable();
            $table->string('task');
            $table->integer('frequency_days')->default(90);
            $table->date('next_due');
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('fm_contractors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->string('trade')->nullable();
            $table->decimal('rating', 3, 1)->default(0);
            $table->string('status')->default('active');
            $table->timestamps();
        });

        Schema::create('fm_permits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('service_request_id')->constrained('facility_service_requests')->cascadeOnDelete();
            $table->foreignId('contractor_id')->constrained('fm_contractors');
            $table->string('type');
            $table->date('valid_from');
            $table->date('valid_to');
            $table->string('status')->default('active');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('fm_permits');
        Schema::dropIfExists('fm_contractors');
        Schema::dropIfExists('fm_ppm_schedules');
        Schema::dropIfExists('fm_slas');
        Schema::dropIfExists('fm_equipment');
        Schema::dropIfExists('fm_spaces');
        Schema::dropIfExists('fm_floors');
        Schema::dropIfExists('fm_facilities');
    }
};
