<?php

use Illuminate\Support\Facades\Route;
use App\Modules\FacilityManagement\Http\Controllers\FacilityController;
use App\Modules\FacilityManagement\Http\Controllers\ServiceRequestController;
use App\Modules\FacilityManagement\Http\Controllers\PpmController;
use App\Modules\FacilityManagement\Http\Controllers\ContractorController;
use App\Modules\FacilityManagement\Http\Controllers\SlaController;
use App\Modules\FacilityManagement\Http\Controllers\FacilityAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.facility_management'])
    ->prefix('api/facility')
    ->group(function () {
        Route::get('facilities', [FacilityController::class, 'index']);
        Route::post('facilities', [FacilityController::class, 'store']);
        Route::post('floors', [FacilityController::class, 'storeFloor']);
        Route::post('spaces', [FacilityController::class, 'storeSpace']);

        Route::get('service-requests', [ServiceRequestController::class, 'index']);
        Route::post('service-requests', [ServiceRequestController::class, 'store']);
        Route::post('service-requests/{serviceRequest}/assign', [ServiceRequestController::class, 'assign']);
        Route::post('service-requests/{serviceRequest}/resolve', [ServiceRequestController::class, 'resolve']);

        Route::get('ppm', [PpmController::class, 'index']);
        Route::post('ppm', [PpmController::class, 'store']);
        Route::post('ppm/generate-due', [PpmController::class, 'generateDue']);

        Route::get('contractors', [ContractorController::class, 'index']);
        Route::post('contractors', [ContractorController::class, 'store']);
        Route::post('permits', [ContractorController::class, 'issuePermit']);

        Route::get('slas', [SlaController::class, 'index']);
        Route::post('slas', [SlaController::class, 'store']);

        Route::get('analytics/open-requests', [FacilityAnalyticsController::class, 'openRequests']);
        Route::get('analytics/sla-breaches', [FacilityAnalyticsController::class, 'slaBreaches']);
        Route::get('analytics/occupancy', [FacilityAnalyticsController::class, 'occupancy']);
    });
