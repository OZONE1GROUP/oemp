<div class="emp-module" data-module="facility_management">
    <h3>ServiceRequests</h3>
    <p class="text-muted">FacilityManagement module &mdash; managed by the EMP platform core.</p>
</div>
