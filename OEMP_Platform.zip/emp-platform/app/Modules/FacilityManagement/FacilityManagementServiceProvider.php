<?php

namespace App\Modules\FacilityManagement;

use App\Core\Support\ModuleServiceProvider;
use App\Core\Events\EventBus;
use App\Modules\FacilityManagement\Models\ServiceRequest;
use App\Modules\FacilityManagement\Services\SlaService;

class FacilityManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'facility_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }

    public function boot(): void
    {
        parent::boot();

        /** @var EventBus $bus */
        $bus = $this->app->make(EventBus::class);

        // Property Management tenant requests become facility service requests.
        $bus->subscribe('property.maintenance.requested', function ($payload) {
            $sla = app(SlaService::class)->dueFor($payload['priority'] ?? 'medium');
            ServiceRequest::create([
                'ticket_no' => 'FSR-' . now()->format('YmdHis'),
                'category' => $payload['category'] ?? 'general',
                'priority' => $payload['priority'] ?? 'medium',
                'status' => 'open',
                'sla_id' => $sla['sla_id'],
                'due_at' => $sla['due_at'],
                'source' => 'property_management',
            ]);
        });
    }
}
