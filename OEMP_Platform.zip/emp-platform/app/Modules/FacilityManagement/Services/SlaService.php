<?php

namespace App\Modules\FacilityManagement\Services;

use App\Modules\FacilityManagement\Models\Sla;
use Illuminate\Support\Carbon;

class SlaService
{
    /** Resolve the SLA for a priority and return the due timestamp from now. */
    public function dueFor(string $priority): array
    {
        $sla = Sla::where('priority', $priority)->first();
        $hours = $sla?->resolution_hours ?? 48;

        return ['sla_id' => $sla?->id, 'due_at' => Carbon::now()->addHours($hours)];
    }
}
