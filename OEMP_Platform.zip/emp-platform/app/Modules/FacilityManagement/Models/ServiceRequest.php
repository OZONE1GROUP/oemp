<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;

class ServiceRequest extends BaseModel
{
    protected $table = 'facility_service_requests';
    protected $fillable = ['tenant_id', 'ticket_no', 'facility_id', 'location', 'category', 'priority', 'status', 'sla_id', 'due_at', 'source', 'contractor_id'];
    protected $casts = ['due_at' => 'datetime'];

}
