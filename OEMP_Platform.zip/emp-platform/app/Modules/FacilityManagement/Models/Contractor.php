<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;

class Contractor extends BaseModel
{
    protected $table = 'fm_contractors';
    protected $fillable = ['tenant_id', 'code', 'name', 'trade', 'rating', 'status'];
    protected $casts = ['rating' => 'decimal:1'];

}
