<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;

class FacilityEquipment extends BaseModel
{
    protected $table = 'fm_equipment';
    protected $fillable = ['tenant_id', 'facility_id', 'name', 'type', 'status'];

}
