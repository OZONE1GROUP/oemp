<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;

class Space extends BaseModel
{
    protected $table = 'fm_spaces';
    protected $fillable = ['tenant_id', 'floor_id', 'code', 'name', 'type', 'capacity', 'occupied'];
    protected $casts = ['capacity' => 'integer', 'occupied' => 'integer'];

}
