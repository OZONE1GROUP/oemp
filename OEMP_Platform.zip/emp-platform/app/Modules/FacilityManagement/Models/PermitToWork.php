<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;

class PermitToWork extends BaseModel
{
    protected $table = 'fm_permits';
    protected $fillable = ['tenant_id', 'service_request_id', 'contractor_id', 'type', 'valid_from', 'valid_to', 'status'];
    protected $casts = ['valid_from' => 'date', 'valid_to' => 'date'];

}
