<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;

class Sla extends BaseModel
{
    protected $table = 'fm_slas';
    protected $fillable = ['tenant_id', 'name', 'priority', 'response_hours', 'resolution_hours'];
    protected $casts = ['response_hours' => 'integer', 'resolution_hours' => 'integer'];

}
