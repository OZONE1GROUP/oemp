<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Floor extends BaseModel
{
    protected $table = 'fm_floors';
    protected $fillable = ['tenant_id', 'facility_id', 'code', 'name', 'area'];
    protected $casts = ['area' => 'decimal:2'];

    public function spaces(): HasMany
    {
        return $this->hasMany(Space::class);
    }
}
