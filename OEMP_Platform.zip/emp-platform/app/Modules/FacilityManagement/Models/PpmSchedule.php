<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;

class PpmSchedule extends BaseModel
{
    protected $table = 'fm_ppm_schedules';
    protected $fillable = ['tenant_id', 'equipment_id', 'facility_id', 'task', 'frequency_days', 'next_due', 'active'];
    protected $casts = ['frequency_days' => 'integer', 'next_due' => 'date', 'active' => 'boolean'];

}
