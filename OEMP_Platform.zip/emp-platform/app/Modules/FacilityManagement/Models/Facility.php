<?php

namespace App\Modules\FacilityManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Facility extends BaseModel
{
    protected $table = 'fm_facilities';
    protected $fillable = ['tenant_id', 'code', 'name', 'address'];

    public function floors(): HasMany
    {
        return $this->hasMany(Floor::class);
    }
}
