<div class="emp-module" data-module="budgeting">
    <h3>Budgets</h3>
    <p class="text-muted">Budgeting module &mdash; managed by the EMP platform core.</p>
</div>
