<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('budgeting_budgets', function (Blueprint $table) {
            foreach ([['fiscal_year','int'],['version','int'],['status','str']] as [$c,$t]) {
                if (! Schema::hasColumn('budgeting_budgets', $c)) {
                    $t === 'int' ? $table->integer($c)->nullable() : $table->string($c)->default('draft');
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('budgeting_budgets', function (Blueprint $table) {
            $table->dropColumn(['fiscal_year', 'version', 'status']);
        });
    }
};
