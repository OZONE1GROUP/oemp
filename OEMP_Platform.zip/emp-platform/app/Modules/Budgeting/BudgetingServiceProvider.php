<?php

namespace App\Modules\Budgeting;

use App\Core\Support\ModuleServiceProvider;

class BudgetingServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'budgeting';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
