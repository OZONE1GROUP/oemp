<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Budgeting\Http\Controllers\BudgetController;
use App\Modules\Budgeting\Http\Controllers\ForecastController;
use App\Modules\Budgeting\Http\Controllers\VarianceController;
use App\Modules\Budgeting\Http\Controllers\BudgetAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.budgeting'])
    ->prefix('api/budgeting')
    ->group(function () {
        Route::get('budgets', [BudgetController::class, 'index']);
        Route::post('budgets', [BudgetController::class, 'store']);
        Route::post('budgets/{budget}/revise', [BudgetController::class, 'revise']);
        Route::post('budgets/{budget}/approve', [BudgetController::class, 'approve']);

        Route::get('forecasts', [ForecastController::class, 'index']);
        Route::post('forecasts', [ForecastController::class, 'store']);

        Route::get('variance', [VarianceController::class, 'report']);

        Route::get('analytics/by-department', [BudgetAnalyticsController::class, 'byDepartment']);
        Route::get('analytics/summary', [BudgetAnalyticsController::class, 'summary']);
    });
