<?php

namespace App\Modules\Budgeting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class BudgetAnalyticsController extends Controller
{
    /** Budget totals by department. */
    public function byDepartment()
    {
        return DB::table('budgeting_budgets')
            ->groupBy('department')
            ->select('department', DB::raw('SUM(amount) as budget'), DB::raw('SUM(forecast) as forecast'))
            ->get();
    }

    /** Budget vs forecast summary. */
    public function summary()
    {
        return DB::table('budgeting_budgets')
            ->select(DB::raw('SUM(amount) as total_budget'), DB::raw('SUM(forecast) as total_forecast'))
            ->first();
    }
}
