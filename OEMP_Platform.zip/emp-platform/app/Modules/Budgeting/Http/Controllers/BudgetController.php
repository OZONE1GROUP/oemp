<?php

namespace App\Modules\Budgeting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Budgeting\Models\Budget;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class BudgetController extends Controller
{
    public function index(Request $request)
    {
        return Budget::with('lines')
            ->when($request->fiscal_year, fn ($q) => $q->where('fiscal_year', $request->fiscal_year))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'fiscal_year' => ['required', 'integer'],
            'department' => ['nullable', 'string', 'max:80'],
            'lines' => ['required', 'array', 'min:1'],
            'lines.*.account_code' => ['required', 'string', 'max:20'],
            'lines.*.period' => ['required', 'string', 'max:7'],
            'lines.*.amount' => ['required', 'numeric'],
        ]);

        return DB::transaction(function () use ($data) {
            $budget = Budget::create([
                'name' => $data['name'], 'fiscal_year' => $data['fiscal_year'],
                'department' => $data['department'] ?? null, 'version' => 1,
                'status' => 'draft', 'amount' => collect($data['lines'])->sum('amount'), 'forecast' => 0,
            ]);
            foreach ($data['lines'] as $l) {
                $budget->lines()->create($l);
            }

            return response()->json($budget->load('lines'), 201);
        });
    }

    /** Create a new version (copy of lines) for re-planning. */
    public function revise(Budget $budget)
    {
        return DB::transaction(function () use ($budget) {
            $copy = $budget->replicate(['created_at', 'updated_at']);
            $copy->version = $budget->version + 1;
            $copy->status = 'draft';
            $copy->save();
            foreach ($budget->lines as $line) {
                $copy->lines()->create($line->only(['account_code', 'period', 'amount']));
            }

            return $copy->load('lines');
        });
    }

    public function approve(Budget $budget)
    {
        $budget->update(['status' => 'approved']);

        return $budget;
    }
}
