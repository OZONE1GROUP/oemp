<?php

namespace App\Modules\Budgeting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Budgeting\Models\Forecast;
use App\Modules\Budgeting\Models\Budget;
use Illuminate\Http\Request;

class ForecastController extends Controller
{
    public function index(Request $request)
    {
        return Forecast::when($request->budget_id, fn ($q) => $q->where('budget_id', $request->budget_id))
            ->orderBy('period')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'budget_id' => ['required', 'integer', 'exists:budgeting_budgets,id'],
            'period' => ['required', 'string', 'max:7'],
            'amount' => ['required', 'numeric'],
            'method' => ['required', 'in:manual,run_rate,trend'],
        ]);
        $fc = Forecast::updateOrCreate(
            ['budget_id' => $data['budget_id'], 'period' => $data['period']],
            ['amount' => $data['amount'], 'method' => $data['method']]
        );
        Budget::where('id', $data['budget_id'])->update(['forecast' => Forecast::where('budget_id', $data['budget_id'])->sum('amount')]);

        return $fc;
    }
}
