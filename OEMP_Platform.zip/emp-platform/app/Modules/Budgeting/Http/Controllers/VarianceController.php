<?php

namespace App\Modules\Budgeting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class VarianceController extends Controller
{
    /**
     * Actual-vs-budget variance by account. Budget from budgeting_lines; actuals
     * from posted ERP GL journal lines (net debit) for the same period.
     */
    public function report(Request $request)
    {
        $budgetId = $request->validate(['budget_id' => ['required', 'integer', 'exists:budgeting_budgets,id']])['budget_id'];

        $budget = DB::table('budgeting_lines')
            ->where('budget_id', $budgetId)
            ->groupBy('account_code')
            ->select('account_code', DB::raw('SUM(amount) as budget'))
            ->get()->keyBy('account_code');

        $actuals = DB::table('erp_gl_journal_lines as l')
            ->join('erp_gl_journals as j', 'j.id', '=', 'l.journal_id')
            ->join('erp_gl_accounts as a', 'a.id', '=', 'l.account_id')
            ->where('j.posted', true)
            ->groupBy('a.code')
            ->select('a.code', DB::raw('SUM(l.debit - l.credit) as actual'))
            ->get()->keyBy('code');

        $rows = [];
        foreach ($budget as $code => $b) {
            $actual = (float) optional($actuals->get($code))->actual;
            $rows[] = [
                'account_code' => $code,
                'budget' => round((float) $b->budget, 2),
                'actual' => round($actual, 2),
                'variance' => round((float) $b->budget - $actual, 2),
                'variance_pct' => $b->budget != 0 ? round(((float) $b->budget - $actual) / (float) $b->budget * 100, 1) : null,
            ];
        }

        return $rows;
    }
}
