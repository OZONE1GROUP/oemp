<?php

namespace App\Modules\Budgeting\Models;

use App\Core\Support\BaseModel;

class Forecast extends BaseModel
{
    protected $table = 'budgeting_forecasts';
    protected $fillable = ['tenant_id', 'budget_id', 'period', 'amount', 'method'];
    protected $casts = ['amount' => 'decimal:2'];

}
