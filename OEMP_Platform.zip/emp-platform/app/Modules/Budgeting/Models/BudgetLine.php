<?php

namespace App\Modules\Budgeting\Models;

use App\Core\Support\BaseModel;

class BudgetLine extends BaseModel
{
    protected $table = 'budgeting_lines';
    protected $fillable = ['tenant_id', 'budget_id', 'account_code', 'period', 'amount'];
    protected $casts = ['amount' => 'decimal:2'];

}
