<?php

namespace App\Modules\Budgeting\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Budget extends BaseModel
{
    protected $table = 'budgeting_budgets';
    protected $fillable = ['tenant_id','name','fiscal_year','department','version','amount','forecast','status','period'];
    protected $casts = ['fiscal_year' => 'integer', 'version' => 'integer', 'amount' => 'decimal:2', 'forecast' => 'decimal:2'];

    public function lines(): HasMany
    {
        return $this->hasMany(BudgetLine::class);
    }
}
