<?php

namespace App\Modules\Dcim\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Dcim\Models\EnvReading;
use App\Modules\Dcim\Models\CoolingUnit;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class EnvironmentalController extends Controller
{
    /** Record an environmental reading (temperature/humidity), typically from IoT. */
    public function record(Request $request, EventBus $bus)
    {
        $data = $request->validate([
            'data_center_id' => ['nullable', 'integer', 'exists:dcim_data_centers,id'],
            'rack_id' => ['nullable', 'integer', 'exists:dcim_racks,id'],
            'metric' => ['required', 'in:temperature,humidity,airflow'],
            'value' => ['required', 'numeric'],
        ]);
        $reading = EnvReading::create(array_merge($data, ['recorded_at' => now()]));

        // Simple thermal threshold alerting.
        if ($data['metric'] === 'temperature' && $data['value'] > 27) {
            $bus->publish('dcim.thermal.alert', ['rack_id' => $data['rack_id'] ?? null, 'value' => $data['value']]);
        }

        return response()->json($reading, 201);
    }

    public function coolingUnits()
    {
        return CoolingUnit::get();
    }

    public function storeCooling(Request $request)
    {
        $data = $request->validate([
            'data_center_id' => ['required', 'integer', 'exists:dcim_data_centers,id'],
            'name' => ['required', 'string', 'max:80'],
            'type' => ['nullable', 'in:crac,crah,chiller,inrow'],
            'capacity_kw' => ['nullable', 'numeric', 'min:0'],
        ]);

        return response()->json(CoolingUnit::create(array_merge($data, ['status' => 'running'])), 201);
    }
}
