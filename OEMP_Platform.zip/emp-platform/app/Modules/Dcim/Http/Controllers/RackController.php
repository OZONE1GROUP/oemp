<?php

namespace App\Modules\Dcim\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Dcim\Models\Rack;
use App\Modules\Dcim\Models\RackDevice;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class RackController extends Controller
{
    public function index(Request $request)
    {
        return Rack::with('devices')
            ->when($request->data_center_id, fn ($q) => $q->where('data_center_id', $request->data_center_id))
            ->orderBy('code')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:30'],
            'data_center_id' => ['required', 'integer', 'exists:dcim_data_centers,id'],
            'u_capacity' => ['required', 'integer', 'min:1', 'max:60'],
        ]);

        return response()->json(Rack::create(array_merge($data, ['u_used' => 0, 'status' => 'active'])), 201);
    }

    /** Mount a device into contiguous rack U-space, validating capacity & overlap. */
    public function mount(Request $request, Rack $rack)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'type' => ['required', 'in:server,switch,storage,router,firewall,other'],
            'u_start' => ['required', 'integer', 'min:1'],
            'u_size' => ['required', 'integer', 'min:1'],
            'power_watts' => ['nullable', 'integer', 'min:0'],
        ]);

        return DB::transaction(function () use ($rack, $data) {
            $rack = Rack::lockForUpdate()->find($rack->id);
            $end = $data['u_start'] + $data['u_size'] - 1;
            abort_if($end > $rack->u_capacity, 422, 'Device exceeds rack capacity.');

            // overlap check
            $overlap = RackDevice::where('rack_id', $rack->id)
                ->where('u_start', '<=', $end)
                ->whereRaw('(u_start + u_size - 1) >= ?', [$data['u_start']])
                ->exists();
            abort_if($overlap, 422, 'U-space overlaps an existing device.');

            $device = RackDevice::create(array_merge($data, ['rack_id' => $rack->id, 'status' => 'active', 'power_watts' => $data['power_watts'] ?? 0]));
            $rack->increment('u_used', $data['u_size']);

            return response()->json($device, 201);
        });
    }
}
