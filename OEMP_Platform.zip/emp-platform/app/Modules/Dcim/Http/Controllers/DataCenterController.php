<?php

namespace App\Modules\Dcim\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Dcim\Models\DataCenter;
use Illuminate\Http\Request;

class DataCenterController extends Controller
{
    public function index()
    {
        return DataCenter::withCount('racks')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:20'],
            'name' => ['required', 'string', 'max:120'],
            'location' => ['nullable', 'string', 'max:150'],
        ]);

        return response()->json(DataCenter::create($data), 201);
    }
}
