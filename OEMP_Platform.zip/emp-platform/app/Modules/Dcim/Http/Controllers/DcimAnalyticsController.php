<?php

namespace App\Modules\Dcim\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class DcimAnalyticsController extends Controller
{
    /** Rack space utilisation. */
    public function rackUtilisation()
    {
        return DB::table('dcim_racks')
            ->select(DB::raw('SUM(u_capacity) as total_u'), DB::raw('SUM(u_used) as used_u'),
                DB::raw('ROUND(CASE WHEN SUM(u_capacity) > 0 THEN SUM(u_used)/SUM(u_capacity)*100 ELSE 0 END, 1) as utilisation_pct'))
            ->first();
    }

    /** IT power load (kW) from rack device power draw. */
    public function powerLoad()
    {
        $itWatts = DB::table('dcim_rack_devices')->sum('power_watts');

        return ['it_load_kw' => round((float) $itWatts / 1000, 2)];
    }

    /**
     * PUE = total facility power / IT power. Facility power approximated from
     * power-feed capacity utilisation; IT power from device draw.
     */
    public function pue()
    {
        $itKw = (float) DB::table('dcim_rack_devices')->sum('power_watts') / 1000;
        $facilityKw = (float) DB::table('dcim_power_feeds')->sum('capacity_kw');
        // Fallback: assume facility ~1.6x IT if no feed data.
        $facility = $facilityKw > 0 ? min($facilityKw, $itKw * 2) : $itKw * 1.6;
        $pue = $itKw > 0 ? round(max($facility, $itKw) / $itKw, 2) : null;

        return ['it_kw' => round($itKw, 2), 'facility_kw' => round($facility, 2), 'pue' => $pue];
    }
}
