<?php

namespace App\Modules\Dcim\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Dcim\Models\PowerFeed;
use App\Modules\Dcim\Models\Pdu;
use Illuminate\Http\Request;

class PowerController extends Controller
{
    public function feeds()
    {
        return PowerFeed::get();
    }

    public function storeFeed(Request $request)
    {
        $data = $request->validate([
            'data_center_id' => ['required', 'integer', 'exists:dcim_data_centers,id'],
            'name' => ['required', 'string', 'max:80'],
            'capacity_kw' => ['required', 'numeric', 'min:0'],
        ]);

        return response()->json(PowerFeed::create($data), 201);
    }

    public function pdus(Request $request)
    {
        return Pdu::when($request->rack_id, fn ($q) => $q->where('rack_id', $request->rack_id))->get();
    }

    public function storePdu(Request $request)
    {
        $data = $request->validate([
            'rack_id' => ['required', 'integer', 'exists:dcim_racks,id'],
            'name' => ['required', 'string', 'max:80'],
            'capacity_amps' => ['required', 'numeric', 'min:0'],
            'load_amps' => ['nullable', 'numeric', 'min:0'],
        ]);

        return response()->json(Pdu::create(array_merge($data, ['load_amps' => $data['load_amps'] ?? 0])), 201);
    }
}
