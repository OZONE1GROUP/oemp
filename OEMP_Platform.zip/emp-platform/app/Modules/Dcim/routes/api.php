<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Dcim\Http\Controllers\DataCenterController;
use App\Modules\Dcim\Http\Controllers\RackController;
use App\Modules\Dcim\Http\Controllers\PowerController;
use App\Modules\Dcim\Http\Controllers\EnvironmentalController;
use App\Modules\Dcim\Http\Controllers\DcimAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.dcim'])
    ->prefix('api/dcim')
    ->group(function () {
        Route::get('data-centers', [DataCenterController::class, 'index']);
        Route::post('data-centers', [DataCenterController::class, 'store']);

        Route::get('racks', [RackController::class, 'index']);
        Route::post('racks', [RackController::class, 'store']);
        Route::post('racks/{rack}/mount', [RackController::class, 'mount']);

        Route::get('power/feeds', [PowerController::class, 'feeds']);
        Route::post('power/feeds', [PowerController::class, 'storeFeed']);
        Route::get('power/pdus', [PowerController::class, 'pdus']);
        Route::post('power/pdus', [PowerController::class, 'storePdu']);

        Route::post('environmental', [EnvironmentalController::class, 'record']);
        Route::get('cooling', [EnvironmentalController::class, 'coolingUnits']);
        Route::post('cooling', [EnvironmentalController::class, 'storeCooling']);

        Route::get('analytics/rack-utilisation', [DcimAnalyticsController::class, 'rackUtilisation']);
        Route::get('analytics/power-load', [DcimAnalyticsController::class, 'powerLoad']);
        Route::get('analytics/pue', [DcimAnalyticsController::class, 'pue']);
    });
