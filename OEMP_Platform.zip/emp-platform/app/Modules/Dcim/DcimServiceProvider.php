<?php

namespace App\Modules\Dcim;

use App\Core\Support\ModuleServiceProvider;

class DcimServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'dcim';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
