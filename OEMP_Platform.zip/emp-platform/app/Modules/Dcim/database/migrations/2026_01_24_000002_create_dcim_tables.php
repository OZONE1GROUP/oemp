<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('dcim_data_centers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->string('location')->nullable();
            $table->timestamps();
        });

        Schema::create('dcim_rack_devices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('rack_id')->constrained('dcim_racks')->cascadeOnDelete();
            $table->string('name');
            $table->string('type')->default('server');
            $table->integer('u_start');
            $table->integer('u_size');
            $table->integer('power_watts')->default(0);
            $table->string('status')->default('active');
            $table->timestamps();
        });

        Schema::create('dcim_power_feeds', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('data_center_id')->constrained('dcim_data_centers')->cascadeOnDelete();
            $table->string('name');
            $table->decimal('capacity_kw', 10, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('dcim_pdus', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('rack_id')->constrained('dcim_racks')->cascadeOnDelete();
            $table->string('name');
            $table->decimal('capacity_amps', 8, 2)->default(0);
            $table->decimal('load_amps', 8, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('dcim_cooling_units', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('data_center_id')->constrained('dcim_data_centers')->cascadeOnDelete();
            $table->string('name');
            $table->string('type')->nullable();
            $table->decimal('capacity_kw', 10, 2)->default(0);
            $table->string('status')->default('running');
            $table->timestamps();
        });

        Schema::create('dcim_env_readings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->unsignedBigInteger('data_center_id')->nullable();
            $table->unsignedBigInteger('rack_id')->nullable();
            $table->string('metric');
            $table->decimal('value', 10, 2)->default(0);
            $table->timestamp('recorded_at')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dcim_env_readings');
        Schema::dropIfExists('dcim_cooling_units');
        Schema::dropIfExists('dcim_pdus');
        Schema::dropIfExists('dcim_power_feeds');
        Schema::dropIfExists('dcim_rack_devices');
        Schema::dropIfExists('dcim_data_centers');
    }
};
