<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('dcim_racks', function (Blueprint $table) {
            if (! Schema::hasColumn('dcim_racks', 'data_center_id')) {
                $table->unsignedBigInteger('data_center_id')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('dcim_racks', function (Blueprint $table) {
            $table->dropColumn('data_center_id');
        });
    }
};
