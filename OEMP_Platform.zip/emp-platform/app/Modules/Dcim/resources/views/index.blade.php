<div class="emp-module" data-module="dcim">
    <h3>Racks</h3>
    <p class="text-muted">Dcim module &mdash; managed by the EMP platform core.</p>
</div>
