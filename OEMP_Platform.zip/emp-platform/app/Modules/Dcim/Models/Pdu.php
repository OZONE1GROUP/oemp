<?php

namespace App\Modules\Dcim\Models;

use App\Core\Support\BaseModel;

class Pdu extends BaseModel
{
    protected $table = 'dcim_pdus';
    protected $fillable = ['tenant_id', 'rack_id', 'name', 'capacity_amps', 'load_amps'];
    protected $casts = ['capacity_amps' => 'decimal:2', 'load_amps' => 'decimal:2'];

}
