<?php

namespace App\Modules\Dcim\Models;

use App\Core\Support\BaseModel;

class RackDevice extends BaseModel
{
    protected $table = 'dcim_rack_devices';
    protected $fillable = ['tenant_id', 'rack_id', 'name', 'type', 'u_start', 'u_size', 'power_watts', 'status'];
    protected $casts = ['u_start' => 'integer', 'u_size' => 'integer', 'power_watts' => 'integer'];

}
