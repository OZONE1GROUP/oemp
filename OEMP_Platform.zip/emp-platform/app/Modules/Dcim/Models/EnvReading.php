<?php

namespace App\Modules\Dcim\Models;

use App\Core\Support\BaseModel;

class EnvReading extends BaseModel
{
    protected $table = 'dcim_env_readings';
    protected $fillable = ['tenant_id', 'data_center_id', 'rack_id', 'metric', 'value', 'recorded_at'];
    protected $casts = ['value' => 'decimal:2', 'recorded_at' => 'datetime'];

}
