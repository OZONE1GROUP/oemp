<?php

namespace App\Modules\Dcim\Models;

use App\Core\Support\BaseModel;

class PowerFeed extends BaseModel
{
    protected $table = 'dcim_power_feeds';
    protected $fillable = ['tenant_id', 'data_center_id', 'name', 'capacity_kw'];
    protected $casts = ['capacity_kw' => 'decimal:2'];

}
