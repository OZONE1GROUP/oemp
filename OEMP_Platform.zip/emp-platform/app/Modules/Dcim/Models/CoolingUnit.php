<?php

namespace App\Modules\Dcim\Models;

use App\Core\Support\BaseModel;

class CoolingUnit extends BaseModel
{
    protected $table = 'dcim_cooling_units';
    protected $fillable = ['tenant_id', 'data_center_id', 'name', 'type', 'capacity_kw', 'status'];
    protected $casts = ['capacity_kw' => 'decimal:2'];

}
