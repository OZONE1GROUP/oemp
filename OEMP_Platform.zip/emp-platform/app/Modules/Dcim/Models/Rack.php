<?php

namespace App\Modules\Dcim\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Rack extends BaseModel
{
    protected $table = 'dcim_racks';
    protected $fillable = ['tenant_id','code','data_center','data_center_id','u_capacity','u_used','status'];
    protected $casts = ['u_capacity' => 'integer', 'u_used' => 'integer'];

    public function devices(): HasMany
    {
        return $this->hasMany(RackDevice::class);
    }
}
