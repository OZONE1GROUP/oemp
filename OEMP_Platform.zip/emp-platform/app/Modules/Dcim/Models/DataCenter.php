<?php

namespace App\Modules\Dcim\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class DataCenter extends BaseModel
{
    protected $table = 'dcim_data_centers';
    protected $fillable = ['tenant_id', 'code', 'name', 'location'];

    public function racks(): HasMany
    {
        return $this->hasMany(Rack::class);
    }
}
