<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cs_messages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('case_id')->constrained('cs_cases')->cascadeOnDelete();
            $table->string('author');
            $table->text('body');
            $table->boolean('internal')->default(false);
            $table->timestamps();
        });

        Schema::create('cs_slas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('priority');
            $table->integer('response_hours')->default(2);
            $table->integer('resolution_hours')->default(24);
            $table->timestamps();
        });

        Schema::create('cs_csat', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('case_id')->constrained('cs_cases')->cascadeOnDelete();
            $table->integer('score');
            $table->text('comment')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cs_csat');
        Schema::dropIfExists('cs_slas');
        Schema::dropIfExists('cs_messages');
    }
};
