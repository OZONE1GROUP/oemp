<?php

use Illuminate\Support\Facades\Route;
use App\Modules\CustomerService\Http\Controllers\CaseController;
use App\Modules\CustomerService\Http\Controllers\CsatController;
use App\Modules\CustomerService\Http\Controllers\CsAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.customer_service'])
    ->prefix('api/customer-service')
    ->group(function () {
        Route::get('cases', [CaseController::class, 'index']);
        Route::post('cases', [CaseController::class, 'store']);
        Route::post('cases/{case}/reply', [CaseController::class, 'reply']);
        Route::post('cases/{case}/assign', [CaseController::class, 'assign']);
        Route::post('cases/{case}/resolve', [CaseController::class, 'resolve']);
        Route::post('cases/{case}/escalate', [CaseController::class, 'escalate']);
        Route::post('cases/{case}/csat', [CsatController::class, 'store']);

        Route::get('analytics/by-channel', [CsAnalyticsController::class, 'byChannel']);
        Route::get('analytics/sla-breaches', [CsAnalyticsController::class, 'slaBreaches']);
        Route::get('analytics/csat', [CsAnalyticsController::class, 'csat']);
    });
