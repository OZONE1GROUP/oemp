<?php

namespace App\Modules\CustomerService\Models;

use App\Core\Support\BaseModel;

class CaseCsat extends BaseModel
{
    protected $table = 'cs_csat';
    protected $fillable = ['tenant_id', 'case_id', 'score', 'comment'];
    protected $casts = ['score' => 'integer'];

}
