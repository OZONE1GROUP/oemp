<?php

namespace App\Modules\CustomerService\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ServiceCase extends BaseModel
{
    protected $table = 'cs_cases';
    protected $fillable = ['tenant_id','case_no','customer','contact','subject','description','channel',
        'priority','status','agent_id','sla_id','due_at','first_response_at','escalation_level'];
    protected $casts = ['due_at' => 'datetime', 'first_response_at' => 'datetime', 'escalation_level' => 'integer'];

    public function messages(): HasMany
    {
        return $this->hasMany(CaseMessage::class, 'case_id');
    }
}
