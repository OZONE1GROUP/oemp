<?php

namespace App\Modules\CustomerService\Models;

use App\Core\Support\BaseModel;

class CsSla extends BaseModel
{
    protected $table = 'cs_slas';
    protected $fillable = ['tenant_id', 'priority', 'response_hours', 'resolution_hours'];
    protected $casts = ['response_hours' => 'integer', 'resolution_hours' => 'integer'];

}
