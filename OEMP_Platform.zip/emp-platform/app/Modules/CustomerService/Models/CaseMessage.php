<?php

namespace App\Modules\CustomerService\Models;

use App\Core\Support\BaseModel;

class CaseMessage extends BaseModel
{
    protected $table = 'cs_messages';
    protected $fillable = ['tenant_id', 'case_id', 'author', 'body', 'internal'];
    protected $casts = ['internal' => 'boolean'];

}
