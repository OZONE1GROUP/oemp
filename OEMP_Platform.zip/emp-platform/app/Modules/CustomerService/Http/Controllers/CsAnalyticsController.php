<?php

namespace App\Modules\CustomerService\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CsAnalyticsController extends Controller
{
    public function byChannel()
    {
        return DB::table('cs_cases')->groupBy('channel')->select('channel', DB::raw('COUNT(*) as count'))->get();
    }

    public function slaBreaches()
    {
        return ['breached' => DB::table('cs_cases')->whereNotIn('status', ['resolved', 'closed'])
            ->whereNotNull('due_at')->where('due_at', '<', now())->count()];
    }

    public function csat()
    {
        $avg = DB::table('cs_csat')->avg('score');

        return ['average_csat' => round((float) $avg, 2), 'responses' => DB::table('cs_csat')->count()];
    }
}
