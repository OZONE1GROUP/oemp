<?php

namespace App\Modules\CustomerService\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CustomerService\Models\ServiceCase;
use Illuminate\Http\Request;

class ServiceCaseController extends Controller
{
    public function index(Request $request)
    {
        return ServiceCase::query()
            ->when($request->q, fn ($qq) => $qq->where('case_no', 'like', "%{$request->q}%"))
            ->latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'case_no' => 'required|string|max:255',
            'customer' => 'nullable|string|max:255',
            'subject' => 'nullable|string|max:255',
            'channel' => 'nullable|string|max:255',
            'priority' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
        ]);

        return response()->json(ServiceCase::create($data), 201);
    }

    public function show(ServiceCase $customer_serviceItem)
    {
        return $customer_serviceItem;
    }

    public function update(Request $request, ServiceCase $customer_serviceItem)
    {
        $data = $request->validate([
            'case_no' => 'required|string|max:255',
            'customer' => 'nullable|string|max:255',
            'subject' => 'nullable|string|max:255',
            'channel' => 'nullable|string|max:255',
            'priority' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
        ]);
        $customer_serviceItem->update($data);

        return $customer_serviceItem;
    }

    public function destroy(ServiceCase $customer_serviceItem)
    {
        $customer_serviceItem->delete();

        return response()->noContent();
    }
}
