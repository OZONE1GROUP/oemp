<?php

namespace App\Modules\CustomerService\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CustomerService\Models\CaseCsat;
use App\Modules\CustomerService\Models\ServiceCase;
use Illuminate\Http\Request;

class CsatController extends Controller
{
    public function store(Request $request, ServiceCase $case)
    {
        abort_unless($case->status === 'resolved', 422, 'CSAT collected after resolution.');
        $data = $request->validate(['score' => ['required', 'integer', 'min:1', 'max:5'], 'comment' => ['nullable', 'string']]);

        return response()->json(CaseCsat::create(array_merge($data, ['case_id' => $case->id])), 201);
    }
}
