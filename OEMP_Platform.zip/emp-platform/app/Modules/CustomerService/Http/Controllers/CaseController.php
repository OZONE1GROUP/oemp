<?php

namespace App\Modules\CustomerService\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CustomerService\Models\ServiceCase;
use App\Modules\CustomerService\Models\CsSla;
use App\Core\Events\EventBus;
use Illuminate\Support\Carbon;
use Illuminate\Http\Request;

class CaseController extends Controller
{
    public function index(Request $request)
    {
        return ServiceCase::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->priority, fn ($q) => $q->where('priority', $request->priority))
            ->latest()->paginate(50);
    }

    public function store(Request $request, EventBus $bus)
    {
        $data = $request->validate([
            'customer' => ['required', 'string', 'max:150'],
            'contact' => ['nullable', 'string', 'max:120'],
            'subject' => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
            'channel' => ['required', 'in:email,phone,chat,web,social,whatsapp'],
            'priority' => ['required', 'in:low,medium,high,urgent'],
        ]);
        $sla = CsSla::where('priority', $data['priority'])->first();
        $case = ServiceCase::create(array_merge($data, [
            'case_no' => 'CASE-' . now()->format('YmdHis'),
            'status' => 'open', 'sla_id' => $sla?->id,
            'due_at' => Carbon::now()->addHours($sla?->resolution_hours ?? 24),
            'escalation_level' => 0,
        ]));
        $bus->publish('cs.case.created', ['id' => $case->id, 'priority' => $case->priority]);

        return response()->json($case, 201);
    }

    public function reply(Request $request, ServiceCase $case)
    {
        $data = $request->validate(['author' => ['required', 'string'], 'body' => ['required', 'string'], 'internal' => ['boolean']]);
        $case->messages()->create($data);
        if (! $case->first_response_at && ! ($data['internal'] ?? false)) {
            $case->update(['first_response_at' => now(), 'status' => 'in_progress']);
        }

        return $case->fresh()->load('messages');
    }

    public function assign(Request $request, ServiceCase $case)
    {
        $case->update(['agent_id' => $request->validate(['agent_id' => ['required', 'integer']])['agent_id'], 'status' => 'assigned']);

        return $case;
    }

    public function resolve(ServiceCase $case, EventBus $bus)
    {
        $case->update(['status' => 'resolved']);
        $bus->publish('cs.case.resolved', ['id' => $case->id]);

        return $case;
    }

    public function escalate(ServiceCase $case)
    {
        $case->increment('escalation_level');

        return $case;
    }
}
