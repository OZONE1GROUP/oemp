<div class="emp-module" data-module="customer_service">
    <h3>ServiceCases</h3>
    <p class="text-muted">CustomerService module &mdash; managed by the EMP platform core.</p>
</div>
