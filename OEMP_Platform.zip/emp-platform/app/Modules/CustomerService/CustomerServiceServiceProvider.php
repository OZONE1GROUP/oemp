<?php

namespace App\Modules\CustomerService;

use App\Core\Support\ModuleServiceProvider;

class CustomerServiceServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'customer_service';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
