<?php

namespace App\Modules\FleetManagement\Console;

use Illuminate\Console\Command;
use App\Modules\FleetManagement\Services\TelematicsIngestor;
use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

/**
 * Subscribes to vehicle GPS topics: fleet/gps/{plate} with JSON payload
 * {"lat":.., "lng":.., "speed":..}.
 */
class SubscribeTelematics extends Command
{
    protected $signature = 'fleet:subscribe';
    protected $description = 'Subscribe to vehicle GPS telematics over MQTT';

    public function handle(TelematicsIngestor $ingestor): int
    {
        $client = new MqttClient(env('MQTT_HOST', 'mqtt'), (int) env('MQTT_PORT', 1883), 'emp-fleet-' . uniqid());
        $client->connect((new ConnectionSettings)->setKeepAliveInterval(30), true);

        $this->info('Subscribed to fleet/gps/#');
        $client->subscribe('fleet/gps/#', function (string $topic, string $payload) use ($ingestor) {
            $plate = explode('/', $topic)[2] ?? 'unknown';
            $data = json_decode($payload, true) ?: [];
            $ingestor->ingest($plate, (float) ($data['lat'] ?? 0), (float) ($data['lng'] ?? 0), (float) ($data['speed'] ?? 0));
        }, 0);

        $client->loop(true);
        $client->disconnect();

        return self::SUCCESS;
    }
}
