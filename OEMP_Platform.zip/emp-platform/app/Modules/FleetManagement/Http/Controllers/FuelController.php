<?php

namespace App\Modules\FleetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FleetManagement\Models\FuelLog;
use Illuminate\Http\Request;

class FuelController extends Controller
{
    public function index(Request $request)
    {
        return FuelLog::when($request->vehicle_id, fn ($q) => $q->where('vehicle_id', $request->vehicle_id))
            ->latest('date')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'vehicle_id' => ['required', 'integer', 'exists:fleet_vehicles,id'],
            'date' => ['required', 'date'],
            'litres' => ['required', 'numeric', 'gt:0'],
            'cost' => ['required', 'numeric', 'min:0'],
            'odometer' => ['nullable', 'integer', 'min:0'],
        ]);

        return response()->json(FuelLog::create($data), 201);
    }
}
