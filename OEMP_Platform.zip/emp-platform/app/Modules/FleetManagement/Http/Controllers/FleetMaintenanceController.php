<?php

namespace App\Modules\FleetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FleetManagement\Models\VehicleMaintenance;
use Illuminate\Http\Request;

class FleetMaintenanceController extends Controller
{
    public function index(Request $request)
    {
        return VehicleMaintenance::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'vehicle_id' => ['required', 'integer', 'exists:fleet_vehicles,id'],
            'type' => ['required', 'in:service,repair,inspection,tyre'],
            'description' => ['nullable', 'string'],
            'due_odo' => ['nullable', 'integer'],
            'due_date' => ['nullable', 'date'],
        ]);

        return response()->json(VehicleMaintenance::create(array_merge($data, ['status' => 'due', 'cost' => 0])), 201);
    }

    public function complete(Request $request, VehicleMaintenance $maintenance)
    {
        $cost = $request->validate(['cost' => ['nullable', 'numeric', 'min:0']])['cost'] ?? 0;
        $maintenance->update(['status' => 'completed', 'cost' => $cost]);

        return $maintenance;
    }
}
