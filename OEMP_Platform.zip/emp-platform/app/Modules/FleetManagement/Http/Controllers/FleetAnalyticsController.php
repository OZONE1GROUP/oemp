<?php

namespace App\Modules\FleetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class FleetAnalyticsController extends Controller
{
    /** Fuel efficiency (distance per litre) per vehicle. */
    public function fuelEfficiency()
    {
        return DB::table('fleet_fuel_logs')
            ->groupBy('vehicle_id')
            ->select('vehicle_id', DB::raw('SUM(litres) as litres'), DB::raw('SUM(cost) as cost'))
            ->get();
    }

    /** Maintenance due (by date). */
    public function maintenanceDue()
    {
        return DB::table('fleet_maintenance')
            ->where('status', 'due')
            ->where(fn ($q) => $q->whereNull('due_date')->orWhere('due_date', '<=', now()->addDays(14)))
            ->get();
    }

    /** Drivers with licences expiring in 60 days. */
    public function licenceExpiry()
    {
        return DB::table('fleet_drivers')
            ->whereNotNull('license_expiry')
            ->where('license_expiry', '<=', now()->addDays(60))
            ->get(['id', 'name', 'license_no', 'license_expiry']);
    }
}
