<?php

namespace App\Modules\FleetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FleetManagement\Models\Driver;
use Illuminate\Http\Request;

class DriverController extends Controller
{
    public function index()
    {
        return Driver::orderBy('name')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'license_no' => ['required', 'string', 'max:40'],
            'license_expiry' => ['nullable', 'date'],
            'phone' => ['nullable', 'string', 'max:40'],
        ]);

        return response()->json(Driver::create(array_merge($data, ['status' => 'active'])), 201);
    }
}
