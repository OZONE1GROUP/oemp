<?php

namespace App\Modules\FleetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FleetManagement\Models\Trip;
use App\Modules\FleetManagement\Models\Vehicle;
use Illuminate\Http\Request;

class TripController extends Controller
{
    public function index(Request $request)
    {
        return Trip::when($request->vehicle_id, fn ($q) => $q->where('vehicle_id', $request->vehicle_id))
            ->latest()->paginate(50);
    }

    public function start(Request $request)
    {
        $data = $request->validate([
            'vehicle_id' => ['required', 'integer', 'exists:fleet_vehicles,id'],
            'driver_id' => ['required', 'integer', 'exists:fleet_drivers,id'],
            'purpose' => ['nullable', 'string', 'max:150'],
        ]);
        $vehicle = Vehicle::findOrFail($data['vehicle_id']);

        return response()->json(Trip::create(array_merge($data, [
            'start_at' => now(), 'start_odo' => $vehicle->odometer, 'status' => 'active',
        ])), 201);
    }

    /** End a trip; compute distance and update the vehicle odometer. */
    public function end(Request $request, Trip $trip)
    {
        $endOdo = $request->validate(['end_odo' => ['required', 'integer', 'gte:' . $trip->start_odo]])['end_odo'];
        $distance = $endOdo - $trip->start_odo;
        $trip->update(['end_at' => now(), 'end_odo' => $endOdo, 'distance' => $distance, 'status' => 'completed']);
        Vehicle::where('id', $trip->vehicle_id)->update(['odometer' => $endOdo]);

        return $trip;
    }
}
