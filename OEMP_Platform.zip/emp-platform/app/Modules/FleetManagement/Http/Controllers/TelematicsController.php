<?php

namespace App\Modules\FleetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FleetManagement\Models\GpsPing;
use App\Modules\FleetManagement\Services\TelematicsIngestor;
use Illuminate\Http\Request;

class TelematicsController extends Controller
{
    /** HTTP mirror of the MQTT telematics bridge. */
    public function ingest(Request $request, TelematicsIngestor $ingestor)
    {
        $data = $request->validate([
            'plate_no' => ['required', 'string'],
            'lat' => ['required', 'numeric'],
            'lng' => ['required', 'numeric'],
            'speed' => ['nullable', 'numeric'],
        ]);
        $ping = $ingestor->ingest($data['plate_no'], $data['lat'], $data['lng'], $data['speed'] ?? 0);
        abort_if($ping === null, 404, 'Unknown vehicle.');

        return response()->json($ping, 201);
    }

    public function pings(Request $request)
    {
        return GpsPing::where('vehicle_id', $request->vehicle_id)->latest('recorded_at')->limit(200)->get();
    }
}
