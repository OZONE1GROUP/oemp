<?php

namespace App\Modules\FleetManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FleetManagement\Models\Vehicle;
use Illuminate\Http\Request;

class VehicleController extends Controller
{
    public function index(Request $request)
    {
        return Vehicle::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->orderBy('plate_no')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'plate_no' => ['required', 'string', 'max:20'],
            'make' => ['required', 'string', 'max:60'],
            'model' => ['nullable', 'string', 'max:60'],
            'year' => ['nullable', 'integer'],
            'odometer' => ['nullable', 'integer', 'min:0'],
            'fuel_type' => ['nullable', 'in:petrol,diesel,electric,hybrid,cng'],
        ]);

        return response()->json(Vehicle::create(array_merge($data, ['status' => 'active', 'odometer' => $data['odometer'] ?? 0])), 201);
    }

    public function show(Vehicle $vehicle)
    {
        return $vehicle->load('trips');
    }

    public function liveMap()
    {
        return Vehicle::whereNotNull('last_lat')
            ->get(['id', 'plate_no', 'last_lat', 'last_lng', 'last_ping_at', 'status']);
    }
}
