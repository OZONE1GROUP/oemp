<?php

use Illuminate\Support\Facades\Route;
use App\Modules\FleetManagement\Http\Controllers\VehicleController;
use App\Modules\FleetManagement\Http\Controllers\DriverController;
use App\Modules\FleetManagement\Http\Controllers\TripController;
use App\Modules\FleetManagement\Http\Controllers\FuelController;
use App\Modules\FleetManagement\Http\Controllers\FleetMaintenanceController;
use App\Modules\FleetManagement\Http\Controllers\TelematicsController;
use App\Modules\FleetManagement\Http\Controllers\FleetAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.fleet_management'])
    ->prefix('api/fleet')
    ->group(function () {
        Route::get('vehicles', [VehicleController::class, 'index']);
        Route::post('vehicles', [VehicleController::class, 'store']);
        Route::get('vehicles/{vehicle}', [VehicleController::class, 'show']);
        Route::get('live-map', [VehicleController::class, 'liveMap']);

        Route::get('drivers', [DriverController::class, 'index']);
        Route::post('drivers', [DriverController::class, 'store']);

        Route::get('trips', [TripController::class, 'index']);
        Route::post('trips/start', [TripController::class, 'start']);
        Route::post('trips/{trip}/end', [TripController::class, 'end']);

        Route::get('fuel', [FuelController::class, 'index']);
        Route::post('fuel', [FuelController::class, 'store']);

        Route::get('maintenance', [FleetMaintenanceController::class, 'index']);
        Route::post('maintenance', [FleetMaintenanceController::class, 'store']);
        Route::post('maintenance/{maintenance}/complete', [FleetMaintenanceController::class, 'complete']);

        Route::post('telematics', [TelematicsController::class, 'ingest']);
        Route::get('telematics/pings', [TelematicsController::class, 'pings']);

        Route::get('analytics/fuel-efficiency', [FleetAnalyticsController::class, 'fuelEfficiency']);
        Route::get('analytics/maintenance-due', [FleetAnalyticsController::class, 'maintenanceDue']);
        Route::get('analytics/licence-expiry', [FleetAnalyticsController::class, 'licenceExpiry']);
    });
