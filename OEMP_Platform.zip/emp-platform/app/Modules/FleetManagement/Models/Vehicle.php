<?php

namespace App\Modules\FleetManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Vehicle extends BaseModel
{
    protected $table = 'fleet_vehicles';
    protected $fillable = ['tenant_id','plate_no','make','model','year','status','odometer',
        'fuel_type','driver_id','last_lat','last_lng','last_ping_at'];
    protected $casts = ['odometer' => 'integer', 'last_lat' => 'decimal:7', 'last_lng' => 'decimal:7', 'last_ping_at' => 'datetime'];

    public function trips(): HasMany
    {
        return $this->hasMany(Trip::class);
    }
}
