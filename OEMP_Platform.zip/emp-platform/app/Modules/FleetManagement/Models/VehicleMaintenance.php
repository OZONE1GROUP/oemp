<?php

namespace App\Modules\FleetManagement\Models;

use App\Core\Support\BaseModel;

class VehicleMaintenance extends BaseModel
{
    protected $table = 'fleet_maintenance';
    protected $fillable = ['tenant_id', 'vehicle_id', 'type', 'description', 'due_odo', 'due_date', 'status', 'cost'];
    protected $casts = ['due_odo' => 'integer', 'due_date' => 'date', 'cost' => 'decimal:2'];

}
