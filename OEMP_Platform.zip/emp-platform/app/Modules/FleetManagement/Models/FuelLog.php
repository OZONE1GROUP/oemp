<?php

namespace App\Modules\FleetManagement\Models;

use App\Core\Support\BaseModel;

class FuelLog extends BaseModel
{
    protected $table = 'fleet_fuel_logs';
    protected $fillable = ['tenant_id', 'vehicle_id', 'date', 'litres', 'cost', 'odometer'];
    protected $casts = ['date' => 'date', 'litres' => 'decimal:2', 'cost' => 'decimal:2', 'odometer' => 'integer'];

}
