<?php

namespace App\Modules\FleetManagement\Models;

use App\Core\Support\BaseModel;

class Trip extends BaseModel
{
    protected $table = 'fleet_trips';
    protected $fillable = ['tenant_id', 'vehicle_id', 'driver_id', 'start_at', 'end_at', 'start_odo', 'end_odo', 'distance', 'purpose', 'status'];
    protected $casts = ['start_at' => 'datetime', 'end_at' => 'datetime', 'start_odo' => 'integer', 'end_odo' => 'integer', 'distance' => 'integer'];

}
