<?php

namespace App\Modules\FleetManagement\Models;

use App\Core\Support\BaseModel;

class Driver extends BaseModel
{
    protected $table = 'fleet_drivers';
    protected $fillable = ['tenant_id', 'name', 'license_no', 'license_expiry', 'phone', 'status'];
    protected $casts = ['license_expiry' => 'date'];

}
