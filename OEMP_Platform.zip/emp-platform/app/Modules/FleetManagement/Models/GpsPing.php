<?php

namespace App\Modules\FleetManagement\Models;

use App\Core\Support\BaseModel;

class GpsPing extends BaseModel
{
    protected $table = 'fleet_gps_pings';
    protected $fillable = ['tenant_id', 'vehicle_id', 'lat', 'lng', 'speed', 'recorded_at'];
    protected $casts = ['lat' => 'decimal:7', 'lng' => 'decimal:7', 'speed' => 'decimal:2', 'recorded_at' => 'datetime'];

}
