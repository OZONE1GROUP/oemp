<div class="emp-module" data-module="fleet_management">
    <h3>Vehicles</h3>
    <p class="text-muted">FleetManagement module &mdash; managed by the EMP platform core.</p>
</div>
