<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('fleet_drivers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('license_no');
            $table->date('license_expiry')->nullable();
            $table->string('phone')->nullable();
            $table->string('status')->default('active');
            $table->timestamps();
        });

        Schema::create('fleet_trips', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('vehicle_id')->constrained('fleet_vehicles')->cascadeOnDelete();
            $table->unsignedBigInteger('driver_id')->nullable();
            $table->dateTime('start_at')->nullable();
            $table->dateTime('end_at')->nullable();
            $table->integer('start_odo')->default(0);
            $table->integer('end_odo')->nullable();
            $table->integer('distance')->default(0);
            $table->string('purpose')->nullable();
            $table->string('status')->default('active');
            $table->timestamps();
        });

        Schema::create('fleet_gps_pings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->constrained('fleet_vehicles')->cascadeOnDelete();
            $table->decimal('lat', 10, 7);
            $table->decimal('lng', 10, 7);
            $table->decimal('speed', 6, 2)->default(0);
            $table->timestamp('recorded_at')->index();
        });

        Schema::create('fleet_fuel_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('vehicle_id')->constrained('fleet_vehicles')->cascadeOnDelete();
            $table->date('date');
            $table->decimal('litres', 8, 2)->default(0);
            $table->decimal('cost', 12, 2)->default(0);
            $table->integer('odometer')->nullable();
            $table->timestamps();
        });

        Schema::create('fleet_maintenance', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('vehicle_id')->constrained('fleet_vehicles')->cascadeOnDelete();
            $table->string('type');
            $table->text('description')->nullable();
            $table->integer('due_odo')->nullable();
            $table->date('due_date')->nullable();
            $table->string('status')->default('due');
            $table->decimal('cost', 12, 2)->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('fleet_maintenance');
        Schema::dropIfExists('fleet_fuel_logs');
        Schema::dropIfExists('fleet_gps_pings');
        Schema::dropIfExists('fleet_trips');
        Schema::dropIfExists('fleet_drivers');
    }
};
