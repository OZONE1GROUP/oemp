<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('fleet_vehicles', function (Blueprint $table) {
            foreach ([['year','int'],['fuel_type','str'],['driver_id','bigint'],['last_lat','coord'],['last_lng','coord'],['last_ping_at','ts']] as [$c,$t]) {
                if (! Schema::hasColumn('fleet_vehicles', $c)) {
                    match ($t) {
                        'int' => $table->integer($c)->nullable(),
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'coord' => $table->decimal($c, 10, 7)->nullable(),
                        'ts' => $table->timestamp($c)->nullable(),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('fleet_vehicles', function (Blueprint $table) {
            $table->dropColumn(['year','fuel_type','driver_id','last_lat','last_lng','last_ping_at']);
        });
    }
};
