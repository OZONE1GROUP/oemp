<?php

namespace App\Modules\FleetManagement\Services;

use App\Modules\FleetManagement\Models\Vehicle;
use App\Modules\FleetManagement\Models\GpsPing;
use App\Core\Events\EventBus;

/**
 * Ingests a GPS fix (from MQTT or HTTP): records the ping, updates the vehicle's
 * live position, and publishes to the bus for live-map / geofence consumers.
 */
class TelematicsIngestor
{
    public function __construct(private EventBus $bus) {}

    public function ingest(string $plate, float $lat, float $lng, float $speed = 0): ?GpsPing
    {
        $vehicle = Vehicle::where('plate_no', $plate)->first();
        if (! $vehicle) {
            return null;
        }

        $ping = GpsPing::create([
            'vehicle_id' => $vehicle->id, 'lat' => $lat, 'lng' => $lng,
            'speed' => $speed, 'recorded_at' => now(),
        ]);
        $vehicle->update(['last_lat' => $lat, 'last_lng' => $lng, 'last_ping_at' => now()]);
        $this->bus->publish('fleet.gps', ['plate' => $plate, 'lat' => $lat, 'lng' => $lng, 'speed' => $speed]);

        return $ping;
    }
}
