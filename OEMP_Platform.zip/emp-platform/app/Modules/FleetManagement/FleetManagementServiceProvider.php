<?php

namespace App\Modules\FleetManagement;

use App\Core\Support\ModuleServiceProvider;
use App\Modules\FleetManagement\Console\SubscribeTelematics;

class FleetManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'fleet_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }

    public function boot(): void
    {
        parent::boot();

        if ($this->app->runningInConsole()) {
            $this->commands([SubscribeTelematics::class]);
        }
    }
}
