<?php

use Illuminate\Support\Facades\Route;
use App\Modules\AdminSystem\Http\Controllers\ParameterController;
use App\Modules\AdminSystem\Http\Controllers\JobController;
use App\Modules\AdminSystem\Http\Controllers\AuditController;
use App\Modules\AdminSystem\Http\Controllers\HealthController;
use App\Modules\AdminSystem\Http\Controllers\AnnouncementController;
use App\Modules\AdminSystem\Http\Controllers\BackupController;
use App\Modules\AdminSystem\Http\Controllers\AdminAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.admin_system'])
    ->prefix('api/admin')
    ->group(function () {
        Route::get('parameters', [ParameterController::class, 'index']);
        Route::post('parameters', [ParameterController::class, 'upsert']);

        Route::get('jobs', [JobController::class, 'index']);
        Route::post('jobs', [JobController::class, 'store']);
        Route::post('jobs/{job}/run', [JobController::class, 'run']);
        Route::get('jobs/{job}/runs', [JobController::class, 'runs']);

        Route::get('audit', [AuditController::class, 'index']);
        Route::get('health', [HealthController::class, 'status']);

        Route::get('announcements', [AnnouncementController::class, 'index']);
        Route::post('announcements', [AnnouncementController::class, 'store']);

        Route::get('backups', [BackupController::class, 'index']);
        Route::post('backups', [BackupController::class, 'store']);

        Route::get('analytics/overview', [AdminAnalyticsController::class, 'overview']);
        Route::get('analytics/job-health', [AdminAnalyticsController::class, 'jobHealth']);
    });
