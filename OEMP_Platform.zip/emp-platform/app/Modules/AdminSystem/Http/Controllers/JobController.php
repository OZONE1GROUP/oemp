<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AdminSystem\Models\ScheduledJob;
use App\Modules\AdminSystem\Models\JobRun;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class JobController extends Controller
{
    public function index()
    {
        return ScheduledJob::withCount('runs')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'cron' => ['required', 'string', 'max:40'],
            'command' => ['required', 'string', 'max:150'],
        ]);

        return response()->json(ScheduledJob::create(array_merge($data, ['status' => 'idle', 'active' => true])), 201);
    }

    /** Trigger a job run now and log the outcome. */
    public function run(ScheduledJob $job, EventBus $bus)
    {
        $start = microtime(true);
        // In production this dispatches the queued command; here we log a run.
        $job->update(['status' => 'running', 'last_run_at' => now()]);
        $run = JobRun::create([
            'scheduled_job_id' => $job->id, 'status' => 'success',
            'output' => "Executed {$job->command}", 'ran_at' => now(),
            'duration_ms' => (int) ((microtime(true) - $start) * 1000),
        ]);
        $job->update(['status' => 'idle']);
        $bus->publish('admin.job.ran', ['job' => $job->name]);

        return $run;
    }

    public function runs(ScheduledJob $job)
    {
        return $job->runs()->latest('ran_at')->paginate(50);
    }
}
