<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AdminSystem\Models\HealthCheck;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class HealthController extends Controller
{
    /** Live system health probe (database, cache) with latency + persistence. */
    public function status()
    {
        $results = [];

        $t = microtime(true);
        try {
            DB::select('select 1');
            $results[] = $this->record('database', 'up', $t);
        } catch (\Throwable $e) {
            $results[] = $this->record('database', 'down', $t);
        }

        $t = microtime(true);
        try {
            Cache::put('health:ping', 1, 5);
            Cache::get('health:ping');
            $results[] = $this->record('cache', 'up', $t);
        } catch (\Throwable $e) {
            $results[] = $this->record('cache', 'down', $t);
        }

        $healthy = collect($results)->every(fn ($r) => $r['status'] === 'up');

        return ['healthy' => $healthy, 'checks' => $results];
    }

    private function record(string $component, string $status, float $start): array
    {
        $latency = (int) ((microtime(true) - $start) * 1000);
        HealthCheck::create(['component' => $component, 'status' => $status, 'latency_ms' => $latency, 'checked_at' => now()]);

        return ['component' => $component, 'status' => $status, 'latency_ms' => $latency];
    }
}
