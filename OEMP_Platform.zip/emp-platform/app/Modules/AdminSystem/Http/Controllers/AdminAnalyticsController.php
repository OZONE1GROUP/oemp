<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AdminAnalyticsController extends Controller
{
    /** Platform overview: tenants, users, modules configured. */
    public function overview()
    {
        return [
            'tenants' => DB::table('tenants')->count(),
            'users' => DB::table('users')->count(),
            'modules' => count(config('emp.modules', [])),
            'active_entitlements' => DB::table('entitlements')->where('valid_to', '>=', now())->count(),
        ];
    }

    /** Recent job-run success rate. */
    public function jobHealth()
    {
        $ok = DB::table('admin_job_runs')->where('status', 'success')->count();
        $fail = DB::table('admin_job_runs')->where('status', 'failed')->count();
        $total = $ok + $fail;

        return ['success' => $ok, 'failed' => $fail, 'success_rate' => $total ? round($ok / $total * 100, 1) : 100];
    }
}
