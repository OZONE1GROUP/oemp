<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class AuditController extends Controller
{
    /** Read the platform-wide audit trail (Core audit_log). */
    public function index(Request $request)
    {
        return DB::table('audit_log')
            ->when($request->action, fn ($q) => $q->where('action', $request->action))
            ->when($request->user_id, fn ($q) => $q->where('user_id', $request->user_id))
            ->orderByDesc('created_at')->paginate(100);
    }
}
