<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AdminSystem\Models\SystemTask;
use Illuminate\Http\Request;

class SystemTaskController extends Controller
{
    public function index(Request $request)
    {
        return SystemTask::query()
            ->when($request->q, fn ($qq) => $qq->where('name', 'like', "%{$request->q}%"))
            ->latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'schedule' => 'nullable|string|max:255',
            'last_run' => 'nullable|date',
            'status' => 'nullable|string|max:255',
        ]);

        return response()->json(SystemTask::create($data), 201);
    }

    public function show(SystemTask $admin_systemItem)
    {
        return $admin_systemItem;
    }

    public function update(Request $request, SystemTask $admin_systemItem)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'schedule' => 'nullable|string|max:255',
            'last_run' => 'nullable|date',
            'status' => 'nullable|string|max:255',
        ]);
        $admin_systemItem->update($data);

        return $admin_systemItem;
    }

    public function destroy(SystemTask $admin_systemItem)
    {
        $admin_systemItem->delete();

        return response()->noContent();
    }
}
