<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AdminSystem\Models\BackupRecord;
use Illuminate\Http\Request;

class BackupController extends Controller
{
    public function index()
    {
        return BackupRecord::latest('created_at_ts')->paginate(50);
    }

    /** Register a backup run (actual backup performed by ops tooling / scheduler). */
    public function store(Request $request)
    {
        $data = $request->validate([
            'type' => ['required', 'in:database,files,full'],
            'disk' => ['required', 'string', 'max:40'],
            'size_mb' => ['nullable', 'numeric', 'min:0'],
        ]);

        return response()->json(BackupRecord::create(array_merge($data, [
            'status' => 'completed', 'created_at_ts' => now(),
        ])), 201);
    }
}
