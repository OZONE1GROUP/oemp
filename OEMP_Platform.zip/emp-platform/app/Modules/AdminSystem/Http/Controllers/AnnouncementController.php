<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AdminSystem\Models\Announcement;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class AnnouncementController extends Controller
{
    public function index()
    {
        return Announcement::latest()->paginate(50);
    }

    public function store(Request $request, EventBus $bus)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:150'],
            'body' => ['required', 'string'],
            'audience' => ['required', 'in:all,admins,tenant'],
        ]);
        $a = Announcement::create(array_merge($data, ['active' => true, 'published_at' => now()]));
        $bus->publish('admin.announcement.published', ['id' => $a->id]);

        return response()->json($a, 201);
    }
}
