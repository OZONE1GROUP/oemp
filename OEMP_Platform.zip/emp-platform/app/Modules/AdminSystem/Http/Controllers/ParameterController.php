<?php

namespace App\Modules\AdminSystem\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AdminSystem\Models\SystemParameter;
use Illuminate\Http\Request;

class ParameterController extends Controller
{
    public function index(Request $request)
    {
        return SystemParameter::when($request->group, fn ($q) => $q->where('group', $request->group))
            ->orderBy('group')->get();
    }

    public function upsert(Request $request)
    {
        $data = $request->validate([
            'group' => ['required', 'string', 'max:60'],
            'key' => ['required', 'string', 'max:120'],
            'value' => ['nullable'],
            'type' => ['required', 'in:string,number,boolean,json'],
            'description' => ['nullable', 'string'],
        ]);

        return SystemParameter::updateOrCreate(['group' => $data['group'], 'key' => $data['key']], $data);
    }
}
