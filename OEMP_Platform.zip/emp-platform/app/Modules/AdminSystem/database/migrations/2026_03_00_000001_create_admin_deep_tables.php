<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('admin_parameters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained('tenants')->nullOnDelete();
            $table->string('group');
            $table->string('key');
            $table->json('value')->nullable();
            $table->string('type')->default('string');
            $table->string('description')->nullable();
            $table->timestamps();
            $table->unique(['tenant_id', 'group', 'key']);
        });

        Schema::create('admin_scheduled_jobs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained('tenants')->nullOnDelete();
            $table->string('name');
            $table->string('cron');
            $table->string('command');
            $table->string('status')->default('idle');
            $table->timestamp('last_run_at')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('admin_job_runs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('scheduled_job_id')->constrained('admin_scheduled_jobs')->cascadeOnDelete();
            $table->string('status')->default('success');
            $table->text('output')->nullable();
            $table->timestamp('ran_at')->nullable();
            $table->integer('duration_ms')->default(0);
        });

        Schema::create('admin_health_checks', function (Blueprint $table) {
            $table->id();
            $table->string('component');
            $table->string('status');
            $table->integer('latency_ms')->default(0);
            $table->timestamp('checked_at')->nullable();
        });

        Schema::create('admin_announcements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained('tenants')->nullOnDelete();
            $table->string('title');
            $table->text('body');
            $table->string('audience')->default('all');
            $table->boolean('active')->default(true);
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
        });

        Schema::create('admin_backups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained('tenants')->nullOnDelete();
            $table->string('type');
            $table->string('disk');
            $table->decimal('size_mb', 12, 2)->default(0);
            $table->string('status')->default('completed');
            $table->timestamp('created_at_ts')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('admin_backups');
        Schema::dropIfExists('admin_announcements');
        Schema::dropIfExists('admin_health_checks');
        Schema::dropIfExists('admin_job_runs');
        Schema::dropIfExists('admin_scheduled_jobs');
        Schema::dropIfExists('admin_parameters');
    }
};
