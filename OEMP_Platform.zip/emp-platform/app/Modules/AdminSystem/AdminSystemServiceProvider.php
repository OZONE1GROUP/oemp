<?php

namespace App\Modules\AdminSystem;

use App\Core\Support\ModuleServiceProvider;

class AdminSystemServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'admin_system';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
