<div class="emp-module" data-module="admin_system">
    <h3>SystemTasks</h3>
    <p class="text-muted">AdminSystem module &mdash; managed by the EMP platform core.</p>
</div>
