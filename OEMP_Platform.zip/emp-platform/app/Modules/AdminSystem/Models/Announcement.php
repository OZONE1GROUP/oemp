<?php

namespace App\Modules\AdminSystem\Models;

use App\Core\Support\BaseModel;

class Announcement extends BaseModel
{
    protected $table = 'admin_announcements';
    protected $fillable = ['tenant_id', 'title', 'body', 'audience', 'active', 'published_at'];
    protected $casts = ['active' => 'boolean', 'published_at' => 'datetime'];

}
