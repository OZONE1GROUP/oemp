<?php

namespace App\Modules\AdminSystem\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ScheduledJob extends BaseModel
{
    protected $table = 'admin_scheduled_jobs';
    protected $fillable = ['tenant_id', 'name', 'cron', 'command', 'status', 'last_run_at', 'active'];
    protected $casts = ['last_run_at' => 'datetime', 'active' => 'boolean'];

    public function runs(): HasMany
    {
        return $this->hasMany(JobRun::class, 'scheduled_job_id');
    }
}
