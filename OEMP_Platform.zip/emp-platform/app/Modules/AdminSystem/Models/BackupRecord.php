<?php

namespace App\Modules\AdminSystem\Models;

use App\Core\Support\BaseModel;

class BackupRecord extends BaseModel
{
    protected $table = 'admin_backups';
    protected $fillable = ['tenant_id', 'type', 'disk', 'size_mb', 'status', 'created_at_ts'];
    protected $casts = ['size_mb' => 'decimal:2', 'created_at_ts' => 'datetime'];

}
