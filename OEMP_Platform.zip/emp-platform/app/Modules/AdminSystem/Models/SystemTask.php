<?php

namespace App\Modules\AdminSystem\Models;

use App\Core\Support\BaseModel;

class SystemTask extends BaseModel
{
    protected $table = 'admin_system_tasks';
    protected $fillable = ['tenant_id', 'name', 'schedule', 'last_run', 'status'];
    protected $casts = ['last_run' => 'datetime'];
}
