<?php

namespace App\Modules\AdminSystem\Models;

use App\Core\Support\BaseModel;

class HealthCheck extends BaseModel
{
    protected $table = 'admin_health_checks';
    protected $fillable = ['tenant_id', 'component', 'status', 'latency_ms', 'checked_at'];
    protected $casts = ['latency_ms' => 'integer', 'checked_at' => 'datetime'];

}
