<?php

namespace App\Modules\AdminSystem\Models;

use App\Core\Support\BaseModel;

class JobRun extends BaseModel
{
    protected $table = 'admin_job_runs';
    protected $fillable = ['tenant_id', 'scheduled_job_id', 'status', 'output', 'ran_at', 'duration_ms'];
    protected $casts = ['ran_at' => 'datetime', 'duration_ms' => 'integer'];

}
