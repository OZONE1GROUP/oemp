<?php

namespace App\Modules\AdminSystem\Models;

use App\Core\Support\BaseModel;

class SystemParameter extends BaseModel
{
    protected $table = 'admin_parameters';
    protected $fillable = ['tenant_id', 'group', 'key', 'value', 'type', 'description'];
    protected $casts = ['value' => 'json'];

}
