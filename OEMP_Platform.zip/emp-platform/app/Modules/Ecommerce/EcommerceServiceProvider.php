<?php

namespace App\Modules\Ecommerce;

use App\Core\Support\ModuleServiceProvider;

class EcommerceServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'ecommerce';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
