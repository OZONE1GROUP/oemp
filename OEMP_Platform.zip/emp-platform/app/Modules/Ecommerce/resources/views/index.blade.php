<div class="emp-module" data-module="ecommerce">
    <h3>StoreOrders</h3>
    <p class="text-muted">Ecommerce module &mdash; managed by the EMP platform core.</p>
</div>
