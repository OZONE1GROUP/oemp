<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ecom_orders', function (Blueprint $table) {
            foreach ([['email','str'],['subtotal','dec'],['shipping','dec'],['payment_status','str']] as [$c,$t]) {
                if (! Schema::hasColumn('ecom_orders', $c)) {
                    $t === 'dec' ? $table->decimal($c, 12, 2)->default(0) : $table->string($c)->nullable();
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('ecom_orders', function (Blueprint $table) {
            $table->dropColumn(['email', 'subtotal', 'shipping', 'payment_status']);
        });
    }
};
