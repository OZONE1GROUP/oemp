<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ecom_products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('sku');
            $table->string('name');
            $table->text('description')->nullable();
            $table->decimal('price', 12, 2)->default(0);
            $table->unsignedBigInteger('inventory_item_id')->nullable();
            $table->integer('stock')->default(0);
            $table->string('status')->default('active');
            $table->timestamps();
        });

        Schema::create('ecom_order_lines', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('ecom_orders')->cascadeOnDelete();
            $table->unsignedBigInteger('product_id')->nullable();
            $table->string('name');
            $table->integer('qty')->default(1);
            $table->decimal('unit_price', 12, 2)->default(0);
            $table->decimal('line_total', 12, 2)->default(0);
        });

        Schema::create('ecom_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('ecom_orders')->cascadeOnDelete();
            $table->string('provider');
            $table->decimal('amount', 12, 2)->default(0);
            $table->string('status')->default('captured');
            $table->string('reference')->nullable();
            $table->timestamps();
        });

        Schema::create('ecom_fulfilments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('ecom_orders')->cascadeOnDelete();
            $table->string('carrier')->nullable();
            $table->string('tracking_no')->nullable();
            $table->string('status')->default('pending');
            $table->timestamp('shipped_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ecom_fulfilments');
        Schema::dropIfExists('ecom_payments');
        Schema::dropIfExists('ecom_order_lines');
        Schema::dropIfExists('ecom_products');
    }
};
