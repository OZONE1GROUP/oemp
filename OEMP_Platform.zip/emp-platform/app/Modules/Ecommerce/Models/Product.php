<?php

namespace App\Modules\Ecommerce\Models;

use App\Core\Support\BaseModel;

class Product extends BaseModel
{
    protected $table = 'ecom_products';
    protected $fillable = ['tenant_id', 'sku', 'name', 'description', 'price', 'inventory_item_id', 'stock', 'status'];
    protected $casts = ['price' => 'decimal:2', 'stock' => 'integer'];

}
