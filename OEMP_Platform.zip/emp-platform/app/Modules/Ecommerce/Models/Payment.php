<?php

namespace App\Modules\Ecommerce\Models;

use App\Core\Support\BaseModel;

class Payment extends BaseModel
{
    protected $table = 'ecom_payments';
    protected $fillable = ['tenant_id', 'order_id', 'provider', 'amount', 'status', 'reference'];
    protected $casts = ['amount' => 'decimal:2'];

}
