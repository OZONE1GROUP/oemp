<?php

namespace App\Modules\Ecommerce\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class StoreOrder extends BaseModel
{
    protected $table = 'ecom_orders';
    protected $fillable = ['tenant_id','order_no','customer','email','channel','subtotal','shipping','total','status','payment_status'];
    protected $casts = ['subtotal' => 'decimal:2', 'shipping' => 'decimal:2', 'total' => 'decimal:2'];

    public function lines(): HasMany
    {
        return $this->hasMany(OrderLine::class, 'order_id');
    }
}
