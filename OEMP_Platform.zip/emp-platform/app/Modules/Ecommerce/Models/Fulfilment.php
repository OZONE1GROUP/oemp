<?php

namespace App\Modules\Ecommerce\Models;

use App\Core\Support\BaseModel;

class Fulfilment extends BaseModel
{
    protected $table = 'ecom_fulfilments';
    protected $fillable = ['tenant_id', 'order_id', 'carrier', 'tracking_no', 'status', 'shipped_at'];
    protected $casts = ['shipped_at' => 'datetime'];

}
