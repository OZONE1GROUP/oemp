<?php

namespace App\Modules\Ecommerce\Models;

use App\Core\Support\BaseModel;

class OrderLine extends BaseModel
{
    protected $table = 'ecom_order_lines';
    protected $fillable = ['tenant_id', 'order_id', 'product_id', 'name', 'qty', 'unit_price', 'line_total'];
    protected $casts = ['qty' => 'integer', 'unit_price' => 'decimal:2', 'line_total' => 'decimal:2'];

}
