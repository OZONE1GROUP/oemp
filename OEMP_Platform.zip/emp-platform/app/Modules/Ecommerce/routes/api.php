<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Ecommerce\Http\Controllers\ProductController;
use App\Modules\Ecommerce\Http\Controllers\OrderController;
use App\Modules\Ecommerce\Http\Controllers\FulfilmentController;
use App\Modules\Ecommerce\Http\Controllers\EcomAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.ecommerce'])
    ->prefix('api/ecommerce')
    ->group(function () {
        Route::get('products', [ProductController::class, 'index']);
        Route::post('products', [ProductController::class, 'store']);

        Route::get('orders', [OrderController::class, 'index']);
        Route::post('orders/checkout', [OrderController::class, 'checkout']);
        Route::post('orders/{order}/pay', [OrderController::class, 'pay']);
        Route::post('orders/{order}/ship', [FulfilmentController::class, 'ship']);

        Route::get('analytics/sales-by-day', [EcomAnalyticsController::class, 'salesByDay']);
        Route::get('analytics/top-products', [EcomAnalyticsController::class, 'topProducts']);
        Route::get('analytics/conversion', [EcomAnalyticsController::class, 'conversion']);
    });
