<?php

namespace App\Modules\Ecommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class EcomAnalyticsController extends Controller
{
    public function salesByDay()
    {
        return DB::table('ecom_orders')->where('created_at', '>=', now()->subDays(30))
            ->groupBy(DB::raw('DATE(created_at)'))
            ->select(DB::raw('DATE(created_at) as day'), DB::raw('COUNT(*) as orders'), DB::raw('SUM(total) as revenue'))
            ->orderBy('day')->get();
    }

    public function topProducts()
    {
        return DB::table('ecom_order_lines')->groupBy('name')
            ->select('name', DB::raw('SUM(qty) as qty'), DB::raw('SUM(line_total) as revenue'))
            ->orderByDesc('revenue')->limit(20)->get();
    }

    public function conversion()
    {
        $orders = DB::table('ecom_orders')->count();
        $paid = DB::table('ecom_orders')->where('payment_status', 'paid')->count();

        return ['orders' => $orders, 'paid' => $paid, 'payment_rate' => $orders ? round($paid / $orders * 100, 1) : 0];
    }
}
