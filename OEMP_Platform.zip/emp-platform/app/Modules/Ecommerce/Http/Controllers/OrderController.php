<?php

namespace App\Modules\Ecommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Ecommerce\Models\StoreOrder;
use App\Modules\Ecommerce\Models\Product;
use App\Modules\Ecommerce\Models\Payment;
use App\Modules\Inventory\Services\StockService;
use App\Modules\Inventory\Models\Item;
use App\Core\Events\EventBus;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        return StoreOrder::with('lines')->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    /** Place an order: price the cart, create order + lines, decrement product stock. */
    public function checkout(Request $request, EventBus $bus)
    {
        $data = $request->validate([
            'customer' => ['required', 'string', 'max:150'],
            'email' => ['nullable', 'email'],
            'channel' => ['nullable', 'in:web,mobile,marketplace'],
            'shipping' => ['nullable', 'numeric', 'min:0'],
            'lines' => ['required', 'array', 'min:1'],
            'lines.*.product_id' => ['required', 'integer', 'exists:ecom_products,id'],
            'lines.*.qty' => ['required', 'integer', 'gt:0'],
        ]);

        return DB::transaction(function () use ($data, $bus) {
            $subtotal = 0;
            $order = StoreOrder::create([
                'order_no' => 'ECO-' . now()->format('YmdHis'),
                'customer' => $data['customer'], 'email' => $data['email'] ?? null,
                'channel' => $data['channel'] ?? 'web', 'shipping' => $data['shipping'] ?? 0,
                'subtotal' => 0, 'total' => 0, 'status' => 'pending', 'payment_status' => 'unpaid',
            ]);
            foreach ($data['lines'] as $l) {
                $p = Product::lockForUpdate()->find($l['product_id']);
                abort_if($p->stock < $l['qty'], 422, "Insufficient stock for {$p->name}.");
                $lt = round($p->price * $l['qty'], 2);
                $subtotal += $lt;
                $order->lines()->create(['product_id' => $p->id, 'name' => $p->name, 'qty' => $l['qty'], 'unit_price' => $p->price, 'line_total' => $lt]);
                $p->decrement('stock', $l['qty']);
            }
            $order->update(['subtotal' => $subtotal, 'total' => $subtotal + $order->shipping]);
            $bus->publish('ecommerce.order.placed', ['id' => $order->id, 'total' => $order->total]);

            return response()->json($order->load('lines'), 201);
        });
    }

    public function pay(Request $request, StoreOrder $order, EventBus $bus)
    {
        $data = $request->validate([
            'provider' => ['required', 'in:stripe,paypal,card,cod'],
            'amount' => ['required', 'numeric', 'min:0'],
            'reference' => ['nullable', 'string'],
        ]);
        Payment::create(array_merge($data, ['order_id' => $order->id, 'status' => 'captured']));
        $order->update(['payment_status' => 'paid', 'status' => 'confirmed']);
        $bus->publish('ecommerce.order.paid', ['id' => $order->id]);

        return $order;
    }
}
