<?php

namespace App\Modules\Ecommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Ecommerce\Models\StoreOrder;
use Illuminate\Http\Request;

class StoreOrderController extends Controller
{
    public function index(Request $request)
    {
        return StoreOrder::query()
            ->when($request->q, fn ($qq) => $qq->where('order_no', 'like', "%{$request->q}%"))
            ->latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'order_no' => 'required|string|max:255',
            'customer' => 'nullable|string|max:255',
            'channel' => 'nullable|string|max:255',
            'total' => 'nullable|numeric',
            'status' => 'nullable|string|max:255',
        ]);

        return response()->json(StoreOrder::create($data), 201);
    }

    public function show(StoreOrder $ecommerceItem)
    {
        return $ecommerceItem;
    }

    public function update(Request $request, StoreOrder $ecommerceItem)
    {
        $data = $request->validate([
            'order_no' => 'required|string|max:255',
            'customer' => 'nullable|string|max:255',
            'channel' => 'nullable|string|max:255',
            'total' => 'nullable|numeric',
            'status' => 'nullable|string|max:255',
        ]);
        $ecommerceItem->update($data);

        return $ecommerceItem;
    }

    public function destroy(StoreOrder $ecommerceItem)
    {
        $ecommerceItem->delete();

        return response()->noContent();
    }
}
