<?php

namespace App\Modules\Ecommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Ecommerce\Models\StoreOrder;
use App\Modules\Ecommerce\Models\Fulfilment;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class FulfilmentController extends Controller
{
    public function ship(Request $request, StoreOrder $order, EventBus $bus)
    {
        abort_unless($order->payment_status === 'paid', 422, 'Order not paid.');
        $data = $request->validate(['carrier' => ['required', 'string'], 'tracking_no' => ['nullable', 'string']]);
        $f = Fulfilment::create(array_merge($data, ['order_id' => $order->id, 'status' => 'shipped', 'shipped_at' => now()]));
        $order->update(['status' => 'shipped']);
        $bus->publish('ecommerce.order.shipped', ['id' => $order->id]);

        return $f;
    }
}
