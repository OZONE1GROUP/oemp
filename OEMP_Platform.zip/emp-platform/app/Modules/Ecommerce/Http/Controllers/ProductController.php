<?php

namespace App\Modules\Ecommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Ecommerce\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        return Product::when($request->q, fn ($q) => $q->where('name', 'like', "%{$request->q}%"))
            ->where('status', 'active')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'sku' => ['required', 'string', 'max:40'],
            'name' => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
            'price' => ['required', 'numeric', 'min:0'],
            'inventory_item_id' => ['nullable', 'integer'],
            'stock' => ['nullable', 'integer', 'min:0'],
        ]);

        return response()->json(Product::create(array_merge($data, ['status' => 'active', 'stock' => $data['stock'] ?? 0])), 201);
    }
}
