<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class PurchaseOrderLine extends BaseModel
{
    protected $table = 'erp_purchase_order_lines';
    protected $fillable = ['tenant_id', 'purchase_order_id', 'description', 'qty', 'unit_price', 'line_total'];
    protected $casts = ['qty' => 'decimal:2', 'unit_price' => 'decimal:2', 'line_total' => 'decimal:2'];

}
