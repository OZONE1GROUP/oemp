<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class FiscalPeriod extends BaseModel
{
    protected $table = 'erp_fiscal_periods';
    protected $fillable = ['tenant_id', 'code', 'starts_on', 'ends_on', 'status'];
    protected $casts = ['starts_on' => 'date', 'ends_on' => 'date'];

}
