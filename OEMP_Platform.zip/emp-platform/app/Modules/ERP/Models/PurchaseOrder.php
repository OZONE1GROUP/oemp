<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PurchaseOrder extends BaseModel
{
    protected $table = 'erp_purchase_orders';
    protected $fillable = ['tenant_id', 'po_no', 'vendor_id', 'order_date', 'status', 'subtotal', 'tax', 'total'];
    protected $casts = ['order_date' => 'date', 'subtotal' => 'decimal:2', 'tax' => 'decimal:2', 'total' => 'decimal:2'];

    public function lines(): HasMany
    {
        return $this->hasMany(PurchaseOrderLine::class, 'purchase_order_id');
    }
}
