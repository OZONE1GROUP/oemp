<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class Customer extends BaseModel
{
    protected $table = 'erp_customers';
    protected $fillable = ['tenant_id', 'code', 'name', 'email', 'phone', 'credit_limit', 'payment_terms'];
    protected $casts = ['credit_limit' => 'decimal:2'];

}
