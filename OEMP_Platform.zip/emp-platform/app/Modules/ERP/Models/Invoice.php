<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class Invoice extends BaseModel
{
    protected $table = 'erp_invoices';
    protected $fillable = ['tenant_id', 'invoice_no', 'customer_id', 'sales_order_id', 'date', 'due_date', 'total', 'amount_paid', 'status'];
    protected $casts = ['date' => 'date', 'due_date' => 'date', 'total' => 'decimal:2', 'amount_paid' => 'decimal:2'];

}
