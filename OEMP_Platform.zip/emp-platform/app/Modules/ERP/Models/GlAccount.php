<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class GlAccount extends BaseModel
{
    protected $table = 'erp_gl_accounts';
    protected $fillable = ['tenant_id', 'code', 'name', 'type', 'parent_id', 'is_postable'];
    protected $casts = ['is_postable' => 'boolean'];

}
