<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class GlJournal extends BaseModel
{
    protected $table = 'erp_gl_journals';
    protected $fillable = ['tenant_id', 'journal_no', 'date', 'period_id', 'memo', 'source', 'posted'];
    protected $casts = ['date' => 'date', 'posted' => 'boolean'];

    public function lines(): HasMany
    {
        return $this->hasMany(GlJournalLine::class, 'journal_id');
    }
}
