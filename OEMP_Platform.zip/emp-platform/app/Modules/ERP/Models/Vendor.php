<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class Vendor extends BaseModel
{
    protected $table = 'erp_vendors';
    protected $fillable = ['tenant_id', 'code', 'name', 'email', 'phone', 'payment_terms'];

}
