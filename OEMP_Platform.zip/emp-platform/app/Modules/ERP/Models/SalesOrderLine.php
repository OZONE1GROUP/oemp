<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class SalesOrderLine extends BaseModel
{
    protected $table = 'erp_sales_order_lines';
    protected $fillable = ['tenant_id', 'sales_order_id', 'item_ref', 'description', 'qty', 'unit_price', 'line_total'];
    protected $casts = ['qty' => 'decimal:2', 'unit_price' => 'decimal:2', 'line_total' => 'decimal:2'];

}
