<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SalesOrder extends BaseModel
{
    protected $table = 'erp_sales_orders';
    protected $fillable = ['tenant_id', 'order_no', 'customer_id', 'order_date', 'status', 'subtotal', 'tax', 'total'];
    protected $casts = ['order_date' => 'date', 'subtotal' => 'decimal:2', 'tax' => 'decimal:2', 'total' => 'decimal:2'];

    public function lines(): HasMany
    {
        return $this->hasMany(SalesOrderLine::class, 'sales_order_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function recalcTotals(): void
    {
        $subtotal = $this->lines()->sum('line_total');
        $tax = round($subtotal * 0.0, 2); // tax rule pluggable via parameters
        $this->update(['subtotal' => $subtotal, 'tax' => $tax, 'total' => $subtotal + $tax]);
    }
}
