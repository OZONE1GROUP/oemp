<?php

namespace App\Modules\ERP\Models;

use App\Core\Support\BaseModel;

class GlJournalLine extends BaseModel
{
    protected $table = 'erp_gl_journal_lines';
    protected $fillable = ['tenant_id', 'journal_id', 'account_id', 'debit', 'credit', 'memo'];
    protected $casts = ['debit' => 'decimal:2', 'credit' => 'decimal:2'];

}
