<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('erp_sales_orders', function (Blueprint $table) {
            if (! Schema::hasColumn('erp_sales_orders', 'order_date')) {
                $table->date('order_date')->nullable();
            }
            if (! Schema::hasColumn('erp_sales_orders', 'subtotal')) {
                $table->decimal('subtotal', 15, 2)->default(0);
            }
            if (! Schema::hasColumn('erp_sales_orders', 'tax')) {
                $table->decimal('tax', 15, 2)->default(0);
            }
        });
    }

    public function down(): void
    {
        Schema::table('erp_sales_orders', function (Blueprint $table) {
            $table->dropColumn(['order_date', 'subtotal', 'tax']);
        });
    }
};
