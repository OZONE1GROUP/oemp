<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('erp_gl_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->string('type');
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->boolean('is_postable')->default(true);
            $table->timestamps();
            $table->unique(['tenant_id', 'code']);
        });

        Schema::create('erp_fiscal_periods', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->date('starts_on');
            $table->date('ends_on');
            $table->string('status')->default('open');
            $table->timestamps();
        });

        Schema::create('erp_gl_journals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('journal_no');
            $table->date('date');
            $table->foreignId('period_id')->constrained('erp_fiscal_periods');
            $table->string('memo')->nullable();
            $table->string('source')->default('manual');
            $table->boolean('posted')->default(false);
            $table->timestamps();
        });

        Schema::create('erp_gl_journal_lines', function (Blueprint $table) {
            $table->id();
            $table->foreignId('journal_id')->constrained('erp_gl_journals')->cascadeOnDelete();
            $table->foreignId('account_id')->constrained('erp_gl_accounts');
            $table->decimal('debit', 15, 2)->default(0);
            $table->decimal('credit', 15, 2)->default(0);
            $table->string('memo')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('erp_gl_journal_lines');
        Schema::dropIfExists('erp_gl_journals');
        Schema::dropIfExists('erp_fiscal_periods');
        Schema::dropIfExists('erp_gl_accounts');
    }
};
