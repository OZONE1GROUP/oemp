<?php

namespace App\Modules\ERP\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ERP\Models\GlJournal;
use App\Modules\ERP\Models\FiscalPeriod;
use App\Modules\ERP\Http\Requests\StoreJournalRequest;
use App\Core\Events\EventBus;
use Illuminate\Support\Facades\DB;

class JournalController extends Controller
{
    public function index()
    {
        return GlJournal::with('lines')->latest()->paginate(50);
    }

    public function store(StoreJournalRequest $request, EventBus $bus)
    {
        return DB::transaction(function () use ($request, $bus) {
            $journal = GlJournal::create([
                'journal_no' => 'JV-' . now()->format('YmdHis'),
                'date' => $request->date,
                'period_id' => $request->period_id,
                'memo' => $request->memo,
                'source' => 'manual',
                'posted' => false,
            ]);
            foreach ($request->lines as $line) {
                $journal->lines()->create($line);
            }
            $bus->publish('erp.journal.created', ['id' => $journal->id]);

            return response()->json($journal->load('lines'), 201);
        });
    }

    /** Post a journal: locks it after verifying balance and an open period. */
    public function post(GlJournal $journal, EventBus $bus)
    {
        abort_if($journal->posted, 422, 'Journal already posted.');

        $period = FiscalPeriod::find($journal->period_id);
        abort_unless($period && $period->status === 'open', 422, 'Fiscal period is not open.');

        $debits = $journal->lines()->sum('debit');
        $credits = $journal->lines()->sum('credit');
        abort_if(round($debits, 2) != round($credits, 2), 422, 'Journal is not balanced.');

        $journal->update(['posted' => true]);
        $bus->publish('erp.journal.posted', ['id' => $journal->id]);

        return $journal->load('lines');
    }
}
