<?php

namespace App\Modules\ERP\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ERP\Models\SalesOrder;
use App\Modules\ERP\Models\Invoice;
use App\Modules\ERP\Http\Requests\StoreSalesOrderRequest;
use App\Core\Events\EventBus;
use Illuminate\Support\Facades\DB;

class SalesOrderController extends Controller
{
    public function index()
    {
        return SalesOrder::with('customer')->latest()->paginate(50);
    }

    public function show(SalesOrder $salesOrder)
    {
        return $salesOrder->load('lines', 'customer');
    }

    public function store(StoreSalesOrderRequest $request, EventBus $bus)
    {
        return DB::transaction(function () use ($request, $bus) {
            $order = SalesOrder::create([
                'order_no' => 'SO-' . now()->format('YmdHis'),
                'customer_id' => $request->customer_id,
                'order_date' => $request->order_date,
                'status' => 'draft',
            ]);
            foreach ($request->lines as $l) {
                $order->lines()->create([
                    'item_ref' => $l['item_ref'] ?? null,
                    'description' => $l['description'],
                    'qty' => $l['qty'],
                    'unit_price' => $l['unit_price'],
                    'line_total' => round($l['qty'] * $l['unit_price'], 2),
                ]);
            }
            $order->recalcTotals();
            $bus->publish('erp.sales_order.created', ['id' => $order->id]);

            return response()->json($order->load('lines'), 201);
        });
    }

    public function confirm(SalesOrder $salesOrder, EventBus $bus)
    {
        abort_unless($salesOrder->status === 'draft', 422, 'Only draft orders can be confirmed.');
        $salesOrder->update(['status' => 'confirmed']);
        $bus->publish('erp.sales_order.confirmed', ['id' => $salesOrder->id]);

        return $salesOrder;
    }

    /** Generate an AR invoice from a confirmed order. */
    public function invoice(SalesOrder $salesOrder, EventBus $bus)
    {
        abort_unless($salesOrder->status === 'confirmed', 422, 'Order must be confirmed first.');
        $invoice = Invoice::create([
            'invoice_no' => 'INV-' . now()->format('YmdHis'),
            'customer_id' => $salesOrder->customer_id,
            'sales_order_id' => $salesOrder->id,
            'date' => now()->toDateString(),
            'due_date' => now()->addDays(30)->toDateString(),
            'total' => $salesOrder->total,
            'amount_paid' => 0,
            'status' => 'open',
        ]);
        $salesOrder->update(['status' => 'invoiced']);
        $bus->publish('erp.invoice.created', ['id' => $invoice->id, 'total' => (float) $invoice->total]);

        return response()->json($invoice, 201);
    }
}
