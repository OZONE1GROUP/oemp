<?php

namespace App\Modules\ERP\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ERP\Models\PurchaseOrder;
use App\Modules\ERP\Http\Requests\StorePurchaseOrderRequest;
use App\Core\Events\EventBus;
use Illuminate\Support\Facades\DB;

class PurchaseOrderController extends Controller
{
    public function index()
    {
        return PurchaseOrder::with('lines')->latest()->paginate(50);
    }

    public function store(StorePurchaseOrderRequest $request, EventBus $bus)
    {
        return DB::transaction(function () use ($request, $bus) {
            $po = PurchaseOrder::create([
                'po_no' => 'PO-' . now()->format('YmdHis'),
                'vendor_id' => $request->vendor_id,
                'order_date' => $request->order_date,
                'status' => 'draft',
                'subtotal' => 0, 'tax' => 0, 'total' => 0,
            ]);
            $subtotal = 0;
            foreach ($request->lines as $l) {
                $lt = round($l['qty'] * $l['unit_price'], 2);
                $subtotal += $lt;
                $po->lines()->create([
                    'description' => $l['description'],
                    'qty' => $l['qty'],
                    'unit_price' => $l['unit_price'],
                    'line_total' => $lt,
                ]);
            }
            $po->update(['subtotal' => $subtotal, 'tax' => 0, 'total' => $subtotal]);
            $bus->publish('erp.purchase_order.created', ['id' => $po->id]);

            return response()->json($po->load('lines'), 201);
        });
    }

    public function approve(PurchaseOrder $purchaseOrder, EventBus $bus)
    {
        abort_unless($purchaseOrder->status === 'draft', 422, 'Only draft POs can be approved.');
        $purchaseOrder->update(['status' => 'approved']);
        $bus->publish('erp.purchase_order.approved', ['id' => $purchaseOrder->id]);

        return $purchaseOrder;
    }
}
