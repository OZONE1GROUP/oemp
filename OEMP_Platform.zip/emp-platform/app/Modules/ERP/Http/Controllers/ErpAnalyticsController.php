<?php

namespace App\Modules\ERP\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ErpAnalyticsController extends Controller
{
    /** Trial balance: net debit/credit per posted account. */
    public function trialBalance()
    {
        return DB::table('erp_gl_journal_lines as l')
            ->join('erp_gl_journals as j', 'j.id', '=', 'l.journal_id')
            ->join('erp_gl_accounts as a', 'a.id', '=', 'l.account_id')
            ->where('j.posted', true)
            ->groupBy('a.id', 'a.code', 'a.name')
            ->select('a.code', 'a.name',
                DB::raw('SUM(l.debit) as total_debit'),
                DB::raw('SUM(l.credit) as total_credit'),
                DB::raw('SUM(l.debit - l.credit) as balance'))
            ->orderBy('a.code')
            ->get();
    }

    /** AR aging buckets from open invoices. */
    public function arAging()
    {
        return DB::table('erp_invoices')
            ->where('status', 'open')
            ->select(
                DB::raw("SUM(CASE WHEN due_date >= CURDATE() THEN total - amount_paid ELSE 0 END) as current"),
                DB::raw("SUM(CASE WHEN due_date < CURDATE() AND due_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN total - amount_paid ELSE 0 END) as d1_30"),
                DB::raw("SUM(CASE WHEN due_date < DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND due_date >= DATE_SUB(CURDATE(), INTERVAL 60 DAY) THEN total - amount_paid ELSE 0 END) as d31_60"),
                DB::raw("SUM(CASE WHEN due_date < DATE_SUB(CURDATE(), INTERVAL 60 DAY) THEN total - amount_paid ELSE 0 END) as d60_plus")
            )
            ->first();
    }

    /** Sales totals by month. */
    public function salesByPeriod()
    {
        return DB::table('erp_sales_orders')
            ->whereIn('status', ['confirmed', 'invoiced'])
            ->groupBy('period')
            ->select(DB::raw("DATE_FORMAT(order_date, '%Y-%m') as period"), DB::raw('SUM(total) as revenue'), DB::raw('COUNT(*) as orders'))
            ->orderBy('period')
            ->get();
    }
}
