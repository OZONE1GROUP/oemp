<?php

namespace App\Modules\ERP\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ERP\Models\GlAccount;
use Illuminate\Http\Request;

class GlAccountController extends Controller
{
    public function index()
    {
        return GlAccount::orderBy('code')->paginate(100);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:20'],
            'name' => ['required', 'string', 'max:150'],
            'type' => ['required', 'in:asset,liability,equity,income,expense'],
            'parent_id' => ['nullable', 'integer', 'exists:erp_gl_accounts,id'],
            'is_postable' => ['boolean'],
        ]);

        return response()->json(GlAccount::create($data), 201);
    }
}
