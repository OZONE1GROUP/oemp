<div class="emp-module" data-module="erp">
    <h3>SalesOrders</h3>
    <p class="text-muted">ERP module &mdash; managed by the EMP platform core.</p>
</div>
