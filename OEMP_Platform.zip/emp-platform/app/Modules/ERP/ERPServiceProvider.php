<?php

namespace App\Modules\ERP;

use App\Core\Support\ModuleServiceProvider;

class ERPServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'erp';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
