<?php

use Illuminate\Support\Facades\Route;
use App\Modules\ERP\Http\Controllers\GlAccountController;
use App\Modules\ERP\Http\Controllers\JournalController;
use App\Modules\ERP\Http\Controllers\CustomerController;
use App\Modules\ERP\Http\Controllers\SalesOrderController;
use App\Modules\ERP\Http\Controllers\VendorController;
use App\Modules\ERP\Http\Controllers\PurchaseOrderController;
use App\Modules\ERP\Http\Controllers\ErpAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.erp'])
    ->prefix('api/erp')
    ->group(function () {
        // General Ledger
        Route::get('accounts', [GlAccountController::class, 'index']);
        Route::post('accounts', [GlAccountController::class, 'store']);
        Route::get('journals', [JournalController::class, 'index']);
        Route::post('journals', [JournalController::class, 'store']);
        Route::post('journals/{journal}/post', [JournalController::class, 'post']);

        // Sales (Order to Cash)
        Route::get('customers', [CustomerController::class, 'index']);
        Route::post('customers', [CustomerController::class, 'store']);
        Route::get('sales-orders', [SalesOrderController::class, 'index']);
        Route::get('sales-orders/{salesOrder}', [SalesOrderController::class, 'show']);
        Route::post('sales-orders', [SalesOrderController::class, 'store']);
        Route::post('sales-orders/{salesOrder}/confirm', [SalesOrderController::class, 'confirm']);
        Route::post('sales-orders/{salesOrder}/invoice', [SalesOrderController::class, 'invoice']);

        // Purchasing (Procure to Pay)
        Route::get('vendors', [VendorController::class, 'index']);
        Route::post('vendors', [VendorController::class, 'store']);
        Route::get('purchase-orders', [PurchaseOrderController::class, 'index']);
        Route::post('purchase-orders', [PurchaseOrderController::class, 'store']);
        Route::post('purchase-orders/{purchaseOrder}/approve', [PurchaseOrderController::class, 'approve']);

        // Financial analytics
        Route::get('analytics/trial-balance', [ErpAnalyticsController::class, 'trialBalance']);
        Route::get('analytics/ar-aging', [ErpAnalyticsController::class, 'arAging']);
        Route::get('analytics/sales-by-period', [ErpAnalyticsController::class, 'salesByPeriod']);
    });
