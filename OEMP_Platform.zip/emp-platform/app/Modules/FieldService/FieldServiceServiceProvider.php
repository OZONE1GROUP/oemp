<?php

namespace App\Modules\FieldService;

use App\Core\Support\ModuleServiceProvider;

class FieldServiceServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'field_service';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
