<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('fs_work_orders', function (Blueprint $table) {
            foreach ([['location','str'],['description','text'],['technician_id','bigint'],['sla_due','ts']] as [$c,$t]) {
                if (! Schema::hasColumn('fs_work_orders', $c)) {
                    match ($t) {
                        'text' => $table->text($c)->nullable(),
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'ts' => $table->timestamp($c)->nullable(),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('fs_work_orders', function (Blueprint $table) {
            $table->dropColumn(['location', 'description', 'technician_id', 'sla_due']);
        });
    }
};
