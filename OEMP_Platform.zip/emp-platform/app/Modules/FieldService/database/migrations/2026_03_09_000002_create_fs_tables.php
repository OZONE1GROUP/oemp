<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('fs_technicians', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('skills')->nullable();
            $table->string('zone')->nullable();
            $table->string('status')->default('available');
            $table->timestamps();
        });

        Schema::create('fs_parts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('work_order_id')->constrained('fs_work_orders')->cascadeOnDelete();
            $table->string('part');
            $table->integer('qty')->default(1);
            $table->decimal('cost', 12, 2)->default(0);
        });

        Schema::create('fs_reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('work_order_id')->constrained('fs_work_orders')->cascadeOnDelete();
            $table->text('notes')->nullable();
            $table->string('outcome')->default('resolved');
            $table->timestamp('completed_at')->nullable();
            $table->string('signature')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('fs_reports');
        Schema::dropIfExists('fs_parts');
        Schema::dropIfExists('fs_technicians');
    }
};
