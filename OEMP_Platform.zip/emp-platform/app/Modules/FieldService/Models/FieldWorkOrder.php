<?php

namespace App\Modules\FieldService\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FieldWorkOrder extends BaseModel
{
    protected $table = 'fs_work_orders';
    protected $fillable = ['tenant_id','wo_no','customer','location','description','technician_id',
        'scheduled_at','sla_due','priority','status'];
    protected $casts = ['scheduled_at' => 'datetime', 'sla_due' => 'datetime'];

    public function parts(): HasMany
    {
        return $this->hasMany(WorkOrderPart::class, 'work_order_id');
    }
}
