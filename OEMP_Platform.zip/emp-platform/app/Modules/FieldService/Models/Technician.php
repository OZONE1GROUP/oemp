<?php

namespace App\Modules\FieldService\Models;

use App\Core\Support\BaseModel;

class Technician extends BaseModel
{
    protected $table = 'fs_technicians';
    protected $fillable = ['tenant_id', 'name', 'skills', 'zone', 'status'];

}
