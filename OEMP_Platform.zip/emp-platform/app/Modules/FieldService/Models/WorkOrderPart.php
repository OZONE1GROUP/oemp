<?php

namespace App\Modules\FieldService\Models;

use App\Core\Support\BaseModel;

class WorkOrderPart extends BaseModel
{
    protected $table = 'fs_parts';
    protected $fillable = ['tenant_id', 'work_order_id', 'part', 'qty', 'cost'];
    protected $casts = ['qty' => 'integer', 'cost' => 'decimal:2'];

}
