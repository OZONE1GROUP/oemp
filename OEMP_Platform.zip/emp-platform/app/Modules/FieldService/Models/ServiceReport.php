<?php

namespace App\Modules\FieldService\Models;

use App\Core\Support\BaseModel;

class ServiceReport extends BaseModel
{
    protected $table = 'fs_reports';
    protected $fillable = ['tenant_id', 'work_order_id', 'notes', 'outcome', 'completed_at', 'signature'];
    protected $casts = ['completed_at' => 'datetime'];

}
