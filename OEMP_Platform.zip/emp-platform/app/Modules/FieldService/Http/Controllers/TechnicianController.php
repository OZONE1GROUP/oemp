<?php

namespace App\Modules\FieldService\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FieldService\Models\Technician;
use Illuminate\Http\Request;

class TechnicianController extends Controller
{
    public function index()
    {
        return Technician::orderBy('name')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'skills' => ['nullable', 'string', 'max:200'],
            'zone' => ['nullable', 'string', 'max:80'],
        ]);

        return response()->json(Technician::create(array_merge($data, ['status' => 'available'])), 201);
    }
}
