<?php

namespace App\Modules\FieldService\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FieldService\Models\FieldWorkOrder;
use Illuminate\Http\Request;

class FieldWorkOrderController extends Controller
{
    public function index(Request $request)
    {
        return FieldWorkOrder::query()
            ->when($request->q, fn ($qq) => $qq->where('wo_no', 'like', "%{$request->q}%"))
            ->latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'wo_no' => 'required|string|max:255',
            'customer' => 'nullable|string|max:255',
            'technician' => 'nullable|string|max:255',
            'scheduled_at' => 'nullable|date',
            'priority' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
        ]);

        return response()->json(FieldWorkOrder::create($data), 201);
    }

    public function show(FieldWorkOrder $field_serviceItem)
    {
        return $field_serviceItem;
    }

    public function update(Request $request, FieldWorkOrder $field_serviceItem)
    {
        $data = $request->validate([
            'wo_no' => 'required|string|max:255',
            'customer' => 'nullable|string|max:255',
            'technician' => 'nullable|string|max:255',
            'scheduled_at' => 'nullable|date',
            'priority' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
        ]);
        $field_serviceItem->update($data);

        return $field_serviceItem;
    }

    public function destroy(FieldWorkOrder $field_serviceItem)
    {
        $field_serviceItem->delete();

        return response()->noContent();
    }
}
