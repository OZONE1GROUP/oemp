<?php

namespace App\Modules\FieldService\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class FsAnalyticsController extends Controller
{
    public function openByPriority()
    {
        return DB::table('fs_work_orders')->whereNotIn('status', ['completed', 'cancelled'])
            ->groupBy('priority')->select('priority', DB::raw('COUNT(*) as count'))->get();
    }

    public function slaBreaches()
    {
        return ['breached' => DB::table('fs_work_orders')->whereNotIn('status', ['completed', 'cancelled'])
            ->whereNotNull('sla_due')->where('sla_due', '<', now())->count()];
    }

    /** First-time-fix rate from service reports. */
    public function firstTimeFix()
    {
        $resolved = DB::table('fs_reports')->where('outcome', 'resolved')->count();
        $total = DB::table('fs_reports')->count();

        return ['resolved' => $resolved, 'total' => $total, 'ftf_rate' => $total ? round($resolved / $total * 100, 1) : 0];
    }
}
