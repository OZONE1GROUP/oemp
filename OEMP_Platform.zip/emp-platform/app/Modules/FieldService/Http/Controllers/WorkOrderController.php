<?php

namespace App\Modules\FieldService\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\FieldService\Models\FieldWorkOrder;
use App\Modules\FieldService\Models\ServiceReport;
use App\Core\Events\EventBus;
use Illuminate\Support\Carbon;
use Illuminate\Http\Request;

class WorkOrderController extends Controller
{
    public function index(Request $request)
    {
        return FieldWorkOrder::with('parts')
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'customer' => ['required', 'string', 'max:150'],
            'location' => ['nullable', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
            'priority' => ['required', 'in:low,medium,high,urgent'],
            'scheduled_at' => ['nullable', 'date'],
        ]);
        $slaHours = ['low' => 72, 'medium' => 48, 'high' => 24, 'urgent' => 4][$data['priority']];

        return response()->json(FieldWorkOrder::create(array_merge($data, [
            'wo_no' => 'FSW-' . now()->format('YmdHis'),
            'status' => 'new', 'sla_due' => Carbon::now()->addHours($slaHours),
        ])), 201);
    }

    /** Dispatch to a technician. */
    public function dispatch(Request $request, FieldWorkOrder $workOrder, EventBus $bus)
    {
        $data = $request->validate(['technician_id' => ['required', 'integer', 'exists:fs_technicians,id']]);
        $workOrder->update(['technician_id' => $data['technician_id'], 'status' => 'dispatched']);
        $bus->publish('fieldservice.dispatched', ['id' => $workOrder->id]);

        return $workOrder;
    }

    public function start(FieldWorkOrder $workOrder)
    {
        $workOrder->update(['status' => 'in_progress']);

        return $workOrder;
    }

    /** Complete with a service report and parts used. */
    public function complete(Request $request, FieldWorkOrder $workOrder, EventBus $bus)
    {
        $data = $request->validate([
            'notes' => ['nullable', 'string'],
            'outcome' => ['required', 'in:resolved,follow_up,cancelled'],
            'parts' => ['array'],
            'parts.*.part' => ['required_with:parts', 'string'],
            'parts.*.qty' => ['required_with:parts', 'integer', 'min:1'],
            'parts.*.cost' => ['nullable', 'numeric', 'min:0'],
        ]);
        foreach ($data['parts'] ?? [] as $p) {
            $workOrder->parts()->create($p);
        }
        ServiceReport::create([
            'work_order_id' => $workOrder->id, 'notes' => $data['notes'] ?? null,
            'outcome' => $data['outcome'], 'completed_at' => now(),
        ]);
        $workOrder->update(['status' => $data['outcome'] === 'resolved' ? 'completed' : $data['outcome']]);
        $bus->publish('fieldservice.completed', ['id' => $workOrder->id, 'outcome' => $data['outcome']]);

        return $workOrder->load('parts');
    }
}
