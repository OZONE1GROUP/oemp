<div class="emp-module" data-module="field_service">
    <h3>FieldWorkOrders</h3>
    <p class="text-muted">FieldService module &mdash; managed by the EMP platform core.</p>
</div>
