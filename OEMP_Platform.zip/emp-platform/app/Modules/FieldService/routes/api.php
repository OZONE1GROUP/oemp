<?php

use Illuminate\Support\Facades\Route;
use App\Modules\FieldService\Http\Controllers\TechnicianController;
use App\Modules\FieldService\Http\Controllers\WorkOrderController;
use App\Modules\FieldService\Http\Controllers\FsAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.field_service'])
    ->prefix('api/field-service')
    ->group(function () {
        Route::get('technicians', [TechnicianController::class, 'index']);
        Route::post('technicians', [TechnicianController::class, 'store']);

        Route::get('work-orders', [WorkOrderController::class, 'index']);
        Route::post('work-orders', [WorkOrderController::class, 'store']);
        Route::post('work-orders/{workOrder}/dispatch', [WorkOrderController::class, 'dispatch']);
        Route::post('work-orders/{workOrder}/start', [WorkOrderController::class, 'start']);
        Route::post('work-orders/{workOrder}/complete', [WorkOrderController::class, 'complete']);

        Route::get('analytics/open-by-priority', [FsAnalyticsController::class, 'openByPriority']);
        Route::get('analytics/sla-breaches', [FsAnalyticsController::class, 'slaBreaches']);
        Route::get('analytics/first-time-fix', [FsAnalyticsController::class, 'firstTimeFix']);
    });
