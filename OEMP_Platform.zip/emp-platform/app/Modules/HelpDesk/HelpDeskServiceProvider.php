<?php

namespace App\Modules\HelpDesk;

use App\Core\Support\ModuleServiceProvider;

class HelpDeskServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'help_desk';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
