<?php

namespace App\Modules\HelpDesk\Models;

use App\Core\Support\BaseModel;

class HelpdeskSla extends BaseModel
{
    protected $table = 'hd_slas';
    protected $fillable = ['tenant_id', 'priority', 'response_hours', 'resolution_hours'];
    protected $casts = ['response_hours' => 'integer', 'resolution_hours' => 'integer'];

}
