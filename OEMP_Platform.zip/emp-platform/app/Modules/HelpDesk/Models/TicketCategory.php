<?php

namespace App\Modules\HelpDesk\Models;

use App\Core\Support\BaseModel;

class TicketCategory extends BaseModel
{
    protected $table = 'hd_categories';
    protected $fillable = ['tenant_id', 'name', 'queue'];

}
