<?php

namespace App\Modules\HelpDesk\Models;

use App\Core\Support\BaseModel;

class TicketComment extends BaseModel
{
    protected $table = 'hd_comments';
    protected $fillable = ['tenant_id', 'ticket_id', 'author', 'body', 'internal'];
    protected $casts = ['internal' => 'boolean'];

}
