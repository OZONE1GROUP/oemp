<?php

namespace App\Modules\HelpDesk\Models;

use App\Core\Support\BaseModel;

class Csat extends BaseModel
{
    protected $table = 'hd_csat';
    protected $fillable = ['tenant_id', 'ticket_id', 'score', 'comment'];
    protected $casts = ['score' => 'integer'];

}
