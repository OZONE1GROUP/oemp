<?php

namespace App\Modules\HelpDesk\Models;

use App\Core\Support\BaseModel;

class KnowledgeArticle extends BaseModel
{
    protected $table = 'hd_kb_articles';
    protected $fillable = ['tenant_id', 'title', 'body', 'category', 'published', 'views'];
    protected $casts = ['published' => 'boolean', 'views' => 'integer'];

}
