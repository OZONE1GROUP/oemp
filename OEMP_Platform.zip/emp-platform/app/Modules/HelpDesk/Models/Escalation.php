<?php

namespace App\Modules\HelpDesk\Models;

use App\Core\Support\BaseModel;

class Escalation extends BaseModel
{
    protected $table = 'hd_escalations';
    protected $fillable = ['tenant_id', 'ticket_id', 'level', 'reason', 'escalated_at'];
    protected $casts = ['level' => 'integer', 'escalated_at' => 'datetime'];

}
