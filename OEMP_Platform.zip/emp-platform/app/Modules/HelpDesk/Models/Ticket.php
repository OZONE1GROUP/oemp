<?php

namespace App\Modules\HelpDesk\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Ticket extends BaseModel
{
    protected $table = 'helpdesk_tickets';
    protected $fillable = ['tenant_id','ticket_no','subject','description','requester','channel',
        'category_id','priority','status','assignee_id','sla_id','due_at','first_response_at','escalation_level'];
    protected $casts = ['due_at' => 'datetime', 'first_response_at' => 'datetime', 'escalation_level' => 'integer'];

    public function comments(): HasMany
    {
        return $this->hasMany(TicketComment::class);
    }
}
