<?php

namespace App\Modules\HelpDesk\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HelpDesk\Models\KnowledgeArticle;
use Illuminate\Http\Request;

class KnowledgeController extends Controller
{
    /** Full-text-ready search (LIKE now; Elasticsearch-backed in production). */
    public function search(Request $request)
    {
        $q = $request->get('q', '');

        return KnowledgeArticle::where('published', true)
            ->when($q, fn ($qq) => $qq->where('title', 'like', "%$q%")->orWhere('body', 'like', "%$q%"))
            ->limit(25)->get(['id', 'title', 'category', 'views']);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:200'],
            'body' => ['required', 'string'],
            'category' => ['nullable', 'string', 'max:80'],
        ]);

        return response()->json(KnowledgeArticle::create(array_merge($data, ['published' => false, 'views' => 0])), 201);
    }

    public function publish(KnowledgeArticle $article)
    {
        $article->update(['published' => true]);

        return $article;
    }

    public function view(KnowledgeArticle $article)
    {
        $article->increment('views');

        return $article;
    }
}
