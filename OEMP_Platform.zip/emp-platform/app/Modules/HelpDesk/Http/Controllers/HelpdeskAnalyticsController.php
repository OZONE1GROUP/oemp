<?php

namespace App\Modules\HelpDesk\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class HelpdeskAnalyticsController extends Controller
{
    /** Open tickets by priority. */
    public function openByPriority()
    {
        return DB::table('helpdesk_tickets')
            ->whereNotIn('status', ['resolved', 'closed'])
            ->groupBy('priority')
            ->select('priority', DB::raw('COUNT(*) as count'))
            ->get();
    }

    /** SLA breaches: open tickets past due. */
    public function slaBreaches()
    {
        return ['breached' => DB::table('helpdesk_tickets')
            ->whereNotIn('status', ['resolved', 'closed'])
            ->whereNotNull('due_at')->where('due_at', '<', now())->count()];
    }

    /** Average CSAT score. */
    public function csat()
    {
        $avg = DB::table('hd_csat')->avg('score');

        return ['average_csat' => round((float) $avg, 2), 'responses' => DB::table('hd_csat')->count()];
    }
}
