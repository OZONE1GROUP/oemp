<?php

namespace App\Modules\HelpDesk\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HelpDesk\Models\Ticket;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function index(Ticket $ticket)
    {
        return $ticket->comments()->latest()->get();
    }

    public function store(Request $request, Ticket $ticket)
    {
        $data = $request->validate([
            'author' => ['required', 'string', 'max:120'],
            'body' => ['required', 'string'],
            'internal' => ['boolean'],
        ]);

        return response()->json($ticket->comments()->create($data), 201);
    }
}
