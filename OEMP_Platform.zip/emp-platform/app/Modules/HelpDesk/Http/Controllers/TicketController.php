<?php

namespace App\Modules\HelpDesk\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HelpDesk\Models\Ticket;
use App\Modules\HelpDesk\Models\HelpdeskSla;
use App\Modules\HelpDesk\Models\Escalation;
use App\Core\Events\EventBus;
use Illuminate\Support\Carbon;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function index(Request $request)
    {
        return Ticket::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->priority, fn ($q) => $q->where('priority', $request->priority))
            ->when($request->q, fn ($q) => $q->where('subject', 'like', "%{$request->q}%"))
            ->latest()->paginate(50);
    }

    /** Omni-channel intake: email, portal, chat, api. */
    public function store(Request $request, EventBus $bus)
    {
        $data = $request->validate([
            'subject' => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
            'requester' => ['required', 'string', 'max:150'],
            'channel' => ['required', 'in:email,portal,chat,phone,api'],
            'category_id' => ['nullable', 'integer', 'exists:hd_categories,id'],
            'priority' => ['required', 'in:low,medium,high,urgent'],
        ]);

        $sla = HelpdeskSla::where('priority', $data['priority'])->first();
        $ticket = Ticket::create(array_merge($data, [
            'ticket_no' => 'TKT-' . now()->format('YmdHis'),
            'status' => 'open',
            'sla_id' => $sla?->id,
            'due_at' => Carbon::now()->addHours($sla?->resolution_hours ?? 48),
            'escalation_level' => 0,
        ]));
        $bus->publish('helpdesk.ticket.created', ['id' => $ticket->id, 'priority' => $ticket->priority]);

        return response()->json($ticket, 201);
    }

    public function assign(Request $request, Ticket $ticket)
    {
        $data = $request->validate(['assignee_id' => ['required', 'integer']]);
        $ticket->update(['assignee_id' => $data['assignee_id'], 'status' => 'assigned']);

        return $ticket;
    }

    public function respond(Ticket $ticket)
    {
        if (! $ticket->first_response_at) {
            $ticket->update(['first_response_at' => now(), 'status' => 'in_progress']);
        }

        return $ticket;
    }

    public function resolve(Ticket $ticket, EventBus $bus)
    {
        $ticket->update(['status' => 'resolved']);
        $bus->publish('helpdesk.ticket.resolved', ['id' => $ticket->id]);

        return $ticket;
    }

    /** Escalate a ticket (manually or when overdue). */
    public function escalate(Request $request, Ticket $ticket)
    {
        $reason = $request->input('reason', 'SLA breach or manual escalation');
        $level = $ticket->escalation_level + 1;
        $ticket->update(['escalation_level' => $level]);
        Escalation::create(['ticket_id' => $ticket->id, 'level' => $level, 'reason' => $reason, 'escalated_at' => now()]);

        return $ticket;
    }
}
