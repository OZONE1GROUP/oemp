<?php

namespace App\Modules\HelpDesk\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HelpDesk\Models\Csat;
use App\Modules\HelpDesk\Models\Ticket;
use Illuminate\Http\Request;

class CsatController extends Controller
{
    public function store(Request $request, Ticket $ticket)
    {
        abort_unless($ticket->status === 'resolved', 422, 'CSAT is collected after resolution.');
        $data = $request->validate([
            'score' => ['required', 'integer', 'min:1', 'max:5'],
            'comment' => ['nullable', 'string'],
        ]);

        return response()->json(Csat::create(array_merge($data, ['ticket_id' => $ticket->id])), 201);
    }
}
