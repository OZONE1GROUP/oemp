<div class="emp-module" data-module="help_desk">
    <h3>Tickets</h3>
    <p class="text-muted">HelpDesk module &mdash; managed by the EMP platform core.</p>
</div>
