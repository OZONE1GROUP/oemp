<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hd_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('queue')->nullable();
            $table->timestamps();
        });

        Schema::create('hd_slas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('priority');
            $table->integer('response_hours')->default(4);
            $table->integer('resolution_hours')->default(48);
            $table->timestamps();
        });

        Schema::create('hd_comments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('ticket_id')->constrained('helpdesk_tickets')->cascadeOnDelete();
            $table->string('author');
            $table->text('body');
            $table->boolean('internal')->default(false);
            $table->timestamps();
        });

        Schema::create('hd_kb_articles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('title');
            $table->longText('body');
            $table->string('category')->nullable();
            $table->boolean('published')->default(false);
            $table->integer('views')->default(0);
            $table->timestamps();
        });

        Schema::create('hd_csat', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('ticket_id')->constrained('helpdesk_tickets')->cascadeOnDelete();
            $table->integer('score');
            $table->text('comment')->nullable();
            $table->timestamps();
        });

        Schema::create('hd_escalations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('ticket_id')->constrained('helpdesk_tickets')->cascadeOnDelete();
            $table->integer('level')->default(1);
            $table->string('reason')->nullable();
            $table->timestamp('escalated_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hd_escalations');
        Schema::dropIfExists('hd_csat');
        Schema::dropIfExists('hd_kb_articles');
        Schema::dropIfExists('hd_comments');
        Schema::dropIfExists('hd_slas');
        Schema::dropIfExists('hd_categories');
    }
};
