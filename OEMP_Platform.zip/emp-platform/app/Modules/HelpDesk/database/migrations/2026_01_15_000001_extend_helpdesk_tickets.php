<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('helpdesk_tickets', function (Blueprint $table) {
            foreach ([['description','text'],['requester','str'],['channel','str'],['category_id','bigint'],
                      ['sla_id','bigint'],['due_at','ts'],['first_response_at','ts'],['escalation_level','int']] as [$c,$t]) {
                if (! Schema::hasColumn('helpdesk_tickets', $c)) {
                    match ($t) {
                        'text' => $table->text($c)->nullable(),
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'ts' => $table->timestamp($c)->nullable(),
                        'int' => $table->integer($c)->default(0),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('helpdesk_tickets', function (Blueprint $table) {
            $table->dropColumn(['description','requester','channel','category_id','sla_id','due_at','first_response_at','escalation_level']);
        });
    }
};
