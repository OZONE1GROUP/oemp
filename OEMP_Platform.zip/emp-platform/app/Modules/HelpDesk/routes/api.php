<?php

use Illuminate\Support\Facades\Route;
use App\Modules\HelpDesk\Http\Controllers\TicketController;
use App\Modules\HelpDesk\Http\Controllers\CommentController;
use App\Modules\HelpDesk\Http\Controllers\KnowledgeController;
use App\Modules\HelpDesk\Http\Controllers\CsatController;
use App\Modules\HelpDesk\Http\Controllers\HelpdeskAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.help_desk'])
    ->prefix('api/helpdesk')
    ->group(function () {
        Route::get('tickets', [TicketController::class, 'index']);
        Route::post('tickets', [TicketController::class, 'store']);
        Route::post('tickets/{ticket}/assign', [TicketController::class, 'assign']);
        Route::post('tickets/{ticket}/respond', [TicketController::class, 'respond']);
        Route::post('tickets/{ticket}/resolve', [TicketController::class, 'resolve']);
        Route::post('tickets/{ticket}/escalate', [TicketController::class, 'escalate']);

        Route::get('tickets/{ticket}/comments', [CommentController::class, 'index']);
        Route::post('tickets/{ticket}/comments', [CommentController::class, 'store']);
        Route::post('tickets/{ticket}/csat', [CsatController::class, 'store']);

        Route::get('kb/search', [KnowledgeController::class, 'search']);
        Route::post('kb', [KnowledgeController::class, 'store']);
        Route::post('kb/{article}/publish', [KnowledgeController::class, 'publish']);
        Route::post('kb/{article}/view', [KnowledgeController::class, 'view']);

        Route::get('analytics/open-by-priority', [HelpdeskAnalyticsController::class, 'openByPriority']);
        Route::get('analytics/sla-breaches', [HelpdeskAnalyticsController::class, 'slaBreaches']);
        Route::get('analytics/csat', [HelpdeskAnalyticsController::class, 'csat']);
    });
