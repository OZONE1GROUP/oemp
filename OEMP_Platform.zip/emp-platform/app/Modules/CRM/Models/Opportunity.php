<?php

namespace App\Modules\CRM\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Opportunity extends BaseModel
{
    protected $table = 'crm_opportunities';
    protected $fillable = ['tenant_id', 'account_id', 'name', 'amount', 'stage', 'probability', 'close_date', 'status', 'owner_id'];
    protected $casts = ['amount' => 'decimal:2', 'probability' => 'integer', 'close_date' => 'date'];

    public function account(): BelongsTo
    {
        return $this->belongsTo(Account::class);
    }

    public function getWeightedAmountAttribute(): float
    {
        return round((float) $this->amount * ($this->probability / 100), 2);
    }
}
