<?php

namespace App\Modules\CRM\Models;

use App\Core\Support\BaseModel;

class Lead extends BaseModel
{
    protected $table = 'crm_leads';
    protected $fillable = ['tenant_id', 'name', 'company', 'email', 'phone', 'source', 'status', 'score', 'owner_id', 'converted_at'];
    protected $casts = ['score' => 'integer', 'value' => 'decimal:2', 'converted_at' => 'datetime'];
}
