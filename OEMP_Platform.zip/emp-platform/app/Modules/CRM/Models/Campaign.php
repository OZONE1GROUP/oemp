<?php

namespace App\Modules\CRM\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Campaign extends BaseModel
{
    protected $table = 'crm_campaigns';
    protected $fillable = ['tenant_id', 'name', 'channel', 'start_date', 'end_date', 'budget', 'status'];
    protected $casts = ['start_date' => 'date', 'end_date' => 'date', 'budget' => 'decimal:2'];

    public function members(): HasMany
    {
        return $this->hasMany(CampaignMember::class);
    }
}
