<?php

namespace App\Modules\CRM\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Account extends BaseModel
{
    protected $table = 'crm_accounts';
    protected $fillable = ['tenant_id', 'name', 'industry', 'website', 'phone', 'owner_id'];

    public function contacts(): HasMany
    {
        return $this->hasMany(Contact::class);
    }

    public function opportunities(): HasMany
    {
        return $this->hasMany(Opportunity::class);
    }
}
