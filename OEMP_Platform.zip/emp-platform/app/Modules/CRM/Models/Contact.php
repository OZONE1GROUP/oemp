<?php

namespace App\Modules\CRM\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Contact extends BaseModel
{
    protected $table = 'crm_contacts';
    protected $fillable = ['tenant_id', 'account_id', 'first_name', 'last_name', 'email', 'phone', 'title', 'owner_id'];

    public function account(): BelongsTo
    {
        return $this->belongsTo(Account::class);
    }
}
