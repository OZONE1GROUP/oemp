<?php

namespace App\Modules\CRM\Models;

use App\Core\Support\BaseModel;

class CampaignMember extends BaseModel
{
    protected $table = 'crm_campaign_members';
    protected $fillable = ['tenant_id', 'campaign_id', 'lead_id', 'contact_id', 'status'];

}
