<?php

namespace App\Modules\CRM\Models;

use App\Core\Support\BaseModel;

class Activity extends BaseModel
{
    protected $table = 'crm_activities';
    protected $fillable = ['tenant_id', 'type', 'subject', 'notes', 'due_at', 'done', 'related_type', 'related_id', 'owner_id'];
    protected $casts = ['due_at' => 'datetime', 'done' => 'boolean'];

}
