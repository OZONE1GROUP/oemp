<div class="emp-module" data-module="crm">
    <h3>Leads</h3>
    <p class="text-muted">CRM module &mdash; managed by the EMP platform core.</p>
</div>
