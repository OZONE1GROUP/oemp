<?php

namespace App\Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Account;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    public function index(Request $request)
    {
        return Account::withCount('contacts', 'opportunities')
            ->when($request->q, fn ($q) => $q->where('name', 'like', "%{$request->q}%"))
            ->orderBy('name')->paginate(50);
    }

    public function show(Account $account)
    {
        return $account->load('contacts', 'opportunities');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'industry' => ['nullable', 'string', 'max:80'],
            'website' => ['nullable', 'url'],
            'phone' => ['nullable', 'string', 'max:40'],
        ]);

        return response()->json(Account::create($data), 201);
    }
}
