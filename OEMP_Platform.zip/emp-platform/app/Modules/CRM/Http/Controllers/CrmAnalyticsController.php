<?php

namespace App\Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CrmAnalyticsController extends Controller
{
    /** Pipeline value and weighted forecast per open stage. */
    public function pipeline()
    {
        return DB::table('crm_opportunities')
            ->where('status', 'open')
            ->groupBy('stage')
            ->select('stage',
                DB::raw('COUNT(*) as count'),
                DB::raw('SUM(amount) as amount'),
                DB::raw('ROUND(SUM(amount * probability / 100), 2) as weighted'))
            ->get();
    }

    /** Win rate over closed opportunities. */
    public function winRate()
    {
        $won = DB::table('crm_opportunities')->where('status', 'won')->count();
        $lost = DB::table('crm_opportunities')->where('status', 'lost')->count();
        $closed = $won + $lost;

        return [
            'won' => $won,
            'lost' => $lost,
            'win_rate' => $closed ? round($won / $closed * 100, 1) : 0,
        ];
    }

    /** Leads grouped by source. */
    public function leadsBySource()
    {
        return DB::table('crm_leads')
            ->groupBy('source')
            ->select('source', DB::raw('COUNT(*) as count'))
            ->get();
    }
}
