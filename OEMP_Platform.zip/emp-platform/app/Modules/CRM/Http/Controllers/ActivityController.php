<?php

namespace App\Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Activity;
use Illuminate\Http\Request;

class ActivityController extends Controller
{
    public function index(Request $request)
    {
        return Activity::query()
            ->when($request->boolean('open_only'), fn ($q) => $q->where('done', false))
            ->orderBy('due_at')->paginate(100);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'type' => ['required', 'in:call,email,meeting,task'],
            'subject' => ['required', 'string', 'max:150'],
            'notes' => ['nullable', 'string'],
            'due_at' => ['nullable', 'date'],
            'related_type' => ['nullable', 'string'],
            'related_id' => ['nullable', 'integer'],
        ]);

        return response()->json(Activity::create($data), 201);
    }

    public function complete(Activity $activity)
    {
        $activity->update(['done' => true]);

        return $activity;
    }
}
