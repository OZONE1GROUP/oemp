<?php

namespace App\Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Lead;
use App\Modules\CRM\Models\Account;
use App\Modules\CRM\Models\Contact;
use App\Modules\CRM\Models\Opportunity;
use App\Modules\CRM\Http\Requests\StoreLeadRequest;
use App\Core\Events\EventBus;
use Illuminate\Support\Facades\DB;

class LeadController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        return Lead::query()
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->q, fn ($q) => $q->where('name', 'like', "%{$request->q}%"))
            ->latest()->paginate(50);
    }

    public function store(StoreLeadRequest $request)
    {
        $lead = Lead::create(array_merge($request->validated(), ['status' => 'new']));

        return response()->json($lead, 201);
    }

    /** Convert a lead into an Account + Contact + Opportunity. */
    public function convert(Lead $lead, EventBus $bus)
    {
        abort_if($lead->converted_at, 422, 'Lead already converted.');

        return DB::transaction(function () use ($lead, $bus) {
            $account = Account::create(['name' => $lead->company ?: $lead->name, 'owner_id' => $lead->owner_id]);
            $parts = explode(' ', $lead->name, 2);
            $contact = Contact::create([
                'account_id' => $account->id,
                'first_name' => $parts[0],
                'last_name' => $parts[1] ?? '',
                'email' => $lead->email,
                'phone' => $lead->phone,
                'owner_id' => $lead->owner_id,
            ]);
            $opp = Opportunity::create([
                'account_id' => $account->id,
                'name' => $lead->company ?: $lead->name,
                'amount' => 0,
                'stage' => 'qualification',
                'probability' => 10,
                'status' => 'open',
                'owner_id' => $lead->owner_id,
            ]);
            $lead->update(['status' => 'converted', 'converted_at' => now()]);
            $bus->publish('crm.lead.converted', ['lead_id' => $lead->id, 'account_id' => $account->id]);

            return response()->json(compact('account', 'contact', 'opp'), 201);
        });
    }
}
