<?php

namespace App\Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Opportunity;
use App\Modules\CRM\Http\Requests\StoreOpportunityRequest;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class OpportunityController extends Controller
{
    public function index(Request $request)
    {
        return Opportunity::with('account')
            ->when($request->stage, fn ($q) => $q->where('stage', $request->stage))
            ->latest()->paginate(50);
    }

    public function store(StoreOpportunityRequest $request)
    {
        $data = $request->validated();
        $data['probability'] = $data['probability'] ?? 10;
        $data['status'] = 'open';

        return response()->json(Opportunity::create($data), 201);
    }

    /** Move an opportunity to a new stage; closing sets win/lose status. */
    public function moveStage(Request $request, Opportunity $opportunity, EventBus $bus)
    {
        $stage = $request->validate([
            'stage' => ['required', 'in:qualification,proposal,negotiation,closed_won,closed_lost'],
        ])['stage'];

        $status = match ($stage) {
            'closed_won' => 'won',
            'closed_lost' => 'lost',
            default => 'open',
        };
        $probability = match ($stage) {
            'qualification' => 10, 'proposal' => 40, 'negotiation' => 70,
            'closed_won' => 100, 'closed_lost' => 0,
        };

        $opportunity->update(compact('stage', 'status', 'probability'));
        $bus->publish("crm.opportunity.$status", ['id' => $opportunity->id]);

        return $opportunity;
    }
}
