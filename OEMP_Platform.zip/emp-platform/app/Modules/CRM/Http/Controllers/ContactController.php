<?php

namespace App\Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index(Request $request)
    {
        return Contact::with('account')
            ->when($request->account_id, fn ($q) => $q->where('account_id', $request->account_id))
            ->orderBy('last_name')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'account_id' => ['required', 'integer', 'exists:crm_accounts,id'],
            'first_name' => ['required', 'string', 'max:80'],
            'last_name' => ['nullable', 'string', 'max:80'],
            'email' => ['nullable', 'email'],
            'phone' => ['nullable', 'string', 'max:40'],
            'title' => ['nullable', 'string', 'max:80'],
        ]);

        return response()->json(Contact::create($data), 201);
    }
}
