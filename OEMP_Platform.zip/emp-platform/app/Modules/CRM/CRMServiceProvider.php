<?php

namespace App\Modules\CRM;

use App\Core\Support\ModuleServiceProvider;

class CRMServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'crm';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
