<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('crm_leads', function (Blueprint $table) {
            foreach ([['phone', 'string'], ['source', 'string'], ['score', 'integer'], ['owner_id', 'bigint'], ['converted_at', 'timestamp']] as [$col, $type]) {
                if (! Schema::hasColumn('crm_leads', $col)) {
                    match ($type) {
                        'integer' => $table->integer($col)->nullable(),
                        'bigint' => $table->unsignedBigInteger($col)->nullable(),
                        'timestamp' => $table->timestamp($col)->nullable(),
                        default => $table->string($col)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('crm_leads', function (Blueprint $table) {
            $table->dropColumn(['phone', 'source', 'score', 'owner_id', 'converted_at']);
        });
    }
};
