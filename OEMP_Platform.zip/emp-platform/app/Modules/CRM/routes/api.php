<?php

use Illuminate\Support\Facades\Route;
use App\Modules\CRM\Http\Controllers\LeadController;
use App\Modules\CRM\Http\Controllers\AccountController;
use App\Modules\CRM\Http\Controllers\ContactController;
use App\Modules\CRM\Http\Controllers\OpportunityController;
use App\Modules\CRM\Http\Controllers\ActivityController;
use App\Modules\CRM\Http\Controllers\CampaignController;
use App\Modules\CRM\Http\Controllers\CrmAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.crm'])
    ->prefix('api/crm')
    ->group(function () {
        // Leads
        Route::get('leads', [LeadController::class, 'index']);
        Route::post('leads', [LeadController::class, 'store']);
        Route::post('leads/{lead}/convert', [LeadController::class, 'convert']);

        // Accounts & Contacts
        Route::get('accounts', [AccountController::class, 'index']);
        Route::get('accounts/{account}', [AccountController::class, 'show']);
        Route::post('accounts', [AccountController::class, 'store']);
        Route::get('contacts', [ContactController::class, 'index']);
        Route::post('contacts', [ContactController::class, 'store']);

        // Opportunities & pipeline
        Route::get('opportunities', [OpportunityController::class, 'index']);
        Route::post('opportunities', [OpportunityController::class, 'store']);
        Route::post('opportunities/{opportunity}/move-stage', [OpportunityController::class, 'moveStage']);

        // Activities
        Route::get('activities', [ActivityController::class, 'index']);
        Route::post('activities', [ActivityController::class, 'store']);
        Route::post('activities/{activity}/complete', [ActivityController::class, 'complete']);

        // Campaigns
        Route::get('campaigns', [CampaignController::class, 'index']);
        Route::post('campaigns', [CampaignController::class, 'store']);

        // Analytics
        Route::get('analytics/pipeline', [CrmAnalyticsController::class, 'pipeline']);
        Route::get('analytics/win-rate', [CrmAnalyticsController::class, 'winRate']);
        Route::get('analytics/leads-by-source', [CrmAnalyticsController::class, 'leadsBySource']);
    });
