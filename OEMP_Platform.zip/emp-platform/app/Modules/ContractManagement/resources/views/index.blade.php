<div class="emp-module" data-module="contract_management">
    <h3>Contracts</h3>
    <p class="text-muted">ContractManagement module &mdash; managed by the EMP platform core.</p>
</div>
