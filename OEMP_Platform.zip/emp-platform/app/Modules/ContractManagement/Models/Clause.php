<?php

namespace App\Modules\ContractManagement\Models;

use App\Core\Support\BaseModel;

class Clause extends BaseModel
{
    protected $table = 'contract_clauses';
    protected $fillable = ['tenant_id', 'contract_id', 'title', 'body', 'type'];

}
