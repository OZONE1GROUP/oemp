<?php

namespace App\Modules\ContractManagement\Models;

use App\Core\Support\BaseModel;

class ContractApproval extends BaseModel
{
    protected $table = 'contract_approvals';
    protected $fillable = ['tenant_id', 'contract_id', 'approver', 'status', 'decided_at', 'comment'];
    protected $casts = ['decided_at' => 'datetime'];

}
