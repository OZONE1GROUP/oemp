<?php

namespace App\Modules\ContractManagement\Models;

use App\Core\Support\BaseModel;

class Renewal extends BaseModel
{
    protected $table = 'contract_renewals';
    protected $fillable = ['tenant_id', 'contract_id', 'renew_from', 'renew_to', 'status'];
    protected $casts = ['renew_from' => 'date', 'renew_to' => 'date'];

}
