<?php

namespace App\Modules\ContractManagement\Models;

use App\Core\Support\BaseModel;

class Obligation extends BaseModel
{
    protected $table = 'contract_obligations';
    protected $fillable = ['tenant_id', 'contract_id', 'title', 'due_date', 'owner', 'status'];
    protected $casts = ['due_date' => 'date'];

}
