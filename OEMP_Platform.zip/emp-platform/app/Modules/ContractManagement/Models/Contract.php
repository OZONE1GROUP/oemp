<?php

namespace App\Modules\ContractManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Contract extends BaseModel
{
    protected $table = 'contract_contracts';
    protected $fillable = ['tenant_id','contract_no','party','type','start_date','end_date','value',
        'status','owner','renewal_notice_days','auto_renew'];
    protected $casts = ['start_date' => 'date', 'end_date' => 'date', 'value' => 'decimal:2',
        'renewal_notice_days' => 'integer', 'auto_renew' => 'boolean'];

    public function clauses(): HasMany
    {
        return $this->hasMany(Clause::class);
    }

    public function obligations(): HasMany
    {
        return $this->hasMany(Obligation::class);
    }
}
