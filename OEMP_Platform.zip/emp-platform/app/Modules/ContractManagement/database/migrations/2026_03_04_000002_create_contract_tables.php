<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contract_clauses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('contract_id')->constrained('contract_contracts')->cascadeOnDelete();
            $table->string('title');
            $table->text('body');
            $table->string('type')->nullable();
            $table->timestamps();
        });

        Schema::create('contract_obligations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('contract_id')->constrained('contract_contracts')->cascadeOnDelete();
            $table->string('title');
            $table->date('due_date');
            $table->string('owner')->nullable();
            $table->string('status')->default('open');
            $table->timestamps();
        });

        Schema::create('contract_approvals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('contract_id')->constrained('contract_contracts')->cascadeOnDelete();
            $table->string('approver');
            $table->string('status')->default('pending');
            $table->timestamp('decided_at')->nullable();
            $table->string('comment')->nullable();
            $table->timestamps();
        });

        Schema::create('contract_renewals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('contract_id')->constrained('contract_contracts')->cascadeOnDelete();
            $table->date('renew_from')->nullable();
            $table->date('renew_to')->nullable();
            $table->string('status')->default('renewed');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contract_renewals');
        Schema::dropIfExists('contract_approvals');
        Schema::dropIfExists('contract_obligations');
        Schema::dropIfExists('contract_clauses');
    }
};
