<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contract_contracts', function (Blueprint $table) {
            foreach ([['owner','str'],['renewal_notice_days','int'],['auto_renew','bool']] as [$c,$t]) {
                if (! Schema::hasColumn('contract_contracts', $c)) {
                    match ($t) {
                        'int' => $table->integer($c)->default(30),
                        'bool' => $table->boolean($c)->default(false),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('contract_contracts', function (Blueprint $table) {
            $table->dropColumn(['owner', 'renewal_notice_days', 'auto_renew']);
        });
    }
};
