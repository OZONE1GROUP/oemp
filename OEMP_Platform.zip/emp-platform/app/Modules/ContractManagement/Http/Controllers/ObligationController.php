<?php

namespace App\Modules\ContractManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ContractManagement\Models\Contract;
use App\Modules\ContractManagement\Models\Obligation;
use Illuminate\Http\Request;

class ObligationController extends Controller
{
    public function index(Request $request)
    {
        return Obligation::when($request->status, fn ($q) => $q->where('status', $request->status))
            ->orderBy('due_date')->paginate(50);
    }

    public function store(Request $request, Contract $contract)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:150'],
            'due_date' => ['required', 'date'],
            'owner' => ['nullable', 'string', 'max:120'],
        ]);

        return response()->json($contract->obligations()->create(array_merge($data, ['status' => 'open'])), 201);
    }

    public function complete(Obligation $obligation)
    {
        $obligation->update(['status' => 'met']);

        return $obligation;
    }
}
