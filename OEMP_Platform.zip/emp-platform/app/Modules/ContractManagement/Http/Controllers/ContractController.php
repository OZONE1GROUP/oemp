<?php

namespace App\Modules\ContractManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ContractManagement\Models\Contract;
use App\Modules\ContractManagement\Models\ContractApproval;
use App\Modules\ContractManagement\Models\Renewal;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class ContractController extends Controller
{
    public function index(Request $request)
    {
        return Contract::with('clauses', 'obligations')
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'party' => ['required', 'string', 'max:150'],
            'type' => ['required', 'in:msa,nda,sow,vendor,customer,lease,employment,other'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after:start_date'],
            'value' => ['nullable', 'numeric', 'min:0'],
            'renewal_notice_days' => ['nullable', 'integer', 'min:0'],
            'auto_renew' => ['boolean'],
            'owner' => ['nullable', 'string', 'max:120'],
        ]);

        return response()->json(Contract::create(array_merge($data, [
            'contract_no' => 'CTR-' . now()->format('YmdHis'),
            'status' => 'draft',
        ])), 201);
    }

    public function submit(Request $request, Contract $contract)
    {
        $contract->update(['status' => 'in_review']);
        ContractApproval::create(['contract_id' => $contract->id, 'approver' => $request->input('approver', 'legal'), 'status' => 'pending']);

        return $contract;
    }

    public function approve(Request $request, Contract $contract, EventBus $bus)
    {
        abort_unless($contract->status === 'in_review', 422, 'Contract not in review.');
        ContractApproval::where('contract_id', $contract->id)->where('status', 'pending')
            ->update(['status' => 'approved', 'decided_at' => now(), 'comment' => $request->input('comment')]);
        $contract->update(['status' => 'active']);
        $bus->publish('contract.activated', ['id' => $contract->id]);

        return $contract;
    }

    /** Renew a contract, extending the term. */
    public function renew(Request $request, Contract $contract)
    {
        $data = $request->validate(['renew_to' => ['required', 'date', 'after:end_date']]);
        Renewal::create(['contract_id' => $contract->id, 'renew_from' => $contract->end_date, 'renew_to' => $data['renew_to'], 'status' => 'renewed']);
        $contract->update(['end_date' => $data['renew_to'], 'status' => 'active']);

        return $contract;
    }
}
