<?php

namespace App\Modules\ContractManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\ContractManagement\Models\Contract;
use Illuminate\Http\Request;

class ClauseController extends Controller
{
    public function store(Request $request, Contract $contract)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:150'],
            'body' => ['required', 'string'],
            'type' => ['nullable', 'in:payment,liability,termination,confidentiality,sla,ip,other'],
        ]);

        return response()->json($contract->clauses()->create($data), 201);
    }
}
