<?php

namespace App\Modules\ContractManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ContractAnalyticsController extends Controller
{
    /** Contracts expiring within 60 days. */
    public function expiringSoon()
    {
        return DB::table('contract_contracts')
            ->where('status', 'active')
            ->whereBetween('end_date', [now()->toDateString(), now()->addDays(60)->toDateString()])
            ->get(['id', 'contract_no', 'party', 'end_date', 'auto_renew']);
    }

    /** Contract value by type. */
    public function valueByType()
    {
        return DB::table('contract_contracts')
            ->groupBy('type')
            ->select('type', DB::raw('COUNT(*) as count'), DB::raw('SUM(value) as value'))
            ->get();
    }

    /** Obligations due in the next 30 days. */
    public function obligationsDue()
    {
        return DB::table('contract_obligations')
            ->where('status', 'open')
            ->where('due_date', '<=', now()->addDays(30)->toDateString())
            ->orderBy('due_date')->get();
    }
}
