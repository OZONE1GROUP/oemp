<?php

use Illuminate\Support\Facades\Route;
use App\Modules\ContractManagement\Http\Controllers\ContractController;
use App\Modules\ContractManagement\Http\Controllers\ClauseController;
use App\Modules\ContractManagement\Http\Controllers\ObligationController;
use App\Modules\ContractManagement\Http\Controllers\ContractAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.contract_management'])
    ->prefix('api/contracts')
    ->group(function () {
        Route::get('/', [ContractController::class, 'index']);
        Route::post('/', [ContractController::class, 'store']);
        Route::post('{contract}/submit', [ContractController::class, 'submit']);
        Route::post('{contract}/approve', [ContractController::class, 'approve']);
        Route::post('{contract}/renew', [ContractController::class, 'renew']);
        Route::post('{contract}/clauses', [ClauseController::class, 'store']);
        Route::post('{contract}/obligations', [ObligationController::class, 'store']);

        Route::get('obligations', [ObligationController::class, 'index']);
        Route::post('obligations/{obligation}/complete', [ObligationController::class, 'complete']);

        Route::get('analytics/expiring-soon', [ContractAnalyticsController::class, 'expiringSoon']);
        Route::get('analytics/value-by-type', [ContractAnalyticsController::class, 'valueByType']);
        Route::get('analytics/obligations-due', [ContractAnalyticsController::class, 'obligationsDue']);
    });
