<?php

namespace App\Modules\ContractManagement;

use App\Core\Support\ModuleServiceProvider;

class ContractManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'contract_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
