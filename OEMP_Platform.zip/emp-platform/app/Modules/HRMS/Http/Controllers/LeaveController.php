<?php

namespace App\Modules\HRMS\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HRMS\Models\LeaveRequest;
use App\Modules\HRMS\Models\LeaveType;
use App\Modules\HRMS\Http\Requests\StoreLeaveRequest;
use App\Core\Events\EventBus;
use Illuminate\Support\Carbon;

class LeaveController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        return LeaveRequest::with('type')
            ->when($request->employee_id, fn ($q) => $q->where('employee_id', $request->employee_id))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function store(StoreLeaveRequest $request)
    {
        $days = Carbon::parse($request->start_date)->diffInDays(Carbon::parse($request->end_date)) + 1;

        $leave = LeaveRequest::create(array_merge($request->validated(), [
            'days' => $days,
            'status' => 'pending',
        ]));

        return response()->json($leave, 201);
    }

    /** Approve after verifying remaining balance for the leave type. */
    public function approve(LeaveRequest $leaveRequest, EventBus $bus)
    {
        abort_unless($leaveRequest->status === 'pending', 422, 'Only pending requests can be approved.');

        $type = LeaveType::findOrFail($leaveRequest->leave_type_id);
        $used = LeaveRequest::where('employee_id', $leaveRequest->employee_id)
            ->where('leave_type_id', $leaveRequest->leave_type_id)
            ->where('status', 'approved')->sum('days');

        abort_if($used + $leaveRequest->days > $type->days_per_year, 422, 'Insufficient leave balance.');

        $leaveRequest->update(['status' => 'approved', 'approver_id' => request()->user()?->id]);
        $bus->publish('hrms.leave.approved', ['id' => $leaveRequest->id]);

        return $leaveRequest;
    }

    public function balance(int $employee, int $leaveType)
    {
        $type = LeaveType::findOrFail($leaveType);
        $used = LeaveRequest::where('employee_id', $employee)
            ->where('leave_type_id', $leaveType)->where('status', 'approved')->sum('days');

        return ['allowance' => $type->days_per_year, 'used' => $used, 'remaining' => $type->days_per_year - $used];
    }
}
