<?php

namespace App\Modules\HRMS\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HRMS\Models\Employee;
use App\Modules\HRMS\Http\Requests\StoreEmployeeRequest;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index(Request $request)
    {
        return Employee::with('department')
            ->when($request->department_id, fn ($q) => $q->where('department_id', $request->department_id))
            ->when($request->q, fn ($q) => $q->where('first_name', 'like', "%{$request->q}%")->orWhere('last_name', 'like', "%{$request->q}%"))
            ->orderBy('first_name')->paginate(50);
    }

    public function store(StoreEmployeeRequest $request, EventBus $bus)
    {
        $employee = Employee::create(array_merge($request->validated(), ['status' => 'active']));
        $bus->publish('hrms.employee.hired', ['id' => $employee->id]);

        return response()->json($employee, 201);
    }

    public function terminate(Employee $employee, EventBus $bus)
    {
        $employee->update(['status' => 'terminated']);
        $bus->publish('hrms.employee.terminated', ['id' => $employee->id]);

        return $employee;
    }
}
