<?php

namespace App\Modules\HRMS\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class HrAnalyticsController extends Controller
{
    /** Headcount by department. */
    public function headcount()
    {
        return DB::table('hrms_employees as e')
            ->leftJoin('hrms_departments as d', 'd.id', '=', 'e.department_id')
            ->where('e.status', 'active')
            ->groupBy('d.name')
            ->select('d.name as department', DB::raw('COUNT(*) as headcount'))
            ->get();
    }

    /** Attrition: terminated in last 12 months vs active. */
    public function attrition()
    {
        $active = DB::table('hrms_employees')->where('status', 'active')->count();
        $terminated = DB::table('hrms_employees')->where('status', 'terminated')
            ->where('updated_at', '>=', now()->subYear())->count();
        $base = $active + $terminated;

        return ['active' => $active, 'terminated_12m' => $terminated, 'attrition_rate' => $base ? round($terminated / $base * 100, 1) : 0];
    }

    /** Leave utilization by type. */
    public function leaveUtilization()
    {
        return DB::table('hrms_leave_requests as r')
            ->join('hrms_leave_types as t', 't.id', '=', 'r.leave_type_id')
            ->where('r.status', 'approved')
            ->groupBy('t.name')
            ->select('t.name as leave_type', DB::raw('SUM(r.days) as days_taken'))
            ->get();
    }
}
