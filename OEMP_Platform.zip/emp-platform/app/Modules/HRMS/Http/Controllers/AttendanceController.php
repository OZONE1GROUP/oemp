<?php

namespace App\Modules\HRMS\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HRMS\Models\Attendance;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function index(Request $request)
    {
        return Attendance::query()
            ->when($request->employee_id, fn ($q) => $q->where('employee_id', $request->employee_id))
            ->when($request->date, fn ($q) => $q->whereDate('date', $request->date))
            ->latest('date')->paginate(100);
    }

    public function checkIn(Request $request)
    {
        $data = $request->validate(['employee_id' => ['required', 'integer', 'exists:hrms_employees,id']]);
        $att = Attendance::firstOrCreate(
            ['employee_id' => $data['employee_id'], 'date' => now()->toDateString()],
            ['check_in' => now(), 'status' => 'present']
        );

        return response()->json($att, 201);
    }

    public function checkOut(Request $request)
    {
        $data = $request->validate(['employee_id' => ['required', 'integer', 'exists:hrms_employees,id']]);
        $att = Attendance::where('employee_id', $data['employee_id'])
            ->whereDate('date', now()->toDateString())->firstOrFail();
        $att->update([
            'check_out' => now(),
            'hours' => $att->check_in ? round(now()->diffInMinutes($att->check_in) / 60, 2) : 0,
        ]);

        return $att;
    }
}
