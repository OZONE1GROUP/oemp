<?php

namespace App\Modules\HRMS\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\HRMS\Models\Appraisal;
use Illuminate\Http\Request;

class AppraisalController extends Controller
{
    public function index(Request $request)
    {
        return Appraisal::query()
            ->when($request->cycle_id, fn ($q) => $q->where('cycle_id', $request->cycle_id))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'cycle_id' => ['required', 'integer', 'exists:hrms_appraisal_cycles,id'],
            'employee_id' => ['required', 'integer', 'exists:hrms_employees,id'],
            'rating' => ['required', 'numeric', 'min:1', 'max:5'],
            'comments' => ['nullable', 'string'],
        ]);

        return response()->json(Appraisal::create(array_merge($data, ['status' => 'submitted'])), 201);
    }
}
