<?php

namespace App\Modules\HRMS\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'employee_no' => ['required', 'string', 'max:30'],
            'first_name' => ['required', 'string', 'max:80'],
            'last_name' => ['nullable', 'string', 'max:80'],
            'email' => ['nullable', 'email'],
            'phone' => ['nullable', 'string', 'max:40'],
            'department_id' => ['nullable', 'integer', 'exists:hrms_departments,id'],
            'position_id' => ['nullable', 'integer', 'exists:hrms_positions,id'],
            'manager_id' => ['nullable', 'integer', 'exists:hrms_employees,id'],
            'hire_date' => ['required', 'date'],
            'employment_type' => ['required', 'in:full_time,part_time,contract,intern'],
        ];
    }
}
