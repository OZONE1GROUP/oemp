<?php

use Illuminate\Support\Facades\Route;
use App\Modules\HRMS\Http\Controllers\DepartmentController;
use App\Modules\HRMS\Http\Controllers\EmployeeController;
use App\Modules\HRMS\Http\Controllers\AttendanceController;
use App\Modules\HRMS\Http\Controllers\LeaveController;
use App\Modules\HRMS\Http\Controllers\AppraisalController;
use App\Modules\HRMS\Http\Controllers\HrAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.hrms'])
    ->prefix('api/hrms')
    ->group(function () {
        // Org & Employees
        Route::get('departments', [DepartmentController::class, 'index']);
        Route::post('departments', [DepartmentController::class, 'store']);
        Route::get('employees', [EmployeeController::class, 'index']);
        Route::post('employees', [EmployeeController::class, 'store']);
        Route::post('employees/{employee}/terminate', [EmployeeController::class, 'terminate']);

        // Attendance
        Route::get('attendance', [AttendanceController::class, 'index']);
        Route::post('attendance/check-in', [AttendanceController::class, 'checkIn']);
        Route::post('attendance/check-out', [AttendanceController::class, 'checkOut']);

        // Leave
        Route::get('leave', [LeaveController::class, 'index']);
        Route::post('leave', [LeaveController::class, 'store']);
        Route::post('leave/{leaveRequest}/approve', [LeaveController::class, 'approve']);
        Route::get('leave/balance/{employee}/{leaveType}', [LeaveController::class, 'balance']);

        // Performance
        Route::get('appraisals', [AppraisalController::class, 'index']);
        Route::post('appraisals', [AppraisalController::class, 'store']);

        // Analytics
        Route::get('analytics/headcount', [HrAnalyticsController::class, 'headcount']);
        Route::get('analytics/attrition', [HrAnalyticsController::class, 'attrition']);
        Route::get('analytics/leave-utilization', [HrAnalyticsController::class, 'leaveUtilization']);
    });
