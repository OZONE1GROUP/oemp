<?php

namespace App\Modules\HRMS;

use App\Core\Support\ModuleServiceProvider;

class HRMSServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'hrms';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
