<div class="emp-module" data-module="hrms">
    <h3>Employees</h3>
    <p class="text-muted">HRMS module &mdash; managed by the EMP platform core.</p>
</div>
