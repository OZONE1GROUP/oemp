<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hrms_appraisal_cycles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->date('period_start')->nullable();
            $table->date('period_end')->nullable();
            $table->string('status')->default('open');
            $table->timestamps();
        });

        Schema::create('hrms_appraisals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('cycle_id')->constrained('hrms_appraisal_cycles')->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('hrms_employees')->cascadeOnDelete();
            $table->decimal('rating', 3, 1)->nullable();
            $table->text('comments')->nullable();
            $table->string('status')->default('draft');
            $table->timestamps();
        });

        Schema::create('hrms_goals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('hrms_employees')->cascadeOnDelete();
            $table->unsignedBigInteger('cycle_id')->nullable();
            $table->string('title');
            $table->integer('weight')->default(0);
            $table->integer('progress')->default(0);
            $table->string('status')->default('active');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hrms_goals');
        Schema::dropIfExists('hrms_appraisals');
        Schema::dropIfExists('hrms_appraisal_cycles');
    }
};
