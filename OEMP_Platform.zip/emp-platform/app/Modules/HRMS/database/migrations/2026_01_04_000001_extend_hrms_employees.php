<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('hrms_employees', function (Blueprint $table) {
            foreach ([['email','string'],['phone','string'],['department_id','bigint'],['position_id','bigint'],['manager_id','bigint'],['hire_date','date'],['employment_type','string']] as [$c,$t]) {
                if (! Schema::hasColumn('hrms_employees', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'date' => $table->date($c)->nullable(),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('hrms_employees', function (Blueprint $table) {
            $table->dropColumn(['email','phone','department_id','position_id','manager_id','hire_date','employment_type']);
        });
    }
};
