<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;

class Shift extends BaseModel
{
    protected $table = 'hrms_shifts';
    protected $fillable = ['tenant_id', 'name', 'starts_at', 'ends_at', 'grace_minutes'];

}
