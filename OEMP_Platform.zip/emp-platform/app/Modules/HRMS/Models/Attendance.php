<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;

class Attendance extends BaseModel
{
    protected $table = 'hrms_attendance';
    protected $fillable = ['tenant_id', 'employee_id', 'date', 'check_in', 'check_out', 'hours', 'status'];
    protected $casts = ['date' => 'date', 'check_in' => 'datetime', 'check_out' => 'datetime', 'hours' => 'decimal:2'];

}
