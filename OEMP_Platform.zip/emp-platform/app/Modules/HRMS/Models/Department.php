<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Department extends BaseModel
{
    protected $table = 'hrms_departments';
    protected $fillable = ['tenant_id', 'code', 'name', 'parent_id', 'head_id'];

    public function employees(): HasMany
    {
        return $this->hasMany(Employee::class);
    }
}
