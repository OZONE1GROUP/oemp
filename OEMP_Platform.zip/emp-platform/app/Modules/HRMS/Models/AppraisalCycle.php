<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;

class AppraisalCycle extends BaseModel
{
    protected $table = 'hrms_appraisal_cycles';
    protected $fillable = ['tenant_id', 'name', 'period_start', 'period_end', 'status'];
    protected $casts = ['period_start' => 'date', 'period_end' => 'date'];

}
