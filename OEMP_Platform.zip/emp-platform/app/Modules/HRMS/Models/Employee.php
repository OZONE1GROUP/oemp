<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Employee extends BaseModel
{
    protected $table = 'hrms_employees';
    protected $fillable = ['tenant_id','employee_no','first_name','last_name','email','phone',
        'department_id','position_id','manager_id','hire_date','employment_type','status'];
    protected $casts = ['hire_date' => 'date'];

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }

    public function leaveRequests(): HasMany
    {
        return $this->hasMany(LeaveRequest::class);
    }

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }
}
