<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;

class Goal extends BaseModel
{
    protected $table = 'hrms_goals';
    protected $fillable = ['tenant_id', 'employee_id', 'cycle_id', 'title', 'weight', 'progress', 'status'];
    protected $casts = ['weight' => 'integer', 'progress' => 'integer'];

}
