<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LeaveRequest extends BaseModel
{
    protected $table = 'hrms_leave_requests';
    protected $fillable = ['tenant_id', 'employee_id', 'leave_type_id', 'start_date', 'end_date', 'days', 'reason', 'status', 'approver_id'];
    protected $casts = ['start_date' => 'date', 'end_date' => 'date', 'days' => 'decimal:2'];

    public function type(): BelongsTo
    {
        return $this->belongsTo(LeaveType::class, 'leave_type_id');
    }
}
