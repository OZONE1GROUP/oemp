<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;

class LeaveType extends BaseModel
{
    protected $table = 'hrms_leave_types';
    protected $fillable = ['tenant_id', 'code', 'name', 'days_per_year', 'paid'];
    protected $casts = ['days_per_year' => 'decimal:2', 'paid' => 'boolean'];

}
