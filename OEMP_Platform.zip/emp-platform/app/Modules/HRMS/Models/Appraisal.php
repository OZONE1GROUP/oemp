<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;

class Appraisal extends BaseModel
{
    protected $table = 'hrms_appraisals';
    protected $fillable = ['tenant_id', 'cycle_id', 'employee_id', 'rating', 'comments', 'status'];
    protected $casts = ['rating' => 'decimal:1'];

}
