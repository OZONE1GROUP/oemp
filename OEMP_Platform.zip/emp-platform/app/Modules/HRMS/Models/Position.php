<?php

namespace App\Modules\HRMS\Models;

use App\Core\Support\BaseModel;

class Position extends BaseModel
{
    protected $table = 'hrms_positions';
    protected $fillable = ['tenant_id', 'code', 'title', 'department_id', 'grade'];

}
