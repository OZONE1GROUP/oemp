<?php

namespace App\Modules\Esg\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Esg\Models\EmissionSource;
use App\Modules\Esg\Models\EmissionFactor;
use App\Modules\Esg\Models\ActivityRecord;
use App\Modules\Esg\Services\CarbonCalculator;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class EmissionController extends Controller
{
    public function sources()
    {
        return EmissionSource::get();
    }

    public function storeSource(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'scope' => ['required', 'in:scope_1,scope_2,scope_3'],
            'category' => ['nullable', 'string', 'max:80'],
        ]);

        return response()->json(EmissionSource::create(array_merge($data, ['co2e' => 0])), 201);
    }

    public function factors()
    {
        return EmissionFactor::get();
    }

    public function storeFactor(Request $request)
    {
        $data = $request->validate([
            'activity_type' => ['required', 'string', 'max:80'],
            'unit' => ['required', 'string', 'max:20'],
            'factor_kgco2e' => ['required', 'numeric', 'min:0'],
            'scope' => ['required', 'in:scope_1,scope_2,scope_3'],
            'source_ref' => ['nullable', 'string', 'max:150'],
        ]);

        return response()->json(EmissionFactor::create($data), 201);
    }

    /** Record activity data and compute CO2e via the factor library. */
    public function recordActivity(Request $request, CarbonCalculator $calc, EventBus $bus)
    {
        $data = $request->validate([
            'emission_source_id' => ['required', 'integer', 'exists:esg_emission_sources,id'],
            'activity_type' => ['required', 'string', 'max:80'],
            'quantity' => ['required', 'numeric', 'min:0'],
            'unit' => ['required', 'string', 'max:20'],
            'period' => ['required', 'string', 'max:7'],
        ]);
        $result = $calc->co2e($data['activity_type'], $data['quantity']);

        $record = ActivityRecord::create(array_merge($data, [
            'co2e' => $result['co2e_tonnes'], 'scope' => $result['scope'],
        ]));
        $bus->publish('esg.activity.recorded', ['id' => $record->id, 'co2e' => $result['co2e_tonnes']]);

        return response()->json(['record' => $record, 'calc' => $result], 201);
    }
}
