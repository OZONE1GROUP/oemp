<?php

namespace App\Modules\Esg\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Esg\Models\Disclosure;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class DisclosureController extends Controller
{
    public function index()
    {
        return Disclosure::latest()->get();
    }

    /** Generate a framework-aligned disclosure pack (GRI/CSRD/TCFD) for a period. */
    public function generate(Request $request)
    {
        $data = $request->validate([
            'framework' => ['required', 'in:GRI,CSRD,TCFD,SASB'],
            'period' => ['required', 'string', 'max:7'],
        ]);

        $footprint = DB::table('esg_activity_records')
            ->where('period', $data['period'])
            ->groupBy('scope')
            ->select('scope', DB::raw('SUM(co2e) as co2e'))
            ->pluck('co2e', 'scope');

        $payload = [
            'framework' => $data['framework'],
            'period' => $data['period'],
            'emissions' => [
                'scope_1' => round((float) ($footprint['scope_1'] ?? 0), 2),
                'scope_2' => round((float) ($footprint['scope_2'] ?? 0), 2),
                'scope_3' => round((float) ($footprint['scope_3'] ?? 0), 2),
            ],
            'total_co2e' => round((float) $footprint->sum(), 2),
        ];

        $disclosure = Disclosure::create([
            'framework' => $data['framework'], 'period' => $data['period'],
            'status' => 'draft', 'payload' => $payload,
        ]);

        return response()->json($disclosure, 201);
    }
}
