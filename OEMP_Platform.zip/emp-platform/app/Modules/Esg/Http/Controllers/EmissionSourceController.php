<?php

namespace App\Modules\Esg\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Esg\Models\EmissionSource;
use Illuminate\Http\Request;

class EmissionSourceController extends Controller
{
    public function index(Request $request)
    {
        return EmissionSource::query()
            ->when($request->q, fn ($qq) => $qq->where('name', 'like', "%{$request->q}%"))
            ->latest()
            ->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'scope' => 'nullable|string|max:255',
            'category' => 'nullable|string|max:255',
            'co2e' => 'nullable|numeric',
            'period' => 'nullable|string|max:255',
        ]);

        return response()->json(EmissionSource::create($data), 201);
    }

    public function show(EmissionSource $esgItem)
    {
        return $esgItem;
    }

    public function update(Request $request, EmissionSource $esgItem)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'scope' => 'nullable|string|max:255',
            'category' => 'nullable|string|max:255',
            'co2e' => 'nullable|numeric',
            'period' => 'nullable|string|max:255',
        ]);
        $esgItem->update($data);

        return $esgItem;
    }

    public function destroy(EmissionSource $esgItem)
    {
        $esgItem->delete();

        return response()->noContent();
    }
}
