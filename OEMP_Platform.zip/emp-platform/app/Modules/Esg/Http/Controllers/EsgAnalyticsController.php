<?php

namespace App\Modules\Esg\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class EsgAnalyticsController extends Controller
{
    /** Carbon footprint by scope. */
    public function footprintByScope()
    {
        return DB::table('esg_activity_records')
            ->groupBy('scope')
            ->select('scope', DB::raw('SUM(co2e) as co2e_tonnes'))
            ->get();
    }

    /** Emissions trend by period. */
    public function trend()
    {
        return DB::table('esg_activity_records')
            ->groupBy('period')
            ->select('period', DB::raw('SUM(co2e) as co2e_tonnes'))
            ->orderBy('period')
            ->get();
    }

    /** ESG metrics snapshot by category. */
    public function metricsByCategory()
    {
        return DB::table('esg_metrics')
            ->groupBy('category')
            ->select('category', DB::raw('COUNT(*) as metrics'))
            ->get();
    }
}
