<?php

namespace App\Modules\Esg\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Esg\Models\EsgTarget;
use App\Modules\Esg\Models\EsgMetric;
use App\Modules\Esg\Models\Initiative;
use Illuminate\Http\Request;

class TargetController extends Controller
{
    public function metrics()
    {
        return EsgMetric::latest()->paginate(100);
    }

    public function storeMetric(Request $request)
    {
        $data = $request->validate([
            'category' => ['required', 'in:environment,social,governance,energy,water,waste'],
            'name' => ['required', 'string', 'max:120'],
            'value' => ['required', 'numeric'],
            'unit' => ['nullable', 'string', 'max:20'],
            'period' => ['required', 'string', 'max:7'],
        ]);

        return response()->json(EsgMetric::create($data), 201);
    }

    public function targets()
    {
        return EsgTarget::get()->map(function ($t) {
            $range = ($t->baseline - $t->target_value);
            $done = $range != 0 ? ($t->baseline - $t->current) / $range * 100 : 0;
            $t->progress_pct = round(max(0, min(100, $done)), 1);
            return $t;
        });
    }

    public function storeTarget(Request $request)
    {
        $data = $request->validate([
            'metric' => ['required', 'string', 'max:120'],
            'baseline' => ['required', 'numeric'],
            'baseline_year' => ['required', 'integer'],
            'target_value' => ['required', 'numeric'],
            'target_year' => ['required', 'integer'],
            'current' => ['nullable', 'numeric'],
        ]);

        return response()->json(EsgTarget::create(array_merge($data, ['current' => $data['current'] ?? $data['baseline']])), 201);
    }

    public function initiatives()
    {
        return Initiative::get();
    }

    public function storeInitiative(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'description' => ['nullable', 'string'],
            'expected_reduction' => ['nullable', 'numeric', 'min:0'],
        ]);

        return response()->json(Initiative::create(array_merge($data, ['status' => 'planned'])), 201);
    }
}
