<?php

namespace App\Modules\Esg;

use App\Core\Support\ModuleServiceProvider;

class EsgServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'esg';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
