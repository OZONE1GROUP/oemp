<?php

namespace App\Modules\Esg\Services;

use App\Modules\Esg\Models\EmissionFactor;

/**
 * Converts activity data to CO2e using the versioned emission-factor library.
 * co2e (tonnes) = quantity x factor(kgCO2e per unit) / 1000.
 */
class CarbonCalculator
{
    public function co2e(string $activityType, float $quantity): array
    {
        $factor = EmissionFactor::where('activity_type', $activityType)->latest('id')->first();
        $kg = $factor ? $quantity * (float) $factor->factor_kgco2e : 0.0;

        return [
            'scope' => $factor->scope ?? 'scope_3',
            'factor' => $factor?->factor_kgco2e,
            'co2e_tonnes' => round($kg / 1000, 4),
        ];
    }
}
