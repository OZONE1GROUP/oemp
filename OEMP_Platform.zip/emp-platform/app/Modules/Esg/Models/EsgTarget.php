<?php

namespace App\Modules\Esg\Models;

use App\Core\Support\BaseModel;

class EsgTarget extends BaseModel
{
    protected $table = 'esg_targets';
    protected $fillable = ['tenant_id', 'metric', 'baseline', 'baseline_year', 'target_value', 'target_year', 'current'];
    protected $casts = ['baseline' => 'decimal:4', 'baseline_year' => 'integer', 'target_value' => 'decimal:4', 'target_year' => 'integer', 'current' => 'decimal:4'];

}
