<?php

namespace App\Modules\Esg\Models;

use App\Core\Support\BaseModel;

class Disclosure extends BaseModel
{
    protected $table = 'esg_disclosures';
    protected $fillable = ['tenant_id', 'framework', 'period', 'status', 'payload'];
    protected $casts = ['payload' => 'array'];

}
