<?php

namespace App\Modules\Esg\Models;

use App\Core\Support\BaseModel;

class ActivityRecord extends BaseModel
{
    protected $table = 'esg_activity_records';
    protected $fillable = ['tenant_id', 'emission_source_id', 'activity_type', 'quantity', 'unit', 'period', 'co2e', 'scope'];
    protected $casts = ['quantity' => 'decimal:4', 'co2e' => 'decimal:2'];

}
