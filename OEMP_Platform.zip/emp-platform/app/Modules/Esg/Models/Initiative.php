<?php

namespace App\Modules\Esg\Models;

use App\Core\Support\BaseModel;

class Initiative extends BaseModel
{
    protected $table = 'esg_initiatives';
    protected $fillable = ['tenant_id', 'name', 'description', 'status', 'expected_reduction'];
    protected $casts = ['expected_reduction' => 'decimal:2'];

}
