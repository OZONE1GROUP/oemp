<?php

namespace App\Modules\Esg\Models;

use App\Core\Support\BaseModel;

class EsgMetric extends BaseModel
{
    protected $table = 'esg_metrics';
    protected $fillable = ['tenant_id', 'category', 'name', 'value', 'unit', 'period'];
    protected $casts = ['value' => 'decimal:4'];

}
