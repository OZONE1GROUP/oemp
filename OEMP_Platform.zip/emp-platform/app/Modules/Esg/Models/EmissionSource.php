<?php

namespace App\Modules\Esg\Models;

use App\Core\Support\BaseModel;

class EmissionSource extends BaseModel
{
    protected $table = 'esg_emission_sources';
    protected $fillable = ['tenant_id','name','scope','category','co2e','period'];
    protected $casts = ['co2e' => 'decimal:2'];
}
