<?php

namespace App\Modules\Esg\Models;

use App\Core\Support\BaseModel;

class EmissionFactor extends BaseModel
{
    protected $table = 'esg_factors';
    protected $fillable = ['tenant_id', 'activity_type', 'unit', 'factor_kgco2e', 'scope', 'source_ref'];
    protected $casts = ['factor_kgco2e' => 'decimal:6'];

}
