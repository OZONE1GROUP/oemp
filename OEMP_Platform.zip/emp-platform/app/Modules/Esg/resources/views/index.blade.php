<div class="emp-module" data-module="esg">
    <h3>EmissionSources</h3>
    <p class="text-muted">Esg module &mdash; managed by the EMP platform core.</p>
</div>
