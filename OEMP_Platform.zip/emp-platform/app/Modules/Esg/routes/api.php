<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Esg\Http\Controllers\EmissionController;
use App\Modules\Esg\Http\Controllers\TargetController;
use App\Modules\Esg\Http\Controllers\DisclosureController;
use App\Modules\Esg\Http\Controllers\EsgAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.esg'])
    ->prefix('api/esg')
    ->group(function () {
        Route::get('sources', [EmissionController::class, 'sources']);
        Route::post('sources', [EmissionController::class, 'storeSource']);
        Route::get('factors', [EmissionController::class, 'factors']);
        Route::post('factors', [EmissionController::class, 'storeFactor']);
        Route::post('activity', [EmissionController::class, 'recordActivity']);

        Route::get('metrics', [TargetController::class, 'metrics']);
        Route::post('metrics', [TargetController::class, 'storeMetric']);
        Route::get('targets', [TargetController::class, 'targets']);
        Route::post('targets', [TargetController::class, 'storeTarget']);
        Route::get('initiatives', [TargetController::class, 'initiatives']);
        Route::post('initiatives', [TargetController::class, 'storeInitiative']);

        Route::get('disclosures', [DisclosureController::class, 'index']);
        Route::post('disclosures/generate', [DisclosureController::class, 'generate']);

        Route::get('analytics/footprint-by-scope', [EsgAnalyticsController::class, 'footprintByScope']);
        Route::get('analytics/trend', [EsgAnalyticsController::class, 'trend']);
        Route::get('analytics/metrics-by-category', [EsgAnalyticsController::class, 'metricsByCategory']);
    });
