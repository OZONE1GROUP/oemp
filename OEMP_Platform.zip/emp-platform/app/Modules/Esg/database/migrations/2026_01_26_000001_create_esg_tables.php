<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('esg_factors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('activity_type');
            $table->string('unit');
            $table->decimal('factor_kgco2e', 14, 6)->default(0);
            $table->string('scope')->default('scope_3');
            $table->string('source_ref')->nullable();
            $table->timestamps();
        });

        Schema::create('esg_activity_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('emission_source_id')->constrained('esg_emission_sources')->cascadeOnDelete();
            $table->string('activity_type');
            $table->decimal('quantity', 18, 4)->default(0);
            $table->string('unit');
            $table->string('period');
            $table->decimal('co2e', 18, 2)->default(0);
            $table->string('scope')->default('scope_3');
            $table->timestamps();
        });

        Schema::create('esg_metrics', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('category');
            $table->string('name');
            $table->decimal('value', 18, 4)->default(0);
            $table->string('unit')->nullable();
            $table->string('period');
            $table->timestamps();
        });

        Schema::create('esg_targets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('metric');
            $table->decimal('baseline', 18, 4)->default(0);
            $table->integer('baseline_year')->nullable();
            $table->decimal('target_value', 18, 4)->default(0);
            $table->integer('target_year')->nullable();
            $table->decimal('current', 18, 4)->default(0);
            $table->timestamps();
        });

        Schema::create('esg_initiatives', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('status')->default('planned');
            $table->decimal('expected_reduction', 14, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('esg_disclosures', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('framework');
            $table->string('period');
            $table->string('status')->default('draft');
            $table->json('payload')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('esg_disclosures');
        Schema::dropIfExists('esg_initiatives');
        Schema::dropIfExists('esg_targets');
        Schema::dropIfExists('esg_metrics');
        Schema::dropIfExists('esg_activity_records');
        Schema::dropIfExists('esg_factors');
    }
};
