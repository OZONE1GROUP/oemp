<?php

namespace App\Modules\Compliance;

use App\Core\Support\ModuleServiceProvider;

class ComplianceServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'compliance';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
