<div class="emp-module" data-module="compliance">
    <h3>ComplianceRequirements</h3>
    <p class="text-muted">Compliance module &mdash; managed by the EMP platform core.</p>
</div>
