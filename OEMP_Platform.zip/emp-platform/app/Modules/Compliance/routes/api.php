<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Compliance\Http\Controllers\FrameworkController;
use App\Modules\Compliance\Http\Controllers\RequirementController;
use App\Modules\Compliance\Http\Controllers\ControlController;
use App\Modules\Compliance\Http\Controllers\EvidenceController;
use App\Modules\Compliance\Http\Controllers\AuditController;
use App\Modules\Compliance\Http\Controllers\ComplianceAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.compliance'])
    ->prefix('api/compliance')
    ->group(function () {
        Route::get('frameworks', [FrameworkController::class, 'index']);
        Route::post('frameworks', [FrameworkController::class, 'store']);

        Route::get('requirements', [RequirementController::class, 'index']);
        Route::post('requirements', [RequirementController::class, 'store']);

        Route::get('controls', [ControlController::class, 'index']);
        Route::post('controls', [ControlController::class, 'store']);
        Route::post('controls/{control}/assess', [ControlController::class, 'assess']);

        Route::get('evidence', [EvidenceController::class, 'index']);
        Route::post('evidence', [EvidenceController::class, 'store']);

        Route::get('audits', [AuditController::class, 'index']);
        Route::post('audits', [AuditController::class, 'store']);
        Route::post('audits/{audit}/findings', [AuditController::class, 'addFinding']);
        Route::get('findings', [AuditController::class, 'findings']);

        Route::get('analytics/compliance-rate', [ComplianceAnalyticsController::class, 'complianceRate']);
        Route::get('analytics/control-effectiveness', [ComplianceAnalyticsController::class, 'controlEffectiveness']);
        Route::get('analytics/open-findings', [ComplianceAnalyticsController::class, 'openFindings']);
    });
