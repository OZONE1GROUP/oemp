<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('compliance_requirements', function (Blueprint $table) {
            if (! Schema::hasColumn('compliance_requirements', 'owner')) {
                $table->string('owner')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('compliance_requirements', function (Blueprint $table) {
            $table->dropColumn('owner');
        });
    }
};
