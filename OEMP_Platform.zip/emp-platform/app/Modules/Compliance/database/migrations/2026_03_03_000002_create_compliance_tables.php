<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('compliance_frameworks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code');
            $table->string('name');
            $table->string('description')->nullable();
            $table->timestamps();
        });

        Schema::create('compliance_controls', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('requirement_id')->constrained('compliance_requirements')->cascadeOnDelete();
            $table->string('name');
            $table->string('type')->default('preventive');
            $table->string('frequency')->default('quarterly');
            $table->string('owner')->nullable();
            $table->string('status')->default('active');
            $table->timestamps();
        });

        Schema::create('compliance_assessments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('control_id')->constrained('compliance_controls')->cascadeOnDelete();
            $table->string('result')->default('pass');
            $table->text('notes')->nullable();
            $table->timestamp('assessed_at')->nullable();
            $table->string('assessor')->nullable();
        });

        Schema::create('compliance_evidence', function (Blueprint $table) {
            $table->id();
            $table->foreignId('control_id')->constrained('compliance_controls')->cascadeOnDelete();
            $table->string('title');
            $table->string('file_ref')->nullable();
            $table->timestamp('collected_at')->nullable();
        });

        Schema::create('compliance_audits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->string('framework');
            $table->string('period')->nullable();
            $table->string('status')->default('planned');
            $table->timestamps();
        });

        Schema::create('compliance_findings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('audit_id')->constrained('compliance_audits')->cascadeOnDelete();
            $table->string('severity')->default('medium');
            $table->text('description');
            $table->string('status')->default('open');
            $table->text('remediation')->nullable();
            $table->date('due_date')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('compliance_findings');
        Schema::dropIfExists('compliance_audits');
        Schema::dropIfExists('compliance_evidence');
        Schema::dropIfExists('compliance_assessments');
        Schema::dropIfExists('compliance_controls');
        Schema::dropIfExists('compliance_frameworks');
    }
};
