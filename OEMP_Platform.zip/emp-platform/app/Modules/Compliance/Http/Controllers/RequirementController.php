<?php

namespace App\Modules\Compliance\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Compliance\Models\ComplianceRequirement;
use Illuminate\Http\Request;

class RequirementController extends Controller
{
    public function index(Request $request)
    {
        return ComplianceRequirement::with('controls')
            ->when($request->framework, fn ($q) => $q->where('framework', $request->framework))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:40'],
            'framework' => ['required', 'string', 'max:40'],
            'description' => ['required', 'string'],
            'due_date' => ['nullable', 'date'],
            'owner' => ['nullable', 'string', 'max:120'],
        ]);

        return response()->json(ComplianceRequirement::create(array_merge($data, ['status' => 'open'])), 201);
    }
}
