<?php

namespace App\Modules\Compliance\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Compliance\Models\Framework;
use Illuminate\Http\Request;

class FrameworkController extends Controller
{
    public function index()
    {
        return Framework::get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:30'],
            'name' => ['required', 'string', 'max:120'],
            'description' => ['nullable', 'string'],
        ]);

        return response()->json(Framework::create($data), 201);
    }
}
