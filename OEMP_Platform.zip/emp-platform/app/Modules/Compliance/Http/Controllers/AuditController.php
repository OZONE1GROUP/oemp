<?php

namespace App\Modules\Compliance\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Compliance\Models\Audit;
use App\Modules\Compliance\Models\Finding;
use Illuminate\Http\Request;

class AuditController extends Controller
{
    public function index()
    {
        return Audit::latest()->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'framework' => ['required', 'string', 'max:40'],
            'period' => ['nullable', 'string', 'max:20'],
        ]);

        return response()->json(Audit::create(array_merge($data, ['status' => 'planned'])), 201);
    }

    public function addFinding(Request $request, Audit $audit)
    {
        $data = $request->validate([
            'severity' => ['required', 'in:low,medium,high,critical'],
            'description' => ['required', 'string'],
            'remediation' => ['nullable', 'string'],
            'due_date' => ['nullable', 'date'],
        ]);

        return response()->json($audit->findings()->create(array_merge($data, ['status' => 'open'])), 201);
    }

    public function findings(Request $request)
    {
        return Finding::when($request->status, fn ($q) => $q->where('status', $request->status))->latest()->paginate(50);
    }
}
