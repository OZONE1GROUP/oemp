<?php

namespace App\Modules\Compliance\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Compliance\Models\ComplianceRequirement;
use Illuminate\Http\Request;

class ComplianceRequirementController extends Controller
{
    public function index(Request $request)
    {
        return ComplianceRequirement::query()
            ->when($request->q, fn ($qq) => $qq->where('code', 'like', "%{$request->q}%"))
            ->latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => 'required|string|max:255',
            'framework' => 'nullable|string|max:255',
            'description' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
            'due_date' => 'nullable|date',
        ]);

        return response()->json(ComplianceRequirement::create($data), 201);
    }

    public function show(ComplianceRequirement $complianceItem)
    {
        return $complianceItem;
    }

    public function update(Request $request, ComplianceRequirement $complianceItem)
    {
        $data = $request->validate([
            'code' => 'required|string|max:255',
            'framework' => 'nullable|string|max:255',
            'description' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
            'due_date' => 'nullable|date',
        ]);
        $complianceItem->update($data);

        return $complianceItem;
    }

    public function destroy(ComplianceRequirement $complianceItem)
    {
        $complianceItem->delete();

        return response()->noContent();
    }
}
