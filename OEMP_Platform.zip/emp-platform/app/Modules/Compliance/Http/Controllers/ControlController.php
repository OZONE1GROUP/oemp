<?php

namespace App\Modules\Compliance\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Compliance\Models\Control;
use App\Modules\Compliance\Models\ComplianceRequirement;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class ControlController extends Controller
{
    public function index(Request $request)
    {
        return Control::with('assessments')
            ->when($request->requirement_id, fn ($q) => $q->where('requirement_id', $request->requirement_id))
            ->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'requirement_id' => ['required', 'integer', 'exists:compliance_requirements,id'],
            'name' => ['required', 'string', 'max:150'],
            'type' => ['required', 'in:preventive,detective,corrective'],
            'frequency' => ['required', 'in:continuous,daily,weekly,monthly,quarterly,annual'],
            'owner' => ['nullable', 'string', 'max:120'],
        ]);

        return response()->json(Control::create(array_merge($data, ['status' => 'active'])), 201);
    }

    /** Assess a control; a pass marks the linked requirement compliant when all pass. */
    public function assess(Request $request, Control $control, EventBus $bus)
    {
        $data = $request->validate([
            'result' => ['required', 'in:pass,fail,partial'],
            'notes' => ['nullable', 'string'],
        ]);
        $control->assessments()->create(array_merge($data, ['assessed_at' => now(), 'assessor' => $request->user()?->name]));
        $control->update(['status' => $data['result'] === 'pass' ? 'effective' : 'deficient']);

        $req = ComplianceRequirement::with('controls')->find($control->requirement_id);
        $allEffective = $req->controls->every(fn ($c) => $c->status === 'effective');
        $req->update(['status' => $allEffective ? 'compliant' : 'open']);

        if ($data['result'] === 'fail') {
            $bus->publish('compliance.control.failed', ['control_id' => $control->id]);
        }

        return $control->fresh()->load('assessments');
    }
}
