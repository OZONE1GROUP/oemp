<?php

namespace App\Modules\Compliance\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Compliance\Models\Evidence;
use Illuminate\Http\Request;

class EvidenceController extends Controller
{
    public function index(Request $request)
    {
        return Evidence::when($request->control_id, fn ($q) => $q->where('control_id', $request->control_id))->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'control_id' => ['required', 'integer', 'exists:compliance_controls,id'],
            'title' => ['required', 'string', 'max:150'],
            'file_ref' => ['nullable', 'string', 'max:255'],
        ]);

        return response()->json(Evidence::create(array_merge($data, ['collected_at' => now()])), 201);
    }
}
