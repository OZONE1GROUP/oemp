<?php

namespace App\Modules\Compliance\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ComplianceAnalyticsController extends Controller
{
    /** Compliance rate: compliant requirements / total. */
    public function complianceRate()
    {
        $total = DB::table('compliance_requirements')->count();
        $compliant = DB::table('compliance_requirements')->where('status', 'compliant')->count();

        return ['total' => $total, 'compliant' => $compliant, 'rate_pct' => $total ? round($compliant / $total * 100, 1) : 0];
    }

    /** Control effectiveness. */
    public function controlEffectiveness()
    {
        return DB::table('compliance_controls')
            ->groupBy('status')
            ->select('status', DB::raw('COUNT(*) as count'))
            ->get();
    }

    /** Open findings by severity. */
    public function openFindings()
    {
        return DB::table('compliance_findings')
            ->where('status', 'open')
            ->groupBy('severity')
            ->select('severity', DB::raw('COUNT(*) as count'))
            ->get();
    }
}
