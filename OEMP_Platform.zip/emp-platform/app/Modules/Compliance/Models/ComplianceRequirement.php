<?php

namespace App\Modules\Compliance\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ComplianceRequirement extends BaseModel
{
    protected $table = 'compliance_requirements';
    protected $fillable = ['tenant_id','code','framework','description','status','due_date','owner'];
    protected $casts = ['due_date' => 'date'];

    public function controls(): HasMany
    {
        return $this->hasMany(Control::class, 'requirement_id');
    }
}
