<?php

namespace App\Modules\Compliance\Models;

use App\Core\Support\BaseModel;

class Evidence extends BaseModel
{
    protected $table = 'compliance_evidence';
    protected $fillable = ['tenant_id', 'control_id', 'title', 'file_ref', 'collected_at'];
    protected $casts = ['collected_at' => 'datetime'];

}
