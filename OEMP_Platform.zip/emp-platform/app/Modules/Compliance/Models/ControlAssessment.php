<?php

namespace App\Modules\Compliance\Models;

use App\Core\Support\BaseModel;

class ControlAssessment extends BaseModel
{
    protected $table = 'compliance_assessments';
    protected $fillable = ['tenant_id', 'control_id', 'result', 'notes', 'assessed_at', 'assessor'];
    protected $casts = ['assessed_at' => 'datetime'];

}
