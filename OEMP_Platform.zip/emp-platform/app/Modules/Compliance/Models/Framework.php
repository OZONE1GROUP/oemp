<?php

namespace App\Modules\Compliance\Models;

use App\Core\Support\BaseModel;

class Framework extends BaseModel
{
    protected $table = 'compliance_frameworks';
    protected $fillable = ['tenant_id', 'code', 'name', 'description'];

}
