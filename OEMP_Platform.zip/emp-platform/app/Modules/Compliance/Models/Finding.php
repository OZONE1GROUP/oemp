<?php

namespace App\Modules\Compliance\Models;

use App\Core\Support\BaseModel;

class Finding extends BaseModel
{
    protected $table = 'compliance_findings';
    protected $fillable = ['tenant_id', 'audit_id', 'severity', 'description', 'status', 'remediation', 'due_date'];
    protected $casts = ['due_date' => 'date'];

}
