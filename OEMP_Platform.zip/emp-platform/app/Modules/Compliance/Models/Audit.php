<?php

namespace App\Modules\Compliance\Models;

use App\Core\Support\BaseModel;

class Audit extends BaseModel
{
    protected $table = 'compliance_audits';
    protected $fillable = ['tenant_id', 'name', 'framework', 'period', 'status'];

}
