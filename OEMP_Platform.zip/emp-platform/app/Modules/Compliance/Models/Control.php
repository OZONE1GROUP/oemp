<?php

namespace App\Modules\Compliance\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Control extends BaseModel
{
    protected $table = 'compliance_controls';
    protected $fillable = ['tenant_id', 'requirement_id', 'name', 'type', 'frequency', 'owner', 'status'];

    public function assessments(): HasMany
    {
        return $this->hasMany(ControlAssessment::class, 'control_id');
    }
}
