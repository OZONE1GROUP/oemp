<?php

namespace App\Modules\KnowledgeManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class KmAnalyticsController extends Controller
{
    public function topArticles()
    {
        return DB::table('km_items')->where('status', 'published')->orderByDesc('views')->limit(20)->get(['id', 'title', 'views']);
    }

    public function avgRating()
    {
        return DB::table('km_ratings')->select(DB::raw('AVG(rating) as avg_rating'), DB::raw('COUNT(*) as ratings'))->first();
    }

    public function byCategory()
    {
        return DB::table('km_items')->groupBy('category_id')->select('category_id', DB::raw('COUNT(*) as articles'))->get();
    }
}
