<?php

namespace App\Modules\KnowledgeManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\KnowledgeManagement\Models\KnowledgeItem;
use Illuminate\Http\Request;

class KnowledgeItemController extends Controller
{
    public function index(Request $request)
    {
        return KnowledgeItem::query()
            ->when($request->q, fn ($qq) => $qq->where('title', 'like', "%{$request->q}%"))
            ->latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'nullable|string|max:255',
            'summary' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
            'views' => 'nullable|integer',
        ]);

        return response()->json(KnowledgeItem::create($data), 201);
    }

    public function show(KnowledgeItem $knowledge_managementItem)
    {
        return $knowledge_managementItem;
    }

    public function update(Request $request, KnowledgeItem $knowledge_managementItem)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'nullable|string|max:255',
            'summary' => 'nullable|string|max:255',
            'status' => 'nullable|string|max:255',
            'views' => 'nullable|integer',
        ]);
        $knowledge_managementItem->update($data);

        return $knowledge_managementItem;
    }

    public function destroy(KnowledgeItem $knowledge_managementItem)
    {
        $knowledge_managementItem->delete();

        return response()->noContent();
    }
}
