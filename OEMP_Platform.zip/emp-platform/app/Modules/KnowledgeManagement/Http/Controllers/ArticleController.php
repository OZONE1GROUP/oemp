<?php

namespace App\Modules\KnowledgeManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\KnowledgeManagement\Models\KnowledgeItem;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    /** Full-text-ready search over published articles. */
    public function search(Request $request)
    {
        $q = $request->get('q', '');

        return KnowledgeItem::where('status', 'published')
            ->when($q, fn ($qq) => $qq->where('title', 'like', "%$q%")->orWhere('body', 'like', "%$q%")->orWhere('summary', 'like', "%$q%"))
            ->when($request->category_id, fn ($qq) => $qq->where('category_id', $request->category_id))
            ->orderByDesc('views')->limit(50)->get(['id', 'title', 'summary', 'category_id', 'views', 'version']);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:200'],
            'category_id' => ['nullable', 'integer', 'exists:km_categories,id'],
            'summary' => ['nullable', 'string', 'max:400'],
            'body' => ['required', 'string'],
        ]);
        $item = KnowledgeItem::create(array_merge($data, ['status' => 'draft', 'views' => 0, 'version' => 1, 'author' => $request->user()?->name]));
        $item->versions()->create(['version' => 1, 'body' => $data['body'], 'editor' => $request->user()?->name, 'created_at_ts' => now()]);

        return response()->json($item, 201);
    }

    public function publish(KnowledgeItem $article, EventBus $bus)
    {
        $article->update(['status' => 'published']);
        $bus->publish('km.article.published', ['id' => $article->id]);

        return $article;
    }

    /** Save a new version of the body. */
    public function revise(Request $request, KnowledgeItem $article)
    {
        $body = $request->validate(['body' => ['required', 'string']])['body'];
        $next = $article->version + 1;
        $article->versions()->create(['version' => $next, 'body' => $body, 'editor' => $request->user()?->name, 'created_at_ts' => now()]);
        $article->update(['body' => $body, 'version' => $next]);

        return $article;
    }

    public function view(KnowledgeItem $article)
    {
        $article->increment('views');

        return $article;
    }
}
