<?php

namespace App\Modules\KnowledgeManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\KnowledgeManagement\Models\KnowledgeItem;
use Illuminate\Http\Request;

class RatingController extends Controller
{
    public function store(Request $request, KnowledgeItem $article)
    {
        $data = $request->validate(['rating' => ['required', 'integer', 'min:1', 'max:5'], 'comment' => ['nullable', 'string']]);

        return response()->json($article->ratings()->create($data), 201);
    }
}
