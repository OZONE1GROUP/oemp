<?php

namespace App\Modules\KnowledgeManagement\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\KnowledgeManagement\Models\KmCategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        return KmCategory::get();
    }

    public function store(Request $request)
    {
        $data = $request->validate(['name' => ['required', 'string', 'max:120'], 'parent_id' => ['nullable', 'integer', 'exists:km_categories,id']]);

        return response()->json(KmCategory::create($data), 201);
    }
}
