<div class="emp-module" data-module="knowledge_management">
    <h3>KnowledgeItems</h3>
    <p class="text-muted">KnowledgeManagement module &mdash; managed by the EMP platform core.</p>
</div>
