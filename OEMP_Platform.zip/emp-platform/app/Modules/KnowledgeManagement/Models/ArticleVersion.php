<?php

namespace App\Modules\KnowledgeManagement\Models;

use App\Core\Support\BaseModel;

class ArticleVersion extends BaseModel
{
    protected $table = 'km_versions';
    protected $fillable = ['tenant_id', 'item_id', 'version', 'body', 'editor', 'created_at_ts'];
    protected $casts = ['version' => 'integer', 'created_at_ts' => 'datetime'];

}
