<?php

namespace App\Modules\KnowledgeManagement\Models;

use App\Core\Support\BaseModel;

class KmCategory extends BaseModel
{
    protected $table = 'km_categories';
    protected $fillable = ['tenant_id', 'name', 'parent_id'];

}
