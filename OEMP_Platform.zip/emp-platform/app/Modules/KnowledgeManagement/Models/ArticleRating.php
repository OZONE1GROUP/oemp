<?php

namespace App\Modules\KnowledgeManagement\Models;

use App\Core\Support\BaseModel;

class ArticleRating extends BaseModel
{
    protected $table = 'km_ratings';
    protected $fillable = ['tenant_id', 'item_id', 'rating', 'comment'];
    protected $casts = ['rating' => 'integer'];

}
