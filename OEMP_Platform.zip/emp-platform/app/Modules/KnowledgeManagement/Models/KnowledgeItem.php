<?php

namespace App\Modules\KnowledgeManagement\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;

class KnowledgeItem extends BaseModel
{
    protected $table = 'km_items';
    protected $fillable = ['tenant_id','title','category_id','category','summary','body','status','views','version','author'];
    protected $casts = ['views' => 'integer', 'version' => 'integer'];

    public function versions(): HasMany
    {
        return $this->hasMany(ArticleVersion::class, 'item_id');
    }

    public function ratings(): HasMany
    {
        return $this->hasMany(ArticleRating::class, 'item_id');
    }
}
