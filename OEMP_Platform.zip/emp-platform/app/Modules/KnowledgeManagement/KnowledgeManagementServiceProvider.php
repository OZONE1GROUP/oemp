<?php

namespace App\Modules\KnowledgeManagement;

use App\Core\Support\ModuleServiceProvider;

class KnowledgeManagementServiceProvider extends ModuleServiceProvider
{
    public function key(): string
    {
        return 'knowledge_management';
    }

    protected function moduleBasePath(): string
    {
        return __DIR__;
    }
}
