<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('km_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->timestamps();
        });

        Schema::create('km_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained('km_items')->cascadeOnDelete();
            $table->integer('version')->default(1);
            $table->longText('body')->nullable();
            $table->string('editor')->nullable();
            $table->timestamp('created_at_ts')->nullable();
        });

        Schema::create('km_ratings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained('km_items')->cascadeOnDelete();
            $table->integer('rating');
            $table->text('comment')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('km_ratings');
        Schema::dropIfExists('km_versions');
        Schema::dropIfExists('km_categories');
    }
};
