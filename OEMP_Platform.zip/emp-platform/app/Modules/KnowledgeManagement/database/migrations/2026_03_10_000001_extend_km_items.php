<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('km_items', function (Blueprint $table) {
            foreach ([['category_id','bigint'],['body','long'],['version','int'],['author','str']] as [$c,$t]) {
                if (! Schema::hasColumn('km_items', $c)) {
                    match ($t) {
                        'bigint' => $table->unsignedBigInteger($c)->nullable(),
                        'long' => $table->longText($c)->nullable(),
                        'int' => $table->integer($c)->default(1),
                        default => $table->string($c)->nullable(),
                    };
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('km_items', function (Blueprint $table) {
            $table->dropColumn(['category_id', 'body', 'version', 'author']);
        });
    }
};
