<?php

use Illuminate\Support\Facades\Route;
use App\Modules\KnowledgeManagement\Http\Controllers\CategoryController;
use App\Modules\KnowledgeManagement\Http\Controllers\ArticleController;
use App\Modules\KnowledgeManagement\Http\Controllers\RatingController;
use App\Modules\KnowledgeManagement\Http\Controllers\KmAnalyticsController;

Route::middleware(['auth:sanctum', 'tenant', 'entitled:module.knowledge_management'])
    ->prefix('api/knowledge')
    ->group(function () {
        Route::get('categories', [CategoryController::class, 'index']);
        Route::post('categories', [CategoryController::class, 'store']);

        Route::get('articles/search', [ArticleController::class, 'search']);
        Route::post('articles', [ArticleController::class, 'store']);
        Route::post('articles/{article}/publish', [ArticleController::class, 'publish']);
        Route::post('articles/{article}/revise', [ArticleController::class, 'revise']);
        Route::post('articles/{article}/view', [ArticleController::class, 'view']);
        Route::post('articles/{article}/rate', [RatingController::class, 'store']);

        Route::get('analytics/top-articles', [KmAnalyticsController::class, 'topArticles']);
        Route::get('analytics/avg-rating', [KmAnalyticsController::class, 'avgRating']);
        Route::get('analytics/by-category', [KmAnalyticsController::class, 'byCategory']);
    });
