<?php

namespace App\Core\Licensing;

use Illuminate\Support\Facades\Cache;

/**
 * Fast, cached entitlement checks. Every module route is guarded by an
 * entitlement key such as "module.erp". Meters and feature flags are evaluated
 * here too. In production the entitlement is a signed document issued by the
 * licensing authority and re-validated periodically.
 */
class EntitlementService
{
    public function forCurrentTenant(): ?Entitlement
    {
        $tenant = app('emp.tenant');
        if (! $tenant) {
            return null;
        }

        return Cache::remember("entitlement:{$tenant->id}", 300, function () use ($tenant) {
            return Entitlement::where('tenant_id', $tenant->id)
                ->where('valid_to', '>=', now())
                ->latest()
                ->first();
        });
    }

    public function can(string $key, int $quantity = 1): bool
    {
        $ent = $this->forCurrentTenant();
        if (! $ent) {
            return false;
        }

        // module.* checks
        if (str_starts_with($key, 'module.')) {
            $module = substr($key, 7);
            return in_array($module, $ent->modules ?? [], true);
        }

        // feature.* checks
        if (str_starts_with($key, 'feature.')) {
            $feature = substr($key, 8);
            return (bool) ($ent->features[$feature] ?? false);
        }

        return true;
    }

    public function meterAllows(string $meter, int $used): bool
    {
        $ent = $this->forCurrentTenant();
        $cfg = $ent->meters[$meter] ?? null;
        if (! $cfg) {
            return true;
        }
        $cap = $cfg['hard_cap'] ?? null;
        return $cap === null || $used <= $cap;
    }
}
