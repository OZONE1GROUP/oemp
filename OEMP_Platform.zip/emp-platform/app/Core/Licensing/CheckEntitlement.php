<?php

namespace App\Core\Licensing;

use Closure;
use Illuminate\Http\Request;

/**
 * Route middleware: `->middleware('entitled:module.erp')`.
 * Returns HTTP 402 (Payment Required) with an upgrade path when denied.
 */
class CheckEntitlement
{
    public function __construct(private EntitlementService $entitlements) {}

    public function handle(Request $request, Closure $next, string $key)
    {
        if (! $this->entitlements->can($key)) {
            return response()->json([
                'error' => 'entitlement_required',
                'key' => $key,
                'message' => 'Your subscription does not include this capability.',
                'upgrade_url' => '/billing/upgrade',
            ], 402);
        }

        return $next($request);
    }
}
