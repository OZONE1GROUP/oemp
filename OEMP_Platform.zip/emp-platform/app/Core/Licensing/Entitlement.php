<?php

namespace App\Core\Licensing;

use Illuminate\Database\Eloquent\Model;

class Entitlement extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'modules' => 'array',
        'features' => 'array',
        'meters' => 'array',
        'seats' => 'array',
        'valid_to' => 'datetime',
    ];
}
