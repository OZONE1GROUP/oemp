<?php

namespace App\Core\Reporting\Models;

use App\Core\Support\BaseModel;

/**
 * A saved, metadata-defined report: the source table, columns, filters,
 * grouping and aggregate. The ReportController interprets these safely.
 */
class ReportDefinition extends BaseModel
{
    protected $table = 'report_definitions';
    protected $fillable = ['tenant_id', 'name', 'module', 'source', 'columns', 'filters', 'group_by', 'aggregate'];
    protected $casts = ['columns' => 'array', 'filters' => 'array'];
}
