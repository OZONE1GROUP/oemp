<?php

namespace App\Core\Reporting\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Reporting\Models\ReportDefinition;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index()
    {
        return ReportDefinition::orderBy('name')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string'],
            'module' => ['required', 'string'],
            'source' => ['required', 'string'],
            'columns' => ['required', 'array'],
            'filters' => ['nullable', 'array'],
            'group_by' => ['nullable', 'string'],
            'aggregate' => ['nullable', 'in:count,sum,avg,min,max'],
        ]);

        return response()->json(ReportDefinition::create($data), 201);
    }

    /** Execute a report definition and return rows (guards against unknown tables/columns). */
    public function run(ReportDefinition $report)
    {
        abort_unless(Schema::hasTable($report->source), 422, 'Unknown source table.');

        $cols = collect($report->columns)
            ->filter(fn ($c) => Schema::hasColumn($report->source, $c))
            ->values()->all();

        $query = DB::table($report->source);
        foreach ($report->filters ?? [] as $f) {
            if (Schema::hasColumn($report->source, $f['column'] ?? '')) {
                $query->where($f['column'], $f['op'] ?? '=', $f['value'] ?? null);
            }
        }

        if ($report->group_by && $report->aggregate) {
            $agg = strtoupper($report->aggregate);
            $target = $cols[0] ?? '*';
            return $query->select($report->group_by)
                ->selectRaw("$agg(" . ($target === '*' ? '*' : "`$target`") . ") as value")
                ->groupBy($report->group_by)
                ->get();
        }

        return $query->select($cols ?: ['*'])->limit(1000)->get();
    }

    /** Lightweight analytics summary used by dashboards. */
    public function analytics(Request $request)
    {
        $source = $request->validate(['source' => ['required', 'string']])['source'];
        abort_unless(Schema::hasTable($source), 422, 'Unknown source table.');

        $base = DB::table($source);
        return [
            'total' => (clone $base)->count(),
            'created_last_30d' => Schema::hasColumn($source, 'created_at')
                ? (clone $base)->where('created_at', '>=', now()->subDays(30))->count() : null,
        ];
    }
}
