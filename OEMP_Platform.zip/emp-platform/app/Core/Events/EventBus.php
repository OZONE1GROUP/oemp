<?php

namespace App\Core\Events;

use Illuminate\Support\Facades\Event;

/**
 * Thin wrapper over Laravel's event dispatcher used as the inter-module bus.
 * Modules publish domain events (e.g. "erp.sales_order.created") and other
 * modules subscribe, keeping bounded contexts loosely coupled.
 */
class EventBus
{
    public function publish(string $event, array $payload = []): void
    {
        Event::dispatch("emp.$event", [$payload]);
    }

    public function subscribe(string $event, callable $listener): void
    {
        Event::listen("emp.$event", $listener);
    }
}
