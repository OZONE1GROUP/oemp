<?php

namespace App\Core\Tenancy;

use Closure;
use Illuminate\Http\Request;

/**
 * Resolves the active tenant from the authenticated user, an X-Tenant header,
 * or the request subdomain, and binds it into the container as "emp.tenant".
 */
class ResolveTenant
{
    public function handle(Request $request, Closure $next)
    {
        $tenant = null;

        if ($user = $request->user()) {
            $tenant = Tenant::find($user->tenant_id);
        } elseif ($header = $request->header('X-Tenant')) {
            $tenant = Tenant::where('slug', $header)->first();
        } else {
            $sub = explode('.', $request->getHost())[0] ?? null;
            if ($sub) {
                $tenant = Tenant::where('slug', $sub)->first();
            }
        }

        if ($tenant) {
            app()->instance('emp.tenant', $tenant);
        }

        return $next($request);
    }
}
