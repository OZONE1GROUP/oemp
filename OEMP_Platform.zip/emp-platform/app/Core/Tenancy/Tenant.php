<?php

namespace App\Core\Tenancy;

use Illuminate\Database\Eloquent\Model;

class Tenant extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'settings' => 'array',
        'active' => 'boolean',
    ];
}
