<?php

namespace App\Core\Tenancy;

use Illuminate\Database\Eloquent\Builder;

/**
 * Applies a global scope so every query is automatically constrained to the
 * current tenant, and stamps tenant_id on create. This is the backbone of the
 * shared-schema multi-tenancy model.
 */
trait BelongsToTenant
{
    public static function bootBelongsToTenant(): void
    {
        static::creating(function ($model) {
            if (! $model->tenant_id && $tenant = app('emp.tenant')) {
                $model->tenant_id = $tenant->id;
            }
        });

        static::addGlobalScope('tenant', function (Builder $builder) {
            if ($tenant = app('emp.tenant')) {
                $builder->where($builder->getModel()->getTable() . '.tenant_id', $tenant->id);
            }
        });
    }
}
