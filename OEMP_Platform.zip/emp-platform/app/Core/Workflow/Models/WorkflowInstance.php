<?php

namespace App\Core\Workflow\Models;

use App\Core\Support\BaseModel;

class WorkflowInstance extends BaseModel
{
    protected $table = 'workflow_instances';
    protected $fillable = ['tenant_id', 'definition_id', 'subject_type', 'subject_id', 'state', 'history'];
    protected $casts = ['history' => 'array'];
}
