<?php

namespace App\Core\Workflow\Models;

use App\Core\Support\BaseModel;

class WorkflowDefinition extends BaseModel
{
    protected $table = 'workflow_definitions';
    protected $fillable = ['tenant_id', 'key', 'name', 'entity', 'states', 'transitions', 'active'];
    protected $casts = ['states' => 'array', 'transitions' => 'array', 'active' => 'boolean'];
}
