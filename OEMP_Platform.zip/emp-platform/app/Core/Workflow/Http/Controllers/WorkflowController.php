<?php

namespace App\Core\Workflow\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Workflow\Models\WorkflowDefinition;
use App\Core\Workflow\Models\WorkflowInstance;
use Illuminate\Http\Request;

class WorkflowController extends Controller
{
    public function definitions()
    {
        return WorkflowDefinition::orderBy('name')->get();
    }

    public function storeDefinition(Request $request)
    {
        $data = $request->validate([
            'key' => ['required', 'string'],
            'name' => ['required', 'string'],
            'entity' => ['required', 'string'],
            'states' => ['required', 'array'],
            'transitions' => ['required', 'array'],
        ]);

        return response()->json(WorkflowDefinition::create($data), 201);
    }

    /** Attempt a state transition, validating it against the definition. */
    public function transition(Request $request, WorkflowInstance $instance)
    {
        $to = $request->validate(['to' => ['required', 'string']])['to'];
        $def = WorkflowDefinition::findOrFail($instance->definition_id);

        $allowed = collect($def->transitions)
            ->contains(fn ($t) => $t['from'] === $instance->state && $t['to'] === $to);

        abort_unless($allowed, 422, "Illegal transition {$instance->state} -> {$to}");

        $history = $instance->history ?? [];
        $history[] = ['from' => $instance->state, 'to' => $to, 'at' => now()->toIso8601String(), 'by' => $request->user()?->id];
        $instance->update(['state' => $to, 'history' => $history]);

        return $instance;
    }
}
