<?php

namespace App\Core\Integration\Models;

use App\Core\Support\BaseModel;

class Connector extends BaseModel
{
    protected $table = 'connectors';
    protected $fillable = ['tenant_id', 'type', 'name', 'config', 'active'];
    protected $casts = ['config' => 'encrypted:array', 'active' => 'boolean'];
}
