<?php

namespace App\Core\Integration\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Events\EventBus;
use Illuminate\Http\Request;

class WebhookController extends Controller
{
    public function __construct(private EventBus $bus) {}

    /** Inbound webhook endpoint; publishes to the internal event bus. */
    public function receive(Request $request, string $connector)
    {
        $this->bus->publish("integration.$connector.received", $request->all());

        return response()->json(['status' => 'accepted'], 202);
    }
}
