<?php

namespace App\Core\Config\Models;

use App\Core\Support\BaseModel;

/**
 * Tenant- and module-scoped parameter registry. All configurable platform and
 * module parameters live here (key/value with type + group), enabling the
 * "configuration over customization" principle.
 */
class Setting extends BaseModel
{
    protected $table = 'settings';
    protected $fillable = ['tenant_id', 'module', 'group', 'key', 'value', 'type'];
    protected $casts = ['value' => 'json'];
}
