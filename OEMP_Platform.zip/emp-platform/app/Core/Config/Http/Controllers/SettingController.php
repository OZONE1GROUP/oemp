<?php

namespace App\Core\Config\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Config\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index(Request $request)
    {
        return Setting::query()
            ->when($request->module, fn ($q) => $q->where('module', $request->module))
            ->orderBy('group')->get();
    }

    public function upsert(Request $request)
    {
        $data = $request->validate([
            'module' => ['required', 'string'],
            'group' => ['nullable', 'string'],
            'key' => ['required', 'string'],
            'value' => ['nullable'],
            'type' => ['required', 'in:string,number,boolean,json'],
        ]);

        $setting = Setting::updateOrCreate(
            ['module' => $data['module'], 'key' => $data['key']],
            $data
        );

        return $setting;
    }
}
