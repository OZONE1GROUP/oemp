<?php

namespace App\Core\Files\Models;

use App\Core\Support\BaseModel;

class FileObject extends BaseModel
{
    protected $table = 'file_objects';
    protected $fillable = ['tenant_id', 'disk', 'path', 'name', 'mime', 'size', 'owner_id', 'attachable_type', 'attachable_id'];
    protected $casts = ['size' => 'integer'];
}
