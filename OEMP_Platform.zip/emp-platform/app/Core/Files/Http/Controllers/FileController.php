<?php

namespace App\Core\Files\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Files\Models\FileObject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FileController extends Controller
{
    public function store(Request $request)
    {
        $request->validate(['file' => ['required', 'file', 'max:51200']]);
        $file = $request->file('file');
        $path = $file->store('uploads', config('filesystems.default'));

        return response()->json(FileObject::create([
            'disk' => config('filesystems.default'),
            'path' => $path,
            'name' => $file->getClientOriginalName(),
            'mime' => $file->getMimeType(),
            'size' => $file->getSize(),
            'owner_id' => $request->user()?->id,
        ]), 201);
    }

    public function download(FileObject $file)
    {
        return Storage::disk($file->disk)->download($file->path, $file->name);
    }
}
