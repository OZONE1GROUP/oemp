<?php

namespace App\Core\Contracts;

interface Module
{
    /** Machine key, e.g. "erp". */
    public function key(): string;

    /** Human name, e.g. "ERP". */
    public function name(): string;

    /** Entitlement required to access this module. */
    public function entitlement(): string;
}
