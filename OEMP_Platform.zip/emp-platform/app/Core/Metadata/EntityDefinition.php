<?php

namespace App\Core\Metadata;

use App\Core\Support\BaseModel;

/**
 * A metadata-defined entity. The MetadataEngine can render forms, validation
 * and API behaviour from these definitions without bespoke per-object code.
 */
class EntityDefinition extends BaseModel
{
    protected $table = 'metadata_entities';

    protected $casts = [
        'fields' => 'array',
        'layout' => 'array',
        'permissions' => 'array',
    ];
}
