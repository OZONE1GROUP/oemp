<?php

namespace App\Core\Metadata;

/**
 * Interprets metadata definitions at runtime. This reference implementation
 * exposes validation-rule generation; a full build extends it to dynamic
 * schema, form rendering and permission enforcement.
 */
class MetadataEngine
{
    public function definition(string $entity): ?EntityDefinition
    {
        return EntityDefinition::where('key', $entity)->first();
    }

    /** Build Laravel validation rules from a metadata definition. */
    public function validationRules(string $entity): array
    {
        $def = $this->definition($entity);
        if (! $def) {
            return [];
        }

        $rules = [];
        foreach ($def->fields ?? [] as $field) {
            $r = [];
            $r[] = ($field['required'] ?? false) ? 'required' : 'nullable';
            $r[] = match ($field['type'] ?? 'string') {
                'integer', 'decimal' => 'numeric',
                'boolean' => 'boolean',
                'date' => 'date',
                'email' => 'email',
                default => 'string',
            };
            $rules[$field['key']] = implode('|', $r);
        }

        return $rules;
    }
}
