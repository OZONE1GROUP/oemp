<?php

namespace App\Core\SuperAdmin\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Tenancy\Tenant;
use App\Core\Licensing\Entitlement;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class TenantController extends Controller
{
    /** List every tenant with its edition, seats and enabled-module count. */
    public function index()
    {
        return Tenant::query()->orderBy('name')->get()->map(function ($tenant) {
            $ent = Entitlement::where('tenant_id', $tenant->id)->latest('id')->first();
            return [
                'id' => $tenant->id,
                'name' => $tenant->name,
                'slug' => $tenant->slug,
                'edition' => $tenant->edition,
                'active' => (bool) $tenant->active,
                'enabled_modules' => count($ent->modules ?? []),
                'total_modules' => count(config('emp.modules', [])),
                'valid_to' => optional($ent)->valid_to,
            ];
        });
    }

    /** Provision a new tenant with an admin user and a base entitlement. */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'slug' => ['required', 'string', 'max:60', 'alpha_dash', 'unique:tenants,slug'],
            'edition' => ['required', 'in:starter,professional,enterprise'],
            'admin_email' => ['required', 'email'],
            'admin_password' => ['required', 'string', 'min:12'],
            'modules' => ['array'],
        ]);

        return DB::transaction(function () use ($data) {
            $tenant = Tenant::create([
                'name' => $data['name'], 'slug' => $data['slug'],
                'edition' => $data['edition'], 'active' => true,
            ]);
            DB::table('users')->insert([
                'tenant_id' => $tenant->id, 'name' => $data['name'] . ' Admin',
                'email' => $data['admin_email'], 'password' => Hash::make($data['admin_password']),
                'created_at' => now(), 'updated_at' => now(),
            ]);
            Entitlement::create([
                'tenant_id' => $tenant->id, 'edition' => $data['edition'],
                'seats' => ['named' => 50],
                'modules' => array_values($data['modules'] ?? []),
                'features' => ['sso' => true, 'bi_feeds' => true],
                'meters' => ['iot_devices' => ['included' => 100, 'hard_cap' => 1000]],
                'valid_from' => now(), 'valid_to' => now()->addYear(),
            ]);

            return response()->json($tenant, 201);
        });
    }

    public function toggleActive(Tenant $tenant)
    {
        $tenant->update(['active' => ! $tenant->active]);

        return $tenant;
    }
}
