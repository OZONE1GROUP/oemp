<?php

namespace App\Core\SuperAdmin\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Tenancy\Tenant;
use App\Core\Licensing\Entitlement;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Request;

class ModuleAccessController extends Controller
{
    /** Full 48-module matrix for a tenant with an enabled flag each. */
    public function index(Tenant $tenant)
    {
        $ent = $this->entitlement($tenant);
        $enabled = $ent->modules ?? [];

        return collect(config('emp.modules', []))->map(function ($m, $key) use ($enabled) {
            return [
                'key' => $key,
                'name' => $m['name'],
                'label' => $m['label'] ?? null,
                'band' => $m['band'] ?? null,
                'icon' => $m['icon'] ?? null,
                'enabled' => in_array($key, $enabled, true),
            ];
        })->values();
    }

    /** Enable or disable a single module for a tenant (updates entitlement + clears cache). */
    public function toggle(Request $request, Tenant $tenant)
    {
        $data = $request->validate([
            'module' => ['required', 'string'],
            'enabled' => ['required', 'boolean'],
        ]);
        abort_unless(array_key_exists($data['module'], config('emp.modules', [])), 422, 'Unknown module.');

        $ent = $this->entitlement($tenant);
        $modules = $ent->modules ?? [];

        if ($data['enabled']) {
            $modules[] = $data['module'];
        } else {
            $modules = array_filter($modules, fn ($m) => $m !== $data['module']);
        }
        $ent->update(['modules' => array_values(array_unique($modules))]);

        // Invalidate the cached entitlement so the change is enforced immediately.
        Cache::forget("entitlement:{$tenant->id}");

        return ['tenant_id' => $tenant->id, 'module' => $data['module'], 'enabled' => $data['enabled'],
            'enabled_modules' => count($ent->fresh()->modules ?? [])];
    }

    /** Bulk set the enabled module list for a tenant. */
    public function bulkSet(Request $request, Tenant $tenant)
    {
        $data = $request->validate(['modules' => ['required', 'array'], 'modules.*' => ['string']]);
        $valid = array_values(array_intersect($data['modules'], array_keys(config('emp.modules', []))));
        $ent = $this->entitlement($tenant);
        $ent->update(['modules' => $valid]);
        Cache::forget("entitlement:{$tenant->id}");

        return ['tenant_id' => $tenant->id, 'enabled_modules' => count($valid)];
    }

    private function entitlement(Tenant $tenant): Entitlement
    {
        return Entitlement::firstOrCreate(
            ['tenant_id' => $tenant->id],
            ['edition' => $tenant->edition ?? 'professional', 'modules' => [],
             'seats' => ['named' => 50], 'valid_from' => now(), 'valid_to' => now()->addYear()]
        );
    }
}
