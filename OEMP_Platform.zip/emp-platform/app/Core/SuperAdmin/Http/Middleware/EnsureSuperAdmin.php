<?php

namespace App\Core\SuperAdmin\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Guards the super-admin console: only platform super admins may pass. */
class EnsureSuperAdmin
{
    public function handle(Request $request, Closure $next)
    {
        abort_unless($request->user() && $request->user()->is_super_admin, 403, 'Super administrator access required.');

        return $next($request);
    }
}
