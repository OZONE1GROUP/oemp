<?php

namespace App\Core\SuperAdmin;

use Illuminate\Support\ServiceProvider;

class SuperAdminServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->app['router']->aliasMiddleware('superadmin', \App\Core\SuperAdmin\Http\Middleware\EnsureSuperAdmin::class);
        $this->loadRoutesFrom(base_path('routes/superadmin.php'));
    }
}
