<?php

namespace App\Core\Notifications\Models;

use App\Core\Support\BaseModel;

class NotificationTemplate extends BaseModel
{
    protected $table = 'notification_templates';
    protected $fillable = ['tenant_id', 'key', 'channel', 'subject', 'body', 'active'];
    protected $casts = ['active' => 'boolean'];
}
