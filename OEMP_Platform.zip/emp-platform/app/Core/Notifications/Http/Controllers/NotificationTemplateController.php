<?php

namespace App\Core\Notifications\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Notifications\Models\NotificationTemplate;
use Illuminate\Http\Request;

class NotificationTemplateController extends Controller
{
    public function index()
    {
        return NotificationTemplate::orderBy('key')->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'key' => ['required', 'string'],
            'channel' => ['required', 'in:email,sms,push,in_app,webhook'],
            'subject' => ['nullable', 'string'],
            'body' => ['required', 'string'],
            'active' => ['boolean'],
        ]);

        return response()->json(NotificationTemplate::create($data), 201);
    }
}
