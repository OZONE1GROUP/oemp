<?php

namespace App\Core\Support;

use Illuminate\Database\Eloquent\Model;
use App\Core\Tenancy\BelongsToTenant;

abstract class BaseModel extends Model
{
    use BelongsToTenant;

    protected $guarded = ['id'];
}
