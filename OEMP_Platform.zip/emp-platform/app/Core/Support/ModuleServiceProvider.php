<?php

namespace App\Core\Support;

use Illuminate\Support\ServiceProvider;
use App\Core\Contracts\Module;

/**
 * Base provider every EMP module extends. Wires routes, migrations and views
 * from a conventional folder layout so modules stay self-contained packages.
 */
abstract class ModuleServiceProvider extends ServiceProvider implements Module
{
    public function boot(): void
    {
        $base = $this->moduleBasePath();

        if (is_dir("$base/routes")) {
            $this->loadRoutesFrom("$base/routes/api.php");
        }
        if (is_dir("$base/database/migrations")) {
            $this->loadMigrationsFrom("$base/database/migrations");
        }
        if (is_dir("$base/resources/views")) {
            $this->loadViewsFrom("$base/resources/views", $this->key());
        }
    }

    abstract protected function moduleBasePath(): string;

    public function name(): string
    {
        return class_basename(static::class);
    }

    public function entitlement(): string
    {
        return 'module.' . $this->key();
    }
}
