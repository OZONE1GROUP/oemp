<?php

namespace App\Core\Iam\Models;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    protected $table = 'permissions';
    protected $fillable = ['key', 'group', 'description'];
}
