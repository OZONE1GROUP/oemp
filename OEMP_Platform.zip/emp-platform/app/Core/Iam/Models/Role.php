<?php

namespace App\Core\Iam\Models;

use App\Core\Support\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Role extends BaseModel
{
    protected $table = 'roles';
    protected $fillable = ['tenant_id', 'name', 'slug', 'description', 'is_system'];
    protected $casts = ['is_system' => 'boolean'];

    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'permission_role');
    }
}
