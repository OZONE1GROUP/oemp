<?php

namespace App\Core\Iam\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class StoreUserRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('iam.users.manage') ?? true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:190'],
            'password' => ['required', Password::min(12)->mixedCase()->numbers()->symbols()],
            'roles' => ['array'],
            'roles.*' => ['integer', 'exists:roles,id'],
            'mfa_enabled' => ['boolean'],
        ];
    }
}
