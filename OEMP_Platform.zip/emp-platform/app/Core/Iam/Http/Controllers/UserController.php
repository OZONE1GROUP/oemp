<?php

namespace App\Core\Iam\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Core\Iam\Http\Requests\StoreUserRequest;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        return User::query()->orderBy('name')->paginate(50);
    }

    public function store(StoreUserRequest $request)
    {
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'mfa_enabled' => $request->boolean('mfa_enabled'),
        ]);

        return response()->json($user, 201);
    }
}
