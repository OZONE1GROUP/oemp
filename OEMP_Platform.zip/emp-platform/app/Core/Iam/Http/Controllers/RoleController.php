<?php

namespace App\Core\Iam\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Core\Iam\Models\Role;
use App\Core\Iam\Http\Requests\StoreRoleRequest;

class RoleController extends Controller
{
    public function index()
    {
        return Role::with('permissions')->orderBy('name')->paginate(50);
    }

    public function store(StoreRoleRequest $request)
    {
        $role = Role::create($request->only('name', 'slug', 'description'));
        $role->permissions()->sync($request->input('permissions', []));

        return response()->json($role->load('permissions'), 201);
    }

    public function update(StoreRoleRequest $request, Role $role)
    {
        $role->update($request->only('name', 'slug', 'description'));
        $role->permissions()->sync($request->input('permissions', []));

        return $role->load('permissions');
    }

    public function destroy(Role $role)
    {
        abort_if($role->is_system, 403, 'System roles cannot be deleted.');
        $role->delete();

        return response()->noContent();
    }
}
