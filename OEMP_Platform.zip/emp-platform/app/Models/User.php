<?php

namespace App\Models;

use App\Core\Iam\Models\Role;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $fillable = ['tenant_id', 'name', 'email', 'password', 'mfa_enabled', 'mfa_secret', 'is_super_admin'];
    protected $hidden = ['password', 'remember_token', 'mfa_secret'];
    protected $casts = ['email_verified_at' => 'datetime', 'password' => 'hashed', 'mfa_enabled' => 'boolean', 'is_super_admin' => 'boolean'];

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'role_user');
    }

    public function hasPermission(string $key): bool
    {
        return $this->roles()->whereHas('permissions', fn ($q) => $q->where('key', $key))->exists();
    }
}
