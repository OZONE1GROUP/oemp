#!/usr/bin/env bash
# OEMP one-command deploy for Hostinger VPS -> https://oemp.ozngroup.com
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/oemp}"
cd "$APP_DIR"

echo "==> Pulling latest code"
git pull --ff-only || true

echo "==> Building & starting containers"
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build

echo "==> Installing PHP dependencies"
docker compose exec -T app composer install --no-dev --optimize-autoloader

if ! grep -q '^APP_KEY=base64' .env 2>/dev/null; then
  echo "==> Generating app key"
  docker compose exec -T app php artisan key:generate --force
fi

echo "==> Running migrations"
docker compose exec -T app php artisan migrate --force

if [ "${SEED:-no}" = "yes" ]; then
  echo "==> Seeding (super admin + demo tenant)"
  docker compose exec -T app php artisan db:seed --force
fi

echo "==> Caching config & routes"
docker compose exec -T app php artisan config:cache
docker compose exec -T app php artisan route:cache

echo "==> Building frontend"
npm ci && npm run build

echo "==> Done. OEMP is live at https://oemp.ozngroup.com"
echo "    Super admin: superadmin@oemp.ozngroup.com / ChangeMe!2026 (change immediately)"
